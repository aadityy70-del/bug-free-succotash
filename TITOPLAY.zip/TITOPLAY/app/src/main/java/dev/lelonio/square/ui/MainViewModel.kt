package dev.lelonio.square.ui

import coil.imageLoader
import android.app.Application
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.lelonio.square.SquareApplication
import dev.lelonio.square.auth.SpotifyOAuth
import dev.lelonio.square.backend.BackendAuthState
import dev.lelonio.square.backend.BackendId
import dev.lelonio.square.backend.HomeChip
import dev.lelonio.square.backend.HomeRow
import dev.lelonio.square.backend.SearchLabels
import dev.lelonio.square.R
import dev.lelonio.square.data.Catalog
import dev.lelonio.square.data.SpotifyApi
import dev.lelonio.square.data.DownloadStore
import dev.lelonio.square.download.DownloadService
import dev.lelonio.square.data.AddTracksRequestDto
import dev.lelonio.square.data.IdsDto
import dev.lelonio.square.data.RemoveTracksRequestDto
import dev.lelonio.square.data.TrackUriDto
import dev.lelonio.square.data.CatalogPlaylist
import dev.lelonio.square.data.HomeShelf
import dev.lelonio.square.data.SpotifyHome
import dev.lelonio.square.data.CatalogTrack
import dev.lelonio.square.data.ContextCacheStore
import dev.lelonio.square.data.GatewayPage
import dev.lelonio.square.data.LocalLibrary
import dev.lelonio.square.data.SearchItem
import dev.lelonio.square.data.TransferRequestDto
import dev.lelonio.square.data.SearchResults
import dev.lelonio.square.data.toCatalogTrack
import dev.lelonio.square.data.toResults
import dev.lelonio.square.nativecore.NativeBridge
import dev.lelonio.square.playback.BuiltInPresets
import dev.lelonio.square.playback.EffectPreset
import dev.lelonio.square.playback.PlaybackService
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Dispatchers
import retrofit2.HttpException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.isActive
import java.util.concurrent.ConcurrentHashMap

/**
 * Login gate and library browsing.
 *
 * Playback commands are deliberately absent: the UI talks to the media session
 * controller directly, so the notification, the lock screen and the app all read
 * one source of truth instead of two copies that can drift.
 */
class MainViewModel(app: Application) : AndroidViewModel(app) {

    sealed interface UiState {
        data object LoggedOut : UiState

        /** Waiting for the access-point handshake. */
        data object Connecting : UiState
        data object Loading : UiState
        data class Ready(
            /**
             * The profile name where one is available, the account name
             * otherwise. The access point only knows the latter — a login id
             * like `31k4…` on many accounts — so the readable name has to come
             * from the Web API, and does not exist until the user has connected
             * their own application.
             */
            val displayName: String,
            val playlists: List<CatalogPlaylist>,
            val avatarUrl: String? = null,
        ) : UiState
        data class Failed(val message: String) : UiState
    }

    /** What kind of thing the detail screen is showing. */
    enum class DetailKind(@StringRes val label: Int) {
        PLAYLIST(R.string.playlist),
        ALBUM(R.string.album),
        ARTIST(R.string.artist),
        /** A podcast: its episodes are the page's list. */
        SHOW(R.string.podcast),
    }

    /**
     * The playlist, album or artist currently open, keyed by its URI.
     *
     * One state and one screen for all three: they differ in where the tracks
     * come from and in a strip of albums the artist has and the other two do
     * not, which is not enough to justify three near-identical screens that
     * would then drift apart.
     */
    /**
     * One record, said the way the artist page's top card says it.
     *
     * Its own type rather than a [SearchItem] because the card leads with the
     * date and counts the songs, and neither fits in a subtitle line.
     */
    data class ArtistRelease(
        val uri: String,
        val title: String,
        val artworkUrl: String?,
        /** ISO-8601 as Spotify gives it: a full date, a month, or a year. */
        val releaseDate: String,
        val trackCount: Int,
    )

    data class PlaylistState(
        val uri: String? = null,
        val name: String = "",
        val artworkUrl: String? = null,
        val tracks: List<CatalogTrack> = emptyList(),
        val loading: Boolean = false,
        /**
         * More of the list is still being resolved.
         *
         * Separate from [loading]: the first batch replaces the screen with a
         * spinner, the rest arrive under a list the user is already reading and
         * must not.
         */
        val loadingMore: Boolean = false,
        val error: String? = null,
        val kind: DetailKind = DetailKind.PLAYLIST,
        /** What the source says the list is about; empty when it says nothing. */
        val description: String = "",
        /**
         * Whether this page is in the account's library — followed, for a
         * playlist, saved for an album.
         *
         * Null while unknown, and null forever for the pages where the question
         * does not apply: the button is absent rather than wrong.
         */
        val saved: Boolean? = null,
        /**
         * Whether this playlist is one the listener made.
         *
         * Null while unknown, and null for everything that is not a Spotify
         * playlist. It decides which of the actions in the menu are real:
         * Spotify has no way to delete somebody else's list, and offering it
         * meant offering a button that could only fail. Renaming is the same.
         */
        val mine: Boolean? = null,
        /** Populated for artists only. */
        val albums: List<SearchItem> = emptyList(),
        /** Their singles and EPs, kept apart from the albums above. */
        val singles: List<SearchItem> = emptyList(),
        /** Records that are somebody else's, with them on it. */
        val appearsOn: List<SearchItem> = emptyList(),
        /** The playlists Spotify built around them, "This Is" first. */
        val artistPlaylists: List<SearchItem> = emptyList(),
        /** Lists like this one, for the row under a playlist's songs. */
        val relatedPlaylists: List<SearchItem> = emptyList(),
        /** Fans also like / related artists. */
        val relatedArtists: List<SearchItem> = emptyList(),
        /** Whether the artist is verified. */
        val verified: Boolean = true,
        /** Formatted monthly listeners string, e.g. "14.3 M oyentes mensuales". */
        val monthlyListeners: String? = null,
        /**
         * The record they put out last, for the card under the artist's photo.
         *
         * Null on every page that is not an artist, and on an artist whose
         * discography came back empty — the card is then simply absent rather
         * than a row of placeholders.
         */
        /**
         * The picture the page opens with, when there is an editorial one.
         *
         * Apple's catalogue keeps a full-height photograph for artists and for
         * some records; where it exists the page is that photograph, and where
         * it does not the page is the square cover — which is the difference
         * between the two kinds of header the reference shows.
         */
        val heroUrl: String? = null,
        /**
         * The sleeve as Apple scanned it, where the page has one.
         *
         * Beside [artworkUrl] rather than replacing it: that one is the cover
         * this app downloads, caches and colours pages from, and swapping the
         * source under it would have every kept playlist fetch its cover again.
         * This is only what the header draws.
         */
        val coverUrl: String? = null,
        /** What Apple's editors wrote about the record; see AppleCatalog. */
        val notes: String? = null,
        /** The page's tint as six hex digits, where the catalogue names one. */
        val tintHex: String? = null,
        /** The ink the catalogue picked for that tint; see AppleCatalog. */
        val inkHex: String? = null,
        /** The header picture's own proportions, width over height. */
        val heroAspect: Float? = null,
        /**
         * Whose list it is: the account that made a playlist.
         *
         * An album's is taken from its own tracks and does not need a request,
         * so only a playlist fills this in; see openPlaylist.
         */
        val byline: String = "",
        /** Where an artist is from, or when the band was formed. */
        val origin: String? = null,
        /** The cover as a moving picture, where the label made one. */
        val motionUrl: String? = null,
        /**
         * The other catalogue has been asked and has not answered yet.
         *
         * The header holds its picture back while this is true. Spotify's cover
         * is already in hand and could be drawn at once, but on a page that is
         * about to have a different photograph that only means opening on the
         * wrong one and swapping it out in front of the reader. The wait is
         * capped; see dressPage.
         */
        val heroPending: Boolean = false,
        /** The artist's name drawn in their own face; see AppleCatalog. */
        val logoUrl: String? = null,
        val latest: ArtistRelease? = null,
        /**
         * Whether that record is already in the library.
         *
         * Null while unknown, and the "+" on the card is then absent — the same
         * rule the save button on every other page follows.
         */
        val latestSaved: Boolean? = null,
        /** How many accounts follow them, and what Spotify files them under. */
        val followers: Int = 0,
        val genres: List<String> = emptyList(),
        /**
         * Whether this account follows them.
         *
         * Null while unknown, which is not the same as false: a button drawn as
         * "follow" before the answer arrives is a button that lies for a second
         * and then corrects itself in front of the reader.
         */
        val following: Boolean? = null,
        /**
         * Empty because nobody has been allowed to look, rather than because
         * there is nothing there.
         *
         * Only the phone's own music can be in this state; see openLocalFiles.
         */
        val needsPermission: Boolean = false,
        /** YouTube's count of the channel's subscribers, as it words it. */
        val subscribers: String? = null,
        /** An artist page's rows in the source's own order; see ArtistShelf. */
        val shelves: List<dev.lelonio.square.data.ArtistShelf> = emptyList(),
        /** Where the top songs' "see all" leads, when the source has a list for it. */
        val topSongsMoreUri: String? = null,
        /** The playlist's Spotify Mix, when it was mixed in Spotify's app; see Mixes. */
        val mix: dev.lelonio.square.playback.Mixes.PlaylistMix? = null,
        /** Whether the mix is on here: it plays, and the page shows it. */
        val mixOn: Boolean = false,
        /** Tempo and key of the songs, by URI, once a mix is on; see Mixes. */
        val audioAttributes: Map<String, dev.lelonio.square.playback.Mixes.Attributes> = emptyMap(),
    )

    private val container get() = getApplication<SquareApplication>()

    /** The app's own text, which lives in resources so it can be translated. */
    private fun string(@StringRes id: Int, vararg args: Any): String =
        getApplication<SquareApplication>().getString(id, *args)

    private var inFlight: Job? = null
    private var playlistJob: Job? = null

    // Signed out is a Spotify state. The other source works without an account
    // and has its library loading from the start, and reading only Spotify's
    // login here put a Spotify sign-in button on the YouTube Music library until
    // the first refresh replaced it, or for good when that refresh never came.
    private val _state = MutableStateFlow<UiState>(
        when {
            container.activeBackend.id != BackendId.SPOTIFY -> UiState.Loading
            container.spotifySignedIn -> UiState.Connecting
            else -> UiState.LoggedOut
        },
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    /**
     * The home feed's catalogue sections.
     *
     * Everything here comes from the Web API and therefore needs the user's own
     * application, so an empty feed is an ordinary state rather than an error:
     * the rest of the home page — playlists, what was played — works without it.
     */
    data class FeedState(
        val newReleases: List<SearchItem> = emptyList(),
        val topArtists: List<SearchItem> = emptyList(),
        /** On repeat this month. */
        val topTracks: List<CatalogTrack> = emptyList(),
        /** What the account has come back to over the years. */
        val allTimeTracks: List<CatalogTrack> = emptyList(),
        /** Records the artists the account listens to have put out lately. */
        val fromYourArtists: List<SearchItem> = emptyList(),
        /** Playlists and albums the account played last, on any device. */
        val jumpBackIn: List<SearchItem> = emptyList(),
        val loading: Boolean = false,
    )

    /**
     * What is out, arranged the way a "new" page is read.
     *
     * Separate from [FeedState] and loaded only when the tab is opened: the
     * home page needs a dozen records for one shelf, and this needs forty of
     * them split by date plus a song out of each of the first few. Making the
     * home feed carry all that would spend it on every cold start for a page
     * most sessions never open.
     */
    data class NewPage(
        /** The few records the page leads with, drawn large. */
        val hero: List<SearchItem> = emptyList(),
        /** Out in the last seven days. */
        val thisWeek: List<SearchItem> = emptyList(),
        /** Everything else Spotify calls new, newest first. */
        val recent: List<SearchItem> = emptyList(),
        /** One song out of each of the first few records above. */
        val songs: List<CatalogTrack> = emptyList(),
        val loading: Boolean = false,
    )

    private val _newPage = MutableStateFlow(NewPage())
    val newPage: StateFlow<NewPage> = _newPage.asStateFlow()
    private var newPageJob: Job? = null

    data class FollowedReleaseState(
        val albums: List<dev.lelonio.square.data.AlbumDto> = emptyList(),
        val loading: Boolean = false,
        val loaded: Boolean = false,
        val artistCount: Int = 0,
        val completed: Int = 0,
        val failedArtists: Int = 0,
        val error: String? = null,
    )
    private val followedReleaseRepository by lazy {
        dev.lelonio.square.data.FollowedReleases(
            container.api,
            java.io.File(getApplication<SquareApplication>().cacheDir, "followed-releases"),
            container.gateway,
        )
    }
    private val _followedReleases = MutableStateFlow(FollowedReleaseState())
    val followedReleases = _followedReleases.asStateFlow()
    private var followedReleaseJob: Job? = null
    private var followedReleaseLoadedAt = 0L

    fun loadFollowedReleases(force: Boolean = false) {
        if (container.activeBackend.id != BackendId.SPOTIFY || followedReleaseJob?.isActive == true) return
        if (!force && _followedReleases.value.loaded && System.currentTimeMillis() - followedReleaseLoadedAt < 15 * 60 * 1_000L) return
        if (!container.webApi.isReady) {
            _followedReleases.value = FollowedReleaseState(error = string(R.string.followed_releases_connect))
            return
        }
        _followedReleases.value = _followedReleases.value.copy(loading = true, completed = 0, error = null)
        followedReleaseJob = viewModelScope.launch {
            try {
                // The last answer straight away, while this one is worked out:
                // reading every followed artist takes seconds, and the row and
                // the cards at the top waited on it with nothing to show.
                if (_followedReleases.value.albums.isEmpty()) {
                    followedReleaseRepository.saved()?.let { saved ->
                        _followedReleases.value = _followedReleases.value.copy(
                            albums = saved.albums, artistCount = saved.artistCount,
                        )
                    }
                }
                val result = followedReleaseRepository.load(force) { done, total ->
                    _followedReleases.value = _followedReleases.value.copy(completed = done, artistCount = total)
                }
                _followedReleases.value = FollowedReleaseState(
                    albums = result.albums, loaded = true, artistCount = result.artistCount,
                    failedArtists = result.failedArtists,
                )
                followedReleaseLoadedAt = if (result.failedArtists == 0) System.currentTimeMillis() else 0L
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                android.util.Log.w(TAG, "followed releases unavailable: ${describe(e)}")
                _followedReleases.value = _followedReleases.value.copy(loading = false, error = string(
                    if (e is HttpException && e.code() in listOf(401, 403)) R.string.followed_releases_connect else R.string.followed_releases_error,
                ))
            }
        }
    }

    private fun resetFollowedReleases() {
        followedReleaseJob?.cancel()
        followedReleaseJob = null
        followedReleaseLoadedAt = 0L
        _followedReleases.value = FollowedReleaseState()
    }

    /**
     * Fills the new-releases tab, once.
     *
     * Reloaded only when it is empty: records do not come out while somebody is
     * switching tabs, and rebuilding the page under the reader every time they
     * come back to it would move what they were about to tap.
     */
    fun loadNewPage() {
        if (!container.webApi.isReady || newPageJob?.isActive == true) return
        if (_newPage.value.recent.isNotEmpty() || _newPage.value.thisWeek.isNotEmpty()) return

        _newPage.value = _newPage.value.copy(loading = true)
        newPageJob = viewModelScope.launch {
            // Three pages rather than one. Fifty is what this endpoint will
            // answer with at a time, and one page of it is two shelves' worth
            // on a page that is meant to be browsed — the whole complaint about
            // this tab was that it ended almost as soon as it started.
            val albums = runCatching {
                withContext(Dispatchers.IO) {
                    coroutineScope {
                    (0 until NEW_PAGES).map { page ->
                        async {
                            container.api
                                .newReleases(limit = NEW_RELEASES, offset = page * NEW_RELEASES)
                                .albums?.items.orEmpty()
                        }
                    }.awaitAll().flatten()
                    }
                }
            }
                .onFailure { android.util.Log.w(TAG, "new releases unavailable: ${describe(it)}") }
                .getOrDefault(emptyList())
                .distinctBy { it.uri }
                .sortedByDescending { it.releaseDate.orEmpty() }

            val week = java.time.LocalDate.now().minusDays(7).toString()
            fun item(album: dev.lelonio.square.data.AlbumDto): SearchItem? = SearchItem(
                uri = album.uri ?: return null,
                title = album.name,
                subtitle = album.artists.joinToString(", ") { it.name },
                artworkUrl = album.images.firstOrNull()?.url,
            )

            val thisWeek = albums.filter { (it.releaseDate ?: "") >= week }.mapNotNull(::item)
            val rest = albums.filter { (it.releaseDate ?: "") < week }.mapNotNull(::item)

            // The records by the artists this account listens to lead the page,
            // because "new" without "to you" is a catalogue. The global list is
            // the fallback for an account too young to have artists of its own.
            val mine = _feed.value.fromYourArtists
            // Turned over daily, like the radio page's stations: the six the
            // page leads with are drawn from a list that changes slowly, and
            // showing the same six until it does made a page that is supposed
            // to be about what is out look like it had stopped.
            val leading = (if (mine.isNotEmpty()) mine else thisWeek + rest)
            val hero = leading.turnedDaily().take(HERO_RELEASES)

            _newPage.value = NewPage(
                hero = hero,
                thisWeek = thisWeek,
                recent = rest,
                loading = false,
            )

            // And a song out of each of the first few, which is the one part of
            // the page that has to be heard rather than looked at. Resolved
            // through the access point rather than the Web API: this is a track
            // list for a context, which is exactly what that side answers, and
            // it does not come out of the account's own quota.
            if (!awaitEngine()) return@launch
            val songs = withContext(Dispatchers.IO) {
                coroutineScope {
                (thisWeek + rest).turnedDaily().take(NEW_SONGS).map { album ->
                    async {
                        runCatching {
                            Catalog.tracks(Catalog.contextTrackUris(album.uri).take(1)).firstOrNull()
                        }.getOrNull()
                    }
                }.awaitAll().filterNotNull()
                }
            }
            _newPage.value = _newPage.value.copy(songs = songs)
        }
    }

    private val _feed = MutableStateFlow(FeedState())
    val feed: StateFlow<FeedState> = _feed.asStateFlow()
    private var feedJob: Job? = null

    /** YouTube Music's own home page, as it laid it out; see [MusicBackend.homeFeed]. */
    data class YouTubeHomeState(
        val rows: List<HomeRow> = emptyList(),
        val chips: List<HomeChip> = emptyList(),
        /** Which filter is on, by title; null is the home page itself. */
        val chip: String? = null,
        val loading: Boolean = false,
        /** A page after the first, on its way. */
        val loadingMore: Boolean = false,
        val error: String? = null,
        /** Where the next shelves are; null when the page has run out. */
        val cursor: String? = null,
        /**
         * How many of the filter chips have been read as further pages once
         * the page itself ran out. YouTube's home stops after twenty-odd
         * shelves; the chips (Energize, Party, Commute...) are whole pages of
         * their own, so reading them one after another keeps the scroll going.
         */
        val extraChips: Int = 0,
    ) {
        /** True while there are more shelves to ask for. */
        val hasMore: Boolean get() =
            cursor != null || (chip == null && extraChips < chips.size)
    }

    private val _youtubeHome = MutableStateFlow(YouTubeHomeState())
    val youtubeHome: StateFlow<YouTubeHomeState> = _youtubeHome.asStateFlow()
    private var youtubeHomeJob: Job? = null

    /** One of the other two tabs when the source is not Spotify; see [MusicBackend.newRows]. */
    data class SourceRowsState(
        val rows: List<HomeRow> = emptyList(),
        val loading: Boolean = false,
    )

    private val _sourceNew = MutableStateFlow(SourceRowsState())
    val sourceNew: StateFlow<SourceRowsState> = _sourceNew.asStateFlow()
    private val _sourceRadio = MutableStateFlow(SourceRowsState())
    val sourceRadio: StateFlow<SourceRowsState> = _sourceRadio.asStateFlow()
    private var sourceNewJob: Job? = null
    private var sourceRadioJob: Job? = null

    /**
     * The New tab for a source that lays its own out. Read once a session: it
     * is the same page for anyone in the country and moves once a week.
     */
    fun loadSourceNew() {
        if (container.activeBackend.id == BackendId.SPOTIFY) return
        if (sourceNewJob?.isActive == true || _sourceNew.value.rows.isNotEmpty()) return
        _sourceNew.value = _sourceNew.value.copy(loading = true)
        sourceNewJob = viewModelScope.launch {
            val rows = runCatching { container.activeBackend.newRows() }.getOrDefault(emptyList())
            _sourceNew.value = SourceRowsState(rows = rows, loading = false)
        }
    }

    /** And the Radio tab; see [loadSourceNew]. */
    fun loadSourceRadio() {
        if (container.activeBackend.id == BackendId.SPOTIFY) return
        if (sourceRadioJob?.isActive == true || _sourceRadio.value.rows.isNotEmpty()) return
        _sourceRadio.value = _sourceRadio.value.copy(loading = true)
        sourceRadioJob = viewModelScope.launch {
            val rows = runCatching { container.activeBackend.radioRows() }.getOrDefault(emptyList())
            _sourceRadio.value = SourceRowsState(rows = rows, loading = false)
        }
    }

    /**
     * Loads it, once per sign-in state.
     *
     * Re-read after signing in rather than cached for the session: the page is
     * a different page once YouTube knows whose it is, and leaving the
     * signed-out one up would make the login look like it did nothing.
     */
    fun loadYouTubeHome(force: Boolean = false) {
        val backend = container.activeBackend
        if (backend.id != BackendId.YOUTUBE_MUSIC) return
        if (youtubeHomeJob?.isActive == true) return
        if (!force && _youtubeHome.value.rows.isNotEmpty()) return

        youtubeParams = null
        _youtubeHome.value = _youtubeHome.value.copy(loading = true, error = null, chip = null)
        youtubeHomeJob = viewModelScope.launch { readYouTubeHome(replace = true) }
    }

    /**
     * The next shelves, asked for as the page runs out.
     *
     * The home page is served four or five shelves at a time and the list is
     * what says when more are wanted, so this is called from the bottom of it
     * rather than on a timer: what the listener never scrolls to is never
     * fetched.
     */
    fun loadMoreYouTubeHome() {
        val state = _youtubeHome.value
        if (!state.hasMore || state.loading || state.loadingMore) return
        if (youtubeHomeJob?.isActive == true) return

        _youtubeHome.value = state.copy(loadingMore = true)
        youtubeHomeJob = viewModelScope.launch { readYouTubeHome(replace = false) }
    }

    /**
     * Picks one of the filters above the page, or clears it.
     *
     * The chips are the service's own views of the same home — "Relax",
     * "Workout" — and each is a page in its own right, continuation and all,
     * so choosing one starts over rather than filtering what is already here.
     */
    fun selectYouTubeChip(chip: HomeChip?) {
        if (chip?.title == _youtubeHome.value.chip) return
        youtubeHomeJob?.cancel()
        youtubeParams = chip?.params
        _youtubeHome.value = _youtubeHome.value.copy(
            rows = emptyList(),
            chip = chip?.title,
            loading = true,
            loadingMore = false,
            error = null,
        )
        youtubeHomeJob = viewModelScope.launch { readYouTubeHome(replace = true) }
    }

    private var youtubeParams: String? = null

    private suspend fun readYouTubeHome(replace: Boolean) {
        val backend = container.activeBackend
        val before = _youtubeHome.value
        // Past the end of the page itself: the next filter chip's page is read
        // in its place and added below, so the list does not simply stop.
        val viaChip = !replace && before.cursor == null && before.chip == null
        val pickedChip = if (viaChip) before.chips.getOrNull(before.extraChips) else null
        runCatching {
            backend.homeFeed(
                cursor = if (replace) null else before.cursor,
                params = if (viaChip) pickedChip?.params else youtubeParams,
            )
        }
            .onSuccess { feed ->
                val added = if (viaChip) {
                    feed.rows.filter { row -> before.rows.none { it.title == row.title } }
                } else {
                    feed.rows
                }
                val rows = if (replace) feed.rows else before.rows + added
                _youtubeHome.value = before.copy(
                    extraChips = when {
                        replace -> 0
                        viaChip -> before.extraChips + 1
                        else -> before.extraChips
                    },
                    rows = rows,
                    // A continuation carries no chips, so the ones already on
                    // screen stay where they are.
                    chips = feed.chips.ifEmpty { before.chips },
                    loading = false,
                    loadingMore = false,
                    error = null,
                    cursor = if (viaChip) null else feed.cursor,
                )
            }
            .onFailure {
                if (it is kotlinx.coroutines.CancellationException) throw it
                android.util.Log.e(TAG, "youtube home failed: ${chain(it)}", it)
                _youtubeHome.value = before.copy(
                    loading = false,
                    loadingMore = false,
                    // A page that failed after the first leaves what is already
                    // read on screen: the shelves above it are still good.
                    error = if (before.rows.isEmpty()) describe(it) else null,
                    cursor = if (replace) null else before.cursor,
                    // A chip that fails is skipped, not asked for again forever.
                    extraChips = if (viaChip) before.extraChips + 1 else before.extraChips,
                )
            }
    }

    /**
     * Loads the feed, quietly.
     *
     * Each section is fetched on its own and a failure drops just that section:
     * top artists need the `user-top-read` scope, and an account that connected
     * its application before that scope was asked for answers 403 there while
     * everything else still works. One combined call would lose the lot.
     */
    fun loadFeed() {
        if (!container.webApi.isReady || feedJob?.isActive == true) return
        if (_feed.value.newReleases.isNotEmpty()) return

        _feed.value = _feed.value.copy(loading = true)
        feedJob = viewModelScope.launch {
            val releases = runCatching {
                container.api.newReleases().albums?.items.orEmpty().mapNotNull { album ->
                    SearchItem(
                        uri = album.uri ?: return@mapNotNull null,
                        title = album.name,
                        subtitle = album.artists.joinToString(", ") { it.name },
                        artworkUrl = album.images.firstOrNull()?.url,
                    )
                }
            }.onFailure { android.util.Log.w(TAG, "new releases unavailable: ${describe(it)}") }
                .getOrDefault(emptyList())

            val artists = runCatching {
                container.api.topArtists().items.mapNotNull { artist ->
                    SearchItem(
                        uri = artist.uri ?: return@mapNotNull null,
                        title = artist.name,
                        subtitle = string(R.string.artist),
                        artworkUrl = artist.images.firstOrNull()?.url,
                    )
                }
            }.onFailure { android.util.Log.w(TAG, "top artists unavailable: ${describe(it)}") }
                .getOrDefault(emptyList())

            val onRepeat = topTracks("short_term")
            val allTime = topTracks("long_term")

            // Built from the artists the account actually listens to rather
            // than from the catalogue-wide new releases above: those are the
            // same for everyone, and half of them are records the account would
            // never open.
            val fresh = freshFromArtists(artists)

            val jumpBackIn = jumpBackIn()

            _feed.value = FeedState(
                newReleases = releases,
                topArtists = artists,
                topTracks = onRepeat,
                allTimeTracks = allTime,
                fromYourArtists = fresh,
                jumpBackIn = jumpBackIn,
                loading = false,
            )
        }
    }

    /**
     * The same list, started at a different place each day.
     *
     * Not a shuffle: a page that rearranges itself every time it is opened is
     * not richer, it is unreadable. This moves the starting point once a day,
     * so a list that Spotify itself only recomputes weekly still shows
     * something different when the tab is opened tomorrow.
     */
    private fun <T> List<T>.turnedDaily(): List<T> {
        if (size < 2) return this
        val day = java.time.LocalDate.now().toEpochDay().toInt()
        val from = Math.floorMod(day * DAILY_TURN, size)
        return drop(from) + take(from)
    }

    private suspend fun topTracks(range: String): List<CatalogTrack> = runCatching {
        container.api.topTracks(timeRange = range).items.map { it.toCatalogTrack() }
    }.onFailure { android.util.Log.w(TAG, "top tracks ($range) unavailable: ${describe(it)}") }
        .getOrDefault(emptyList())

    /**
     * Records from the account's own artists, newest first.
     *
     * One request per artist, so only the first few are asked: this runs on the
     * home page's first load and a dozen round trips would be felt. Anything
     * older than a year is dropped — "new from artists you listen to" that
     * opens on a 2019 album is just a discography.
     */
    private suspend fun freshFromArtists(artists: List<SearchItem>): List<SearchItem> {
        val cutoff = java.time.LocalDate.now().minusMonths(12).toString()
        // All of them at once. One request per artist is what this costs
        // whatever happens, but asked in turn a dozen of them is several
        // seconds of the home page waiting on a shelf that is not even the
        // first thing on it.
        return coroutineScope {
            artists.take(FRESH_ARTISTS).map { artist ->
                async(Dispatchers.IO) {
                    runCatching {
                        container.api.artistAlbums(
                            artist.uri.substringAfterLast(':'),
                            limit = 6,
                        ).items
                    }.getOrDefault(emptyList())
                }
            }.awaitAll().flatten()
        }
            .filter { (it.releaseDate ?: "") >= cutoff }
            .sortedByDescending { it.releaseDate }
            .distinctBy { it.uri }
            .mapNotNull { album ->
                SearchItem(
                    uri = album.uri ?: return@mapNotNull null,
                    title = album.name,
                    subtitle = album.artists.joinToString(", ") { it.name }
                        .ifBlank { album.releaseDate?.take(4).orEmpty() },
                    artworkUrl = album.images.firstOrNull()?.url,
                )
            }
    }

    /**
     * Where the account was listening last, on any device.
     *
     * The history gives the *context* a track was played from but not its name
     * or its cover, and resolving each one would be a request apiece. Albums
     * carry both on the track itself, and a playlist of the account's own is
     * already in the rootlist — so those two are shown and anything else (an
     * editorial playlist, a radio) is left out rather than guessed at.
     */
    private suspend fun jumpBackIn(): List<SearchItem> = runCatching {
        val mine = (_state.value as? UiState.Ready)?.playlists.orEmpty().associateBy { it.uri }
        container.api.recentlyPlayed().items.mapNotNull { play ->
            val context = play.context?.uri
            when {
                context != null && mine.containsKey(context) -> mine[context]?.let {
                    SearchItem(it.uri, it.name, string(R.string.playlist), it.artworkUrl)
                }

                context != null && context.startsWith("spotify:album:") ->
                    play.track.album?.let { album ->
                        SearchItem(
                            uri = context,
                            title = album.name,
                            subtitle = play.track.artists.joinToString(", ") { it.name },
                            artworkUrl = album.images.firstOrNull()?.url,
                        )
                    }

                else -> null
            }
        }.distinctBy { it.uri }.take(FEED_ROW)
    }.onFailure { android.util.Log.w(TAG, "play history unavailable: ${describe(it)}") }
        .getOrDefault(emptyList())

    /** The Spotify Connect device picker. */
    data class DevicesState(
        val open: Boolean = false,
        val loading: Boolean = false,
        /**
         * The device being switched to, while the switch is in flight.
         *
         * A handover takes a moment and used to look like nothing at all, so
         * the row was pressed again and again.
         */
        val switchingTo: String? = null,
        val devices: List<SpotifyDevice> = emptyList(),
        val error: String? = null,
    )

    data class SpotifyDevice(
        val id: String,
        val name: String,
        val type: String,
        val isActive: Boolean,
    )

    private val _devices = MutableStateFlow(DevicesState())
    val devices: StateFlow<DevicesState> = _devices.asStateFlow()
    private var devicesJob: Job? = null

    init {
        followKeptYouTube()
        // A video in an open list, put right as its song is found; see
        // YouTubeBackend.asSongs, which opens the list without waiting for all.
        viewModelScope.launch {
            container.youtubeBackend.conversions.collect { (videoUri, song) ->
                val open = _playlist.value
                if (open.tracks.none { it.uri == videoUri }) return@collect
                _playlist.value = open.copy(
                    tracks = open.tracks.map { if (it.uri == videoUri) song else it },
                )
            }
        }
        // Offline and back, without a restart in between.
        //
        // The library and the home page are each built once, from whichever
        // source was available at the time, and nothing rebuilt them when that
        // changed: a phone that found signal again went on showing the handful
        // of downloaded playlists, and one that lost it went on offering rows
        // it could no longer fetch. Both directions are the same event, so both
        // are handled here.
        //
        // The current value is skipped — the first load is already on its way
        // when this starts, and running it twice would be two libraries built
        // at once.
        viewModelScope.launch {
            dev.lelonio.square.playback.OfflineMode.active
                .drop(1)
                .distinctUntilChanged()
                .collectLatest { offline ->
                    if (offline && dev.lelonio.square.playback.OfflineMode.reason.value != dev.lelonio.square.playback.OfflineMode.Reason.MANUAL) {
                        // Only an offline that lasts. The session drops for a
                        // moment often enough, on starting up or changing
                        // network, and taking Spotify's own shelves off the home
                        // page for it showed them for a few seconds and then the
                        // app's fallback page in their place. Back within this,
                        // nothing here runs: collectLatest drops it.
                        kotlinx.coroutines.delay(OFFLINE_SETTLE_MS)
                    }
                    android.util.Log.i(TAG, "offline changed to $offline: rebuilding")
                    if (offline) {
                        // What needed a connection goes now rather than staying
                        // as rows that answer nothing when tapped. The shelves
                        // are kept aside, to come back if they cannot be asked
                        // for again.
                        _feed.value = FeedState()
                        if (_homeShelves.value.isNotEmpty()) shelvesBeforeOffline = _homeShelves.value
                        _homeShelves.value = emptyList()
                        _friends.value = emptyList()
                    }
                    // Waited for, not merely started. The library load is
                    // what waits for the session to come back up, and
                    // everything below reads that session: fired alongside it
                    // they all asked while the handshake was still in flight,
                    // failed quietly, and were never tried again — which is why
                    // coming back online left the app's own shelves on the home
                    // page and none of Spotify's.
                    refresh(restart = true).join()
                    if (!offline) {
                        loadFeed()
                        loadHomeShelves()
                        loadFriends()
                    }
                }
        }

        // The list, kept true by the engine rather than by asking.
        //
        // The Web API answers this too, but only when asked, so a sheet left
        // open while playback moved went on showing the old active device until
        // it was closed and opened again. The cluster arrives on its own from
        // the session's own socket, and it is the same list.
        viewModelScope.launch {
            dev.lelonio.square.data.RemoteConnect.devices.collect { cluster ->
                if (cluster.isEmpty()) return@collect
                _devices.value = _devices.value.copy(
                    loading = false,
                    error = null,
                    devices = ordered(
                        cluster.map { device ->
                            SpotifyDevice(
                                id = device.id,
                                name = named(device.id, device.name),
                                type = device.type,
                                isActive = device.active,
                            )
                        },
                    ),
                )
            }
        }
    }

    /**
     * The devices in an order that does not move: this phone first, then by
     * name. The cluster sends them in a different order every few seconds, and
     * a list reshuffled under the finger sent the music to whichever row had
     * just slid into the place the listener was tapping.
     */
    private fun ordered(devices: List<SpotifyDevice>): List<SpotifyDevice> =
        devices.sortedWith(
            compareByDescending<SpotifyDevice> { dev.lelonio.square.data.RemoteConnect.isThisPhone(it.id) }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
                .thenBy { it.id },
        )

    /**
     * This app's own entry, said to be this app. Spotify's official app on the
     * same phone carries the same model name, and two identical rows are a
     * coin toss.
     */
    private fun named(id: String, name: String): String =
        if (dev.lelonio.square.data.RemoteConnect.isThisPhone(id)) string(R.string.device_this_app, name) else name

    fun openDevices() {
        _devices.value = _devices.value.copy(open = true)
        refreshDevices()
    }

    fun closeDevices() {
        _devices.value = _devices.value.copy(open = false)
    }

    /**
     * Reads the account's device list.
     *
     * Needs `user-read-playback-state`, which an application connected before
     * this feature existed was never asked for — hence the explicit message
     * rather than a bare 403.
     */
    fun refreshDevices() {
        devicesJob?.cancel()
        if (!container.webApi.isReady) {
            _devices.value = _devices.value.copy(
                loading = false,
                error = string(R.string.needs_your_app),
            )
            return
        }

        _devices.value = _devices.value.copy(loading = true, error = null)
        devicesJob = viewModelScope.launch {
            runCatching { container.api.devices().devices }
                .onSuccess { list ->
                    // The engine's own list wins once it has one. The Web API
                    // leaves out speakers it considers asleep (a Sonos, mostly),
                    // and replacing the list with its answer when the sheet
                    // opened took the very speaker being reached for off it.
                    if (dev.lelonio.square.data.RemoteConnect.devices.value.isNotEmpty()) {
                        _devices.value = _devices.value.copy(loading = false)
                        return@onSuccess
                    }
                    _devices.value = _devices.value.copy(
                        loading = false,
                        devices = ordered(
                            list.mapNotNull { device ->
                                SpotifyDevice(
                                    // A device with no id cannot be addressed, so it
                                    // is dropped rather than shown as a dead row.
                                    id = device.id ?: return@mapNotNull null,
                                    name = named(device.id, device.name),
                                    type = device.type,
                                    isActive = device.isActive,
                                )
                            },
                        ),
                    )
                }
                .onFailure {
                    android.util.Log.e(TAG, "devices failed: ${chain(it)}", it)
                    _devices.value = _devices.value.copy(
                        loading = false,
                        error = describe(it),
                    )
                }
        }
    }

    /** Moves playback to another device, keeping it playing. */
    /**
     * Moves playback to another device.
     *
     * Through the engine when the device came from the cluster, which is the
     * same road the official clients take and needs no registered Web API
     * application. The Web API is the fallback for a list that came from it.
     */
    /**
     * What the player needs in order to carry on here what another device was
     * playing: the same queue, the same track, the same second.
     */
    data class ResumeHere(
        val tracks: List<CatalogTrack>,
        val index: Int,
        val contextUri: String?,
        val positionMs: Long,
    )

    private val _resumeHere = MutableSharedFlow<ResumeHere>(extraBufferCapacity = 1)

    /** Emitted when the listener asks for the music to come back to this phone. */
    val resumeHere = _resumeHere.asSharedFlow()

    /**
     * Brings the account's playback back to this phone.
     *
     * Not a transfer: a device cannot address a command to itself, and taking
     * the session on its own only makes this one active and silent, which is
     * exactly what choosing Square in the list used to do. A handover has to
     * carry the music with it, so the context the other device was playing is
     * reopened here, at the track it was on, at the position it had reached.
     *
     * A device playing something with no context, a single track started from a
     * search, leaves nothing to reopen: the track alone is the queue.
     */
    private fun takeBackPlayback() = viewModelScope.launch {
        // Whatever the account is playing, wherever it thinks it is playing it.
        //
        // Reading only the "somewhere else" half meant the request quietly did
        // nothing whenever the engine had already decided this phone was
        // active: choosing Square answered with silence and no explanation.
        val remote = dev.lelonio.square.data.RemoteConnect.playback.value
            ?: dev.lelonio.square.data.RemoteConnect.here.value
        if (remote == null) {
            android.util.Log.i(TAG, "nothing to bring back: the account is playing nothing")
            return@launch
        }

        android.util.Log.i(
            TAG,
            "taking playback back: ${remote.uri} from ${remote.realContext} at ${remote.positionMs}",
        )

        // The music first, the list afterwards.
        //
        // This used to resolve the whole context before a note was played,
        // which on a long playlist is a second or two in which nothing happens
        // and the listener, quite reasonably, presses the button again. The
        // queue on screen fills itself in from the state this publishes; see
        // PlaybackService.adoptRemoteQueue.
        val started = withContext(Dispatchers.IO) {
            runCatching {
                NativeBridge.resumeHere(
                    remote.realContext.orEmpty(),
                    remote.uri,
                    remote.positionMs.toInt(),
                )
            }.onFailure { android.util.Log.w(TAG, "could not resume here: $it") }.isSuccess
        }
        if (started) {
            // The account will not say this phone is active now; see
            // RemoteConnect.refresh, which works it out from the engine.
            withContext(Dispatchers.IO) { runCatching { dev.lelonio.square.data.RemoteConnect.refresh() } }
            return@launch
        }

        // The engine refused it. Fall back to opening the context the long way,
        // which is slower but asks nothing of the Connect layer.
        val context = remote.realContext
        val tracks = runCatching {
            if (context != null) container.activeBackend.tracksOf(context) else emptyList()
        }
            .onFailure { android.util.Log.w(TAG, "context unreadable: ${describe(it)}") }
            .getOrDefault(emptyList())

        val index = tracks.indexOfFirst { it.uri == remote.uri }
        if (tracks.isEmpty() || index < 0) {
            val single = runCatching { container.activeBackend.tracksOf(remote.uri) }
                .getOrDefault(emptyList())
                .ifEmpty { return@launch }
            _resumeHere.emit(ResumeHere(single, 0, null, remote.positionMs))
            return@launch
        }

        _resumeHere.emit(ResumeHere(tracks, index, context, remote.positionMs))
    }

    fun transferPlayback(deviceId: String, positionMs: Long = 0L) = viewModelScope.launch {
        if (_devices.value.switchingTo != null) return@launch
        _devices.value = _devices.value.copy(switchingTo = deviceId)
        try {
            switchTo(deviceId, positionMs)
        } finally {
            _devices.value = _devices.value.copy(switchingTo = null)
        }
    }

    private suspend fun switchTo(deviceId: String, positionMs: Long) {
        val devices = dev.lelonio.square.data.RemoteConnect.devices.value
        android.util.Log.i(TAG, "device chosen: $deviceId, ${devices.size} known")
        // Asked of the engine rather than looked up in the list: the list is
        // filled by cluster updates and is empty until the first one arrives,
        // and a handover chosen in that window took the wrong road entirely.
        if (dev.lelonio.square.data.RemoteConnect.isThisPhone(deviceId)) {
            takeBackPlayback().join()
            return
        }
        // The queue is republished as the playlist it came from first, so
        // whatever carries the handover has something resolvable to carry; see
        // NativeBridge.publishContext.
        if (!dev.lelonio.square.data.RemoteConnect.elsewhereActive.value) {
            val republished = withContext(Dispatchers.IO) {
                runCatching { NativeBridge.publishContext(positionMs.toInt()) }
                    .onFailure { android.util.Log.w(TAG, "context not republished: $it") }
                    .getOrDefault(false)
            }
            // Only when something actually changed does Spotify need a moment
            // to see it. A queue that already carried its playlist goes over at
            // once, which is nearly every handover.
            if (republished) delay(TRANSFER_SETTLE_MS)
        }

        // Spotify's own transfer, when the account has an application to ask it
        // with. The dealer command below is the same word without the state:
        // its `data` field is the playback being moved, and building that is
        // Spotify's job in this call. Sent without it, the device does become
        // active and has nothing to play, which is a progress bar advancing over
        // silence and controls that answer to nothing.
        if (!container.webApi.isReady) {
            withContext(Dispatchers.IO) {
                dev.lelonio.square.data.RemoteConnect.transferTo(deviceId)
            }
            return
        }

        runCatching { container.api.transferPlayback(TransferRequestDto(listOf(deviceId))) }
            .onSuccess {
                // Spotify reports the move a beat after acknowledging it, so the
                // list is re-read rather than edited optimistically.
                delay(TRANSFER_SETTLE_MS)
                // Named, not assumed: a transfer that lands on a device which
                // then sits there paused is the one failure this cannot see
                // from here, and asking the device by name to play costs one
                // request that is harmless when it is playing already.
                runCatching { container.api.play(deviceId) }
                    .onFailure { android.util.Log.i(TAG, "play on $deviceId: ${describe(it)}") }
                refreshDevices()
            }
            .onFailure {
                android.util.Log.e(TAG, "transfer failed: ${chain(it)}", it)
                _devices.value = _devices.value.copy(error = describe(it))
            }
    }

    /**
     * The "add to playlist" sheet.
     *
     * Replaces the heart the player used to have. Liked Songs is one playlist
     * out of the account's several and the button spent its whole width saying
     * so; asking which playlist is the same gesture and answers the question the
     * heart could not.
     */
    data class AddToPlaylistState(
        val open: Boolean = false,
        /** The track the sheet will add, captured when it opens. */
        val trackUri: String? = null,
        /**
         * Every track to add, when the sheet adds a whole record or list
         * rather than one song; empty for one song.
         */
        val batch: List<String> = emptyList(),
        val trackTitle: String = "",
        val playlists: List<CatalogPlaylist> = emptyList(),
        /** URI of the playlist currently being written to. */
        val busy: String? = null,
        /** Name of the playlist the track just went into. */
        val done: String? = null,
        /** And of the one it just came out of, which only Liked Songs can be. */
        val removed: String? = null,
        /**
         * Whether the track is already in Liked Songs.
         *
         * The one row in this list whose answer is known, and the one that can
         * be undone: picking it again takes the track back out.
         */
        val liked: Boolean = false,
        /**
         * The listener's playlists the track is known to be in already.
         *
         * Ticked in the list, and picking one takes the track out: the same as
         * Liked Songs, and the only way left to take a song out of the list it
         * is playing from without going to that list.
         */
        val containing: Set<String> = emptySet(),
        val error: String? = null,
    )

    private val _addToPlaylist = MutableStateFlow(AddToPlaylistState())
    val addToPlaylist: StateFlow<AddToPlaylistState> = _addToPlaylist.asStateFlow()

    /**
     * @param asSheet whether to show the modal. False from the player, which
     *   shows the same picker in its own panel and would otherwise get both.
     */
    fun openAddToPlaylist(
        trackUri: String?,
        trackTitle: String,
        asSheet: Boolean = true,
        /** What the track is playing from, when it is; see [AddToPlaylistState.containing]. */
        contextUri: String? = null,
    ) {
        // The other source writes through its own account, to the lists it
        // says can be written to; they are asked for as the sheet opens.
        val backend = container.activeBackend
        if (backend.id != BackendId.SPOTIFY) {
            val writable = trackUri != null && backend.owns(trackUri) && backend.canEditPlaylists
            _addToPlaylist.value = AddToPlaylistState(
                open = asSheet,
                trackUri = trackUri,
                trackTitle = trackTitle,
                error = if (writable) null else string(R.string.track_cannot_be_added),
            )
            if (writable) viewModelScope.launch {
                val lists = runCatching { backend.writablePlaylists() }
                    .onFailure { android.util.Log.w(TAG, "writable playlists unavailable: ${describe(it)}") }
                    .getOrDefault(emptyList())
                if (_addToPlaylist.value.trackUri == trackUri) {
                    _addToPlaylist.value = _addToPlaylist.value.copy(playlists = lists)
                }
            }
            return
        }
        _addToPlaylist.value = AddToPlaylistState(
            open = asSheet,
            trackUri = trackUri,
            trackTitle = trackTitle,
            playlists = (_state.value as? UiState.Ready)?.playlists.orEmpty(),
            liked = trackUri != null && container.likedStore.isLiked(trackUri),
            error = when {
                trackUri == null || !(trackUri.startsWith("spotify:track:") ||
                    LocalLibrary.isLocal(trackUri) || LocalLibrary.isSpotifyLocal(trackUri)) ->
                    string(R.string.track_cannot_be_added)
                !container.webApi.isReady && !container.tokenStore.isLoggedIn ->
                    string(R.string.connect_app_in_settings)
                else -> null
            },
        )
            if (trackUri != null) viewModelScope.launch {
            val own = _addToPlaylist.value.playlists.map { it.uri }.toSet()
            val cached = runCatching { container.contextCache.playlistsWith(trackUri) }.getOrDefault(emptySet())
            // The list it is playing from counts even when it has not been
            // read into the cache, as long as it is one of the listener's.
            val playing = contextUri?.takeIf { it.startsWith("spotify:playlist:") }
            val open = _playlist.value.uri?.takeIf { uri -> _playlist.value.tracks.any { it.uri == trackUri } }
            val containing = (cached + listOfNotNull(playing, open)).filterTo(mutableSetOf()) { it in own }
            if (_addToPlaylist.value.trackUri == trackUri) {
                _addToPlaylist.value = _addToPlaylist.value.copy(containing = containing)
            }
        }
    }

    /**
     * The same sheet for a whole album or list: every one of its songs goes
     * into the playlist picked, in order. Nothing is taken out by picking a
     * playlist twice, as one song is: with dozens of them that would be a
     * second tap undoing a first by surprise.
     */
    fun openAddAllToPlaylist(tracks: List<CatalogTrack>, title: String) {
        val backend = container.activeBackend
        val uris = tracks.map { it.uri }.filter {
            if (backend.id == BackendId.SPOTIFY) it.startsWith("spotify:track:") || it.startsWith("spotify:episode:")
            else backend.owns(it)
        }.distinct()
        _addToPlaylist.value = AddToPlaylistState(
            open = true,
            trackUri = uris.firstOrNull(),
            batch = uris,
            trackTitle = title,
            playlists = if (backend.id == BackendId.SPOTIFY) {
                (_state.value as? UiState.Ready)?.playlists.orEmpty()
            } else {
                emptyList()
            },
            error = when {
                uris.isEmpty() -> string(R.string.track_cannot_be_added)
                backend.id == BackendId.SPOTIFY && !container.webApi.isReady && !container.tokenStore.isLoggedIn ->
                    string(R.string.connect_app_in_settings)
                backend.id != BackendId.SPOTIFY && !backend.canEditPlaylists ->
                    string(R.string.track_cannot_be_added)
                else -> null
            },
        )
        if (backend.id != BackendId.SPOTIFY && uris.isNotEmpty()) viewModelScope.launch {
            val lists = runCatching { backend.writablePlaylists() }.getOrDefault(emptyList())
            if (_addToPlaylist.value.batch == uris) _addToPlaylist.value = _addToPlaylist.value.copy(playlists = lists)
        }
    }

    /** [openAddAllToPlaylist]'s songs, into [playlist]. */
    private fun addAllToPlaylist(playlist: CatalogPlaylist, uris: List<String>) {
        _addToPlaylist.value = _addToPlaylist.value.copy(busy = playlist.uri, done = null, removed = null, error = null)
        viewModelScope.launch {
            runCatching {
                when {
                    // Liked Songs: the account's library, kept in one request.
                    playlist.uri.endsWith(":collection") ->
                        check(container.gateway.setInLibrary(uris, keep = true)) { "the gateway refused" }
                    playlist.uri.startsWith("spotify:playlist:") -> {
                        val id = playlist.uri.substringAfterLast(':')
                        // A hundred a request is the most Spotify takes.
                        uris.chunked(100).forEach { chunk ->
                            container.api.addToPlaylist(id, AddTracksRequestDto(chunk))
                        }
                    }
                    else -> uris.forEach { container.activeBackend.addToPlaylist(playlist.uri, it) }
                }
            }
                .onSuccess {
                    _addToPlaylist.value = _addToPlaylist.value.copy(busy = null, done = playlist.name)
                    _inPlaylists.value = _inPlaylists.value + uris
                    invalidateContext(playlist.uri)
                    if (playlist.uri.endsWith(":collection")) uris.forEach(container.likedStore::add)
                }
                .onFailure {
                    android.util.Log.e(TAG, "adding a whole list failed: ${chain(it)}", it)
                    val forbidden = describe(it).contains("403")
                    if (forbidden) _webApi.value = _webApi.value.copy(expired = true)
                    _addToPlaylist.value = _addToPlaylist.value.copy(
                        busy = null,
                        error = if (forbidden) string(R.string.permission_needed) else string(R.string.add_failed, playlist.name),
                    )
                }
        }
    }

    /**
     * A file on this phone, or a playlist's local entry, put into a playlist.
     *
     * Written as Spotify's own apps write it — a `spotify:local:` entry built
     * from the file's tags — and through the playlist service, since the Web
     * API refuses anything that is not a catalogue track. Every device of the
     * account then shows it, playable wherever there is a matching file.
     */
    private fun addLocalToPlaylist(playlist: CatalogPlaylist, trackUri: String) {
        _addToPlaylist.value = _addToPlaylist.value.copy(busy = playlist.uri, done = null, removed = null, error = null)
        viewModelScope.launch {
            runCatching {
                val entry = if (LocalLibrary.isSpotifyLocal(trackUri)) {
                    trackUri
                } else {
                    val files = deviceFiles.ifEmpty { LocalLibrary.tracks(getApplication()).also { deviceFiles = it } }
                    val file = files.firstOrNull { it.uri == trackUri } ?: error("$trackUri is not on this phone")
                    LocalLibrary.spotifyUri(file).also { uri ->
                        // Playable at once from the playlist, without waiting
                        // for its page to be matched again.
                        file.localFile?.let { path -> dev.lelonio.square.data.LocalFileBindings.bind(mapOf(uri to path)) }
                    }
                }
                withContext(Dispatchers.IO) {
                    dev.lelonio.square.nativecore.NativeBridge.addToPlaylist(playlist.uri, entry)
                }
            }.onSuccess {
                _addToPlaylist.value = _addToPlaylist.value.copy(busy = null, done = playlist.name)
                _inPlaylists.value = _inPlaylists.value + trackUri
                invalidateContext(playlist.uri)
                if (_playlist.value.uri == playlist.uri) openPlaylist(playlist)
            }.onFailure {
                android.util.Log.e(TAG, "add local file to playlist failed: ${chain(it)}", it)
                _addToPlaylist.value = _addToPlaylist.value.copy(
                    busy = null,
                    error = string(R.string.add_failed, playlist.name),
                )
            }
        }
    }

    fun closeAddToPlaylist() {
        _addToPlaylist.value = _addToPlaylist.value.copy(open = false)
    }

    /**
     * Appends the captured track to [playlist].
     *
     * Not optimistic, unlike the heart it replaces: this writes to something the
     * user keeps, the result is a row appearing in a list rather than a filled
     * icon, and there is nothing to undo it with if the call turns out to have
     * failed. So the sheet waits, then says which playlist it went into.
     */
    fun addToPlaylist(playlist: CatalogPlaylist) {
        val current = _addToPlaylist.value
        val trackUri = current.trackUri ?: return
        if (current.busy != null) return
        val id = playlist.uri.substringAfterLast(':')

        if (current.batch.isNotEmpty()) {
            addAllToPlaylist(playlist, current.batch)
            return
        }

        if (playlist.uri.startsWith("spotify:playlist:") &&
            (LocalLibrary.isLocal(trackUri) || LocalLibrary.isSpotifyLocal(trackUri))
        ) {
            addLocalToPlaylist(playlist, trackUri)
            return
        }

        if (!playlist.uri.startsWith("spotify:")) {
            _addToPlaylist.value =
                current.copy(busy = playlist.uri, done = null, removed = null, error = null)
            viewModelScope.launch {
                runCatching { container.activeBackend.addToPlaylist(playlist.uri, trackUri) }
                    .onSuccess {
                        _addToPlaylist.value = _addToPlaylist.value.copy(busy = null, done = playlist.name)
                        _inPlaylists.value = _inPlaylists.value + trackUri
                        invalidateContext(playlist.uri)
                        if (_playlist.value.uri == playlist.uri) openPlaylist(playlist)
                    }
                    .onFailure {
                        android.util.Log.e(TAG, "add to playlist failed: ${chain(it)}", it)
                        _addToPlaylist.value = _addToPlaylist.value.copy(
                            busy = null,
                            error = string(R.string.add_failed, playlist.name),
                        )
                    }
            }
            return
        }

        // Liked Songs is in this list like any other, and is the one entry that
        // is not a playlist: it is the account's library, saved to by its own
        // endpoint. Picking it is what puts the heart on the track, and picking
        // anything else is what puts the tick there.
        val toLibrary = playlist.uri.endsWith(":collection")
        // Picking Liked Songs when the track is already there takes it out
        // again: the heart is the one mark in this list that can be undone,
        // and pressing it twice is how everything else undoes a like.
        val unsaving = toLibrary && current.liked

        if (toLibrary) {
            _addToPlaylist.value = current.copy(
                busy = playlist.uri,
                done = null,
                removed = null,
                error = null,
            )
            toggleLike(trackUri, current.trackTitle, playlistName = playlist.name)
            return
        }

        // Already in it: the tick in that row is taken back, as the heart is.
        if (playlist.uri in current.containing) {
            _addToPlaylist.value =
                current.copy(busy = playlist.uri, done = null, removed = null, error = null)
            viewModelScope.launch {
                runCatching {
                    container.api.removeFromPlaylist(id, RemoveTracksRequestDto(listOf(TrackUriDto(trackUri))))
                }
                    .onSuccess {
                        val left = _addToPlaylist.value.containing - playlist.uri
                        _addToPlaylist.value = _addToPlaylist.value.copy(
                            busy = null,
                            removed = playlist.name,
                            containing = left,
                        )
                        if (left.isEmpty()) _inPlaylists.value = _inPlaylists.value - trackUri
                        _takenOut.value = _takenOut.value + "${playlist.uri}|$trackUri"
                        invalidateContext(playlist.uri)
                        if (_playlist.value.uri == playlist.uri) {
                            _playlist.value = _playlist.value.copy(
                                tracks = _playlist.value.tracks.filterNot { it.uri == trackUri },
                            )
                        }
                    }
                    .onFailure {
                        android.util.Log.e(TAG, "remove from playlist failed: ${chain(it)}", it)
                        _addToPlaylist.value = _addToPlaylist.value.copy(
                            busy = null,
                            error = string(R.string.remove_failed, playlist.name),
                        )
                    }
            }
            return
        }

        _addToPlaylist.value =
            current.copy(busy = playlist.uri, done = null, removed = null, error = null)
        viewModelScope.launch {
            runCatching {
                container.api.addToPlaylist(id, AddTracksRequestDto(listOf(trackUri)))
            }
                .onSuccess {
                    _addToPlaylist.value = _addToPlaylist.value.copy(
                        busy = null,
                        done = playlist.name,
                        removed = null,
                        containing = _addToPlaylist.value.containing + playlist.uri,
                    )
                    _takenOut.value = _takenOut.value - "${playlist.uri}|$trackUri"
                    // Known at once, rather than when that playlist is next
                    // read: the tick is about the track, and the track is in a
                    // playlist from this moment.
                    _inPlaylists.value = _inPlaylists.value + trackUri
                    // The detail screen holds a list resolved before this track
                    // was in it; if that is the playlist just written to, read
                    // it again.
                    invalidateContext(playlist.uri)
                    if (_playlist.value.uri == playlist.uri) openPlaylist(playlist)
                }
                .onFailure {
                    android.util.Log.e(TAG, "add to playlist failed: ${chain(it)}", it)
                    val forbidden = describe(it).contains("403")
                    if (forbidden) _webApi.value = _webApi.value.copy(expired = true)
                    _addToPlaylist.value = _addToPlaylist.value.copy(
                        busy = null,
                        error = when {
                            forbidden -> string(R.string.permission_needed)
                            else -> string(R.string.add_failed, playlist.name)
                        },
                    )
                }
        }
    }

    private val _playlist = MutableStateFlow(PlaylistState())
    val playlist: StateFlow<PlaylistState> = _playlist.asStateFlow()

    /** Search box contents and results. */
    data class SearchState(
        val query: String = "",
        val loading: Boolean = false,
        val results: SearchResults = SearchResults(),
        val error: String? = null,
        /**
         * Set when a search had nowhere to go, so the screen can offer the way
         * out instead of an empty page.
         *
         * Rare now: Spotify's own gateway answers anyone who is signed in, and
         * only a retired query hash sends a search back to the registered
         * application that used to be the only way in.
         */
        val needsSetup: Boolean = false,
        /** A second helping of the same search, on its way. */
        val loadingMore: Boolean = false,
        /** Set once a page comes back with nothing new to add. */
        val exhausted: Boolean = false,
    )

    private val _search = MutableStateFlow(SearchState())
    val search: StateFlow<SearchState> = _search.asStateFlow()
    private var searchJob: Job? = null

    /** How far into the results the next page starts. */
    private var searchOffset = 0
    private var searchMoreJob: Job? = null

    /**
     * Runs a search, debounced.
     *
     * Firing on every keystroke would spend the Web API quota several times per
     * word, mostly on prefixes nobody wanted results for.
     */
    fun onSearchQuery(query: String) {
        val backend = container.activeBackend
        _search.value = _search.value.copy(query = query)
        searchJob?.cancel()

        searchMoreJob?.cancel()
        searchOffset = 0

        if (query.isBlank()) {
            _search.value = SearchState(query = query)
            return
        }

        val spotifyLink = dev.lelonio.square.data.util.SpotifyLinkParser.parse(query)
        if (spotifyLink != null) {
            searchJob = viewModelScope.launch {
                _search.value = _search.value.copy(loading = true, error = null)
                runCatching {
                    resolveSpotifyLink(spotifyLink)
                }.onSuccess { results ->
                    currentCoroutineContext().ensureActive()
                    _search.value = _search.value.copy(
                        loading = false,
                        results = results,
                        needsSetup = false,
                        loadingMore = false,
                        exhausted = true,
                    )
                }.onFailure {
                    if (it is kotlinx.coroutines.CancellationException) throw it
                    android.util.Log.e(TAG, "resolve link failed: ${chain(it)}", it)
                    _search.value = _search.value.copy(loading = false, error = describe(it))
                }
            }
            return
        }

        searchJob = viewModelScope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            _search.value = _search.value.copy(loading = true, error = null)
            runCatching {
                backend.search(
                    query,
                    SearchLabels(
                        artist = string(R.string.artist),
                        album = string(R.string.album),
                        playlist = string(R.string.playlist),
                        podcast = string(R.string.podcast),
                    ),
                )
            }
                .onSuccess { results ->
                    // The answer to a question nobody is asking any more is
                    // not shown: a slow search that was replaced while it ran
                    // would otherwise land on top of the newer one.
                    currentCoroutineContext().ensureActive()
                    searchOffset = SEARCH_PAGE
                    _search.value = _search.value.copy(
                        loading = false,
                        results = results,
                        needsSetup = backend.searchNeedsSetup,
                        loadingMore = false,
                        exhausted = results.isEmpty,
                    )
                }
                .onFailure {
                    // A cancelled search is not a failed one. Every keystroke
                    // cancels the one before it, and runCatching catches that
                    // like anything else — which put "StandaloneCoroutine was
                    // cancelled" on the page while the next search was already
                    // on its way.
                    if (it is kotlinx.coroutines.CancellationException) throw it
                    android.util.Log.e(TAG, "search failed: ${chain(it)}", it)
                    _search.value = _search.value.copy(loading = false, error = describe(it))
                }
        }
    }

    private suspend fun resolveSpotifyLink(link: dev.lelonio.square.data.util.SpotifyLink): SearchResults =
        withContext(Dispatchers.IO) {
            when (link) {
                is dev.lelonio.square.data.util.SpotifyLink.Track -> {
                    val trackDto = runCatching { container.api.track(link.id) }.getOrNull()
                    if (trackDto != null) {
                        SearchResults(tracks = listOf(trackDto.toCatalogTrack()))
                    } else {
                        val tracks = runCatching { Catalog.tracks(listOf(link.uri)) }.getOrDefault(emptyList())
                        SearchResults(tracks = tracks)
                    }
                }
                is dev.lelonio.square.data.util.SpotifyLink.Album -> {
                    val tracks = runCatching { container.activeBackend.tracksOf(link.uri) }.getOrDefault(emptyList())
                    val albumDto = runCatching { container.api.album(link.id) }.getOrNull()
                    val first = tracks.firstOrNull()
                    val title = albumDto?.name ?: first?.album ?: string(R.string.album)
                    val subtitle = albumDto?.artists?.joinToString { it.name }
                        ?: first?.artist.orEmpty()
                    val artworkUrl = albumDto?.images?.firstOrNull()?.url ?: first?.artworkUrl
                    val albumItem = SearchItem(
                        uri = link.uri,
                        title = title,
                        subtitle = subtitle,
                        artworkUrl = artworkUrl,
                    )
                    SearchResults(albums = listOf(albumItem), tracks = tracks)
                }
                is dev.lelonio.square.data.util.SpotifyLink.Playlist -> {
                    val playlistDto = runCatching { container.api.playlist(link.id) }.getOrNull()
                    val tracks = runCatching { container.activeBackend.tracksOf(link.uri) }.getOrDefault(emptyList())
                    val title = playlistDto?.name ?: string(R.string.playlist)
                    val subtitle = playlistDto?.description.orEmpty().ifBlank { string(R.string.playlist) }
                    val artworkUrl = playlistDto?.images?.firstOrNull()?.url ?: tracks.firstOrNull()?.artworkUrl
                    val item = SearchItem(
                        uri = link.uri,
                        title = title,
                        subtitle = subtitle,
                        artworkUrl = artworkUrl,
                    )
                    SearchResults(playlists = listOf(item), tracks = tracks)
                }
                is dev.lelonio.square.data.util.SpotifyLink.Artist -> {
                    val artistDto = runCatching { container.api.artist(link.id) }.getOrNull()
                    val tracks = runCatching { container.activeBackend.tracksOf(link.uri) }.getOrDefault(emptyList())
                    val title = artistDto?.name ?: tracks.firstOrNull()?.artist ?: string(R.string.artist)
                    val artworkUrl = artistDto?.images?.firstOrNull()?.url ?: tracks.firstOrNull()?.artworkUrl
                    val item = SearchItem(
                        uri = link.uri,
                        title = title,
                        subtitle = string(R.string.artist),
                        artworkUrl = artworkUrl,
                    )
                    SearchResults(artists = listOf(item), tracks = tracks)
                }
            }
        }

    /**
     * The next page of the same search, appended.
     *
     * Called by the list as it nears its end rather than by a button: twenty of
     * each kind is the web player's own page size and a fine first answer, but
     * a search for a name that a hundred records share stopped dead at twenty
     * with no way to see the rest.
     *
     * Appended rather than replaced, and de-duplicated by address: the offset
     * is the server's idea of where the page starts, and a catalogue that has
     * changed under it can hand back a row that is already on the screen.
     */
    fun loadMoreSearch() {
        val state = _search.value
        if (state.query.isBlank() || state.loading || state.loadingMore) return
        if (state.exhausted) return
        val backend = container.activeBackend
        searchMoreJob?.cancel()
        _search.value = state.copy(loadingMore = true)
        searchMoreJob = viewModelScope.launch {
            runCatching {
                backend.search(
                    state.query,
                    SearchLabels(
                        artist = string(R.string.artist),
                        album = string(R.string.album),
                        playlist = string(R.string.playlist),
                        podcast = string(R.string.podcast),
                    ),
                    offset = searchOffset,
                )
            }
                .onSuccess { page ->
                    currentCoroutineContext().ensureActive()
                    // Still the same search: a page that arrives after the box
                    // has been retyped belongs to a question nobody is asking.
                    if (_search.value.query != state.query) return@onSuccess
                    val grown = _search.value.results.plus(page)
                    val added = grown.count - _search.value.results.count
                    searchOffset += SEARCH_PAGE
                    _search.value = _search.value.copy(
                        results = grown,
                        loadingMore = false,
                        exhausted = added == 0,
                    )
                }
                .onFailure {
                    if (it is kotlinx.coroutines.CancellationException) throw it
                    android.util.Log.e(TAG, "search page failed: ${chain(it)}", it)
                    _search.value = _search.value.copy(loadingMore = false, exhausted = true)
                }
        }
    }

    /** The user's own Spotify application, used for search. */
    data class WebApiState(
        val clientId: String = "",
        val connected: Boolean = false,
        val connecting: Boolean = false,
        val error: String? = null,
        /** What the user must register as a redirect URI in their dashboard. */
        val redirectUri: String = SpotifyOAuth.REDIRECT_URI,
        /**
         * Set when Spotify has refused the stored session, so the app can say
         * so and offer the way back in.
         *
         * The client id is already known and does not expire, so signing in
         * again is one tap: nothing has to be pasted or registered a second
         * time.
         */
        val expired: Boolean = false,
    )

    private val _webApi = MutableStateFlow(
        WebApiState(
            clientId = container.webApi.clientId.value.orEmpty(),
            connected = container.webApi.isReady,
        ),
    )
    val webApi: StateFlow<WebApiState> = _webApi.asStateFlow()

    init {
        // Only worth saying while there is a client id to sign in with again:
        // an account that was never connected has its own setup card, and a
        // notice about a session that expired would be about nothing.
        viewModelScope.launch {
            container.webApi.tokens.sessionLost.collect {
                if (container.webApi.clientId.value == null) return@collect
                _webApi.value = _webApi.value.copy(connected = false, expired = true)
            }
        }
    }

    /** The notice is dismissed by hand; search and the feed keep working without it. */
    fun dismissWebApiExpiry() {
        _webApi.value = _webApi.value.copy(expired = false)
    }

    fun onWebApiClientIdChange(value: String) {
        _webApi.value = _webApi.value.copy(clientId = value, error = null)
    }

    /**
     * Registers the client id and runs a second OAuth flow against it.
     *
     * A separate authorization from the playback login by necessity: an access
     * token is only valid for the application it was issued to, so the Web API
     * needs its own even though it is the same Spotify account behind both.
     */
    private var webApiJob: Job? = null

    fun connectWebApi() {
        webApiJob?.takeIf { it.isActive }?.let { return }
        webApiJob = viewModelScope.launch {
            val clientId = _webApi.value.clientId.trim()
            if (clientId.isEmpty()) {
                _webApi.value = _webApi.value.copy(error = string(R.string.enter_client_id))
                return@launch
            }

            _webApi.value = _webApi.value.copy(connecting = true, error = null, expired = false)
        container.webApi.setClientId(clientId)
        runCatching {
            // Search needs no scope — it reads public catalogue data — but the
            // home feed's "artisti che ascolti" is the user's own listening,
            // and that is gated behind `user-top-read`. It is the only
            // permission asked for, and an account connected before this
            // existed keeps working: the section simply stays empty until the
            // application is reconnected.
            SpotifyOAuth.authorize(
                getApplication(),
                clientId = clientId,
                scopes = listOf(
                    // The home feed's "artisti che ascolti".
                    "user-top-read",
                    // Reading what the account has actually played, which is a
                    // different permission from the top artists above.
                    "user-read-recently-played",
                    // The Connect device picker: one to list them, one to move
                    // playback.
                    "user-read-playback-state",
                    "user-modify-playback-state",
                    // The player's "add to playlist". Which of the two
                    // applies is the playlist's own visibility, not the
                    // caller's, so both are asked for.
                    "playlist-modify-private",
                    "playlist-modify-public",
                    // Following artists, and the list of the ones followed.
                    "user-follow-read",
                    "user-follow-modify",
                    // Liked Songs. It sits in the "add to" list like a
                    // playlist, but it is the account's library and takes its
                    // own permission — without this, saving a track answers
                    // 403 and the heart never fills.
                    "user-library-read",
                    "user-library-modify",
                    // A new playlist's cover.
                    "ugc-image-upload",
                ),
            )
        }
            .onSuccess { tokens ->
                runCatching {
                    container.webApi.tokens.save(tokens)
                    _webApi.value = _webApi.value.copy(connecting = false, connected = true)
                    _search.value = _search.value.copy(needsSetup = false)
                    // The feed could not have loaded before this point.
                    loadFeed()
                    // Re-run whatever the user had already typed.
                    _search.value.query.takeIf { q -> q.isNotBlank() }?.let(::onSearchQuery)
                }.onFailure { ex ->
                    android.util.Log.e(TAG, "post-login setup failed: ${chain(ex)}", ex)
                }
            }
            .onFailure {
                android.util.Log.e(TAG, "web api login failed: ${chain(it)}", it)
                _webApi.value = _webApi.value.copy(connecting = false, error = describe(it))
            }
        }
    }

    fun disconnectWebApi() {
        resetFollowedReleases()
        container.webApi.disconnect()
        _webApi.value = _webApi.value.copy(connected = false, error = null)
        // Not needsSetup: search comes from Spotify's own gateway now, and
        // giving up the registered application only gives up the fallback.
    }

    /**
     * Saved effect presets: the built-in ones followed by the user's own.
     *
     * Combined here rather than stored together so the built-ins can be changed
     * or added to in a later version without migrating what the user saved.
     */
    val effectPresets: StateFlow<List<EffectPreset>> =
        container.effectPresets.presets
            .map { BuiltInPresets + it }
            .stateIn(viewModelScope, SharingStarted.Eagerly, BuiltInPresets)

    fun saveEffectPreset(name: String, speed: Float, pitch: Float, reverb: Float) {
        container.effectPresets.save(name, speed, pitch, reverb)
    }

    fun deleteEffectPreset(id: String) = container.effectPresets.delete(id)

    /** Locally recorded listening history; see [dev.lelonio.square.data.RecentStore]. */
    /**
     * Recently played, filtered to the source in use.
     *
     * One list on disk, two catalogues drawing from it: a Spotify URI in the
     * YouTube page is a tile that cannot be played, and the other way round.
     * Filtered rather than kept apart so that switching back finds the history
     * still there.
     */
    private val _friends =
        MutableStateFlow<List<dev.lelonio.square.data.FriendListen>>(emptyList())

    /**
     * What the people this account follows are playing.
     *
     * Kept rather than fetched per screen: it is one request, it changes on its
     * own schedule and not on the app's, and the header shows a corner of it
     * whether or not anybody has opened the list.
     */
    val friends: StateFlow<List<dev.lelonio.square.data.FriendListen>> = _friends.asStateFlow()

    /**
     * Reads the list again.
     *
     * Silent on failure by design. This is a private endpoint with no promises
     * attached, an account may follow nobody, and everybody it follows may be
     * listening privately: all three are the same empty list, and none of them
     * is worth an error on the home page.
     */
    fun loadFriends() = viewModelScope.launch {
        if (container.activeBackend.id != BackendId.SPOTIFY) {
            _friends.value = emptyList()
            return@launch
        }
        if (!awaitEngine()) return@launch
        runCatching { dev.lelonio.square.data.FriendActivity.friends() }
            .onSuccess { _friends.value = it }
            .onFailure { android.util.Log.w(TAG, "friend activity unavailable: ${describe(it)}") }
    }

    /**
     * How adding a friend is going, for the panel that asks for one.
     *
     * Idle until somebody types; a message afterwards, kept until the panel is
     * closed. Following somebody is a write to the account, and a write with no
     * answer is a button people press twice.
     */
    enum class AddFriend { IDLE, WORKING, DONE, FAILED, UNSUPPORTED }

    private val _addFriend = MutableStateFlow(AddFriend.IDLE)
    val addFriendState: StateFlow<AddFriend> = _addFriend.asStateFlow()

    fun clearAddFriend() {
        _addFriend.value = AddFriend.IDLE
    }

    /**
     * Follows a Spotify listener, which is what "adding a friend" is here.
     *
     * By link or username, and only by those: Spotify's search covers tracks,
     * albums, artists and playlists, and has never covered people. So there is
     * nobody to look up — what can be done is take the profile the listener was
     * given, in any of the shapes it arrives in, and follow it.
     *
     * Appearing in the activity list afterwards is a separate matter and not
     * this app's to promise: that list is only ever people who both are
     * followed and have chosen to share what they play.
     */
    fun addFriend(input: String) = viewModelScope.launch {
        val id = friendIdOf(input)
        if (id == null) {
            _addFriend.value = AddFriend.FAILED
            return@launch
        }
        if (!container.webApi.isReady) {
            _addFriend.value = AddFriend.UNSUPPORTED
            return@launch
        }
        _addFriend.value = AddFriend.WORKING
        runCatching { container.api.followArtists(type = "user", ids = id) }
            .onSuccess {
                _addFriend.value = AddFriend.DONE
                loadFriends()
            }
            .onFailure {
                android.util.Log.w(TAG, "could not follow $id: ${describe(it)}")
                _addFriend.value = AddFriend.FAILED
            }
    }

    /**
     * The account id inside whatever was pasted.
     *
     * A profile link, a `spotify:user:` uri, or the username on its own — the
     * three shapes somebody's profile arrives in, from a browser, from the
     * share sheet, and from being read out.
     */
    private fun friendIdOf(input: String): String? {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return null
        val raw = when {
            trimmed.startsWith("spotify:user:") -> trimmed.removePrefix("spotify:user:")
            "open.spotify.com/user/" in trimmed ->
                trimmed.substringAfter("open.spotify.com/user/")
            // Some links carry the locale: /intl-it/user/<id>
            "spotify.com" in trimmed && "/user/" in trimmed -> trimmed.substringAfter("/user/")
            else -> trimmed
        }
        val id = raw.substringBefore('?').substringBefore('/').trim()
        // A username is url-safe text; anything else came from a link this did
        // not understand, and following it would fail with a worse message.
        return id.takeIf { it.isNotEmpty() && it.all { c -> c.isLetterOrDigit() || c in "._-" } }
    }

    private val _videoFileId = MutableStateFlow<String?>(null)

    /**
     * The music video for what is playing, when there is one.
     *
     * Looked up in the catalogue rather than waited for: the account attaches a
     * video's id to a track only for the devices it believes can show one, and
     * it does not believe that of this app however it declares itself. Asking
     * works for anybody. See `catalog.rs`.
     */
    val videoFileId: StateFlow<String?> = _videoFileId.asStateFlow()

    private val _videoMode = MutableStateFlow(false)

    /** Whether the listener has asked to watch rather than listen. */
    val videoMode: StateFlow<Boolean> = _videoMode.asStateFlow()

    private var videoLookup: kotlinx.coroutines.Job? = null

    /** Asked once per track, and forgotten the moment the track changes. */
    fun lookUpVideo(trackUri: String?) {
        videoLookup?.cancel()
        _videoFileId.value = null
        _videoMode.value = false
        if (trackUri == null ||
            !(trackUri.startsWith("spotify:track:") || trackUri.startsWith("spotify:episode:"))
        ) return
        // Offline there is no video to offer: it is streamed, and the lookup
        // itself is a request. Leaving the answer null is what takes the button
        // off the player — the button is drawn from having one.
        if (dev.lelonio.square.playback.OfflineMode.active.value) return
        videoLookup = viewModelScope.launch(Dispatchers.IO) {
            val answer = NativeBridge.trackVideo(trackUri) ?: return@launch
            val fileId = runCatching {
                org.json.JSONObject(answer).optString("fileId").takeIf { it.isNotEmpty() }
            }.getOrNull()
            _videoFileId.value = fileId
        }
    }

    fun toggleVideo() {
        _videoMode.value = !_videoMode.value && _videoFileId.value != null
    }

    val listeningEvents = container.listeningStore.events

    init {
        // The month in music is the one of the source in use.
        viewModelScope.launch {
            container.preferences.backend.collect { backend ->
                container.listeningStore.show(
                    when (backend) {
                        BackendId.SPOTIFY -> dev.lelonio.square.data.ListeningStore.Source.SPOTIFY
                        BackendId.YOUTUBE_MUSIC -> dev.lelonio.square.data.ListeningStore.Source.YOUTUBE_MUSIC
                    },
                )
            }
        }
    }
    private var listeningSync: kotlinx.coroutines.Job? = null
    private var lastListeningSync = 0L

    fun syncListeningHistory() {
        if (listeningSync?.isActive == true || System.currentTimeMillis() - lastListeningSync < 60_000) return
        if (container.preferences.backend.value == dev.lelonio.square.backend.BackendId.YOUTUBE_MUSIC) {
            syncYouTubeListening()
            return
        }
        listeningSync = viewModelScope.launch {
            runCatching {
                val owner = meId ?: runCatching { dev.lelonio.square.nativecore.NativeBridge.username() }
                    .getOrNull()?.takeIf { it.isNotBlank() }
                    ?: container.api.me().id.also { meId = it }
                container.listeningStore.useAccount(owner)
                var before: Long? = null
                // Spotify exposes recent history, not a complete monthly archive.
                // Preserve each import so the archive grows on later visits.
                repeat(5) {
                    val page = container.api.recentlyPlayed(50, before)
                    val plays = page.items.mapNotNull { play ->
                        val at = runCatching { java.time.Instant.parse(play.playedAt).toEpochMilli() }.getOrNull()
                        at?.let { play.track.toCatalogTrack() to it }
                    }
                    container.listeningStore.import(plays, owner)
                    val oldest = plays.minOfOrNull { it.second } ?: return@runCatching
                    if (page.next == null || oldest == before) return@runCatching
                    before = oldest
                }
            }.onSuccess { lastListeningSync = System.currentTimeMillis() }
                .onFailure { android.util.Log.w(TAG, "listening history unavailable: ${describe(it)}") }
        }
    }

    /**
     * Reads the account's YouTube Music history into the month in music.
     *
     * Only while the app is open, as Spotify's is: every few minutes, from the
     * loop in SquareApp. Between two readings a song played again goes back to
     * the top of the page, and that is what is counted; see YouTubeListening.
     */
    private fun syncYouTubeListening() {
        val store = container.listeningStore
        listeningSync = viewModelScope.launch {
            runCatching {
                val sections = container.youtubeBackend.listeningHistory() ?: return@runCatching
                val now = System.currentTimeMillis()
                val last = store.youtubeReading()
                val plays = dev.lelonio.square.data.YouTubeListening.plays(
                    sections = sections,
                    previous = last?.first,
                    previousAt = last?.second ?: now,
                    now = now,
                )
                store.importRemote(plays, dev.lelonio.square.data.ListeningStore.YOUTUBE_OWNER)
                // And which songs already have a heart: the account's liked
                // list, so the heart in the notification starts right.
                runCatching {
                    val liked = container.youtubeBackend.tracksOf(
                        dev.lelonio.square.backend.youtube.YouTubeBackend.LIKED_MUSIC_URI,
                    )
                    container.likedStore.replaceSource(
                        dev.lelonio.square.backend.youtube.YouTubeBackend.TRACK_PREFIX,
                        liked.map { it.uri },
                    )
                }.onFailure { android.util.Log.w(TAG, "youtube likes unavailable: ${describe(it)}") }
                store.keepYoutubeReading(sections.flatMap { it.second }.map { it.uri }, now)
                android.util.Log.i(TAG, "youtube history: ${sections.map { it.first }}, ${plays.size} plays filed")
            }.onSuccess { lastListeningSync = System.currentTimeMillis() }
                .onFailure { android.util.Log.w(TAG, "youtube history unavailable: ${describe(it)}") }
        }
    }

    val recent: StateFlow<List<CatalogTrack>> =
        combine(container.recentStore.tracks, container.preferences.backend) { tracks, _ ->
            // A nameless row is one that was recorded before the session had
            // finished describing the track; see the history effect in
            // SquareApp. (From HectorZL's #19.)
            tracks.filter { it.name.isNotBlank() && container.activeBackend.owns(it.uri) }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Called when a track starts, to keep the home page's history current. */
    fun recordPlayed(track: CatalogTrack) = viewModelScope.launch {
        container.recentStore.record(track)
    }

    /**
     * Songs found by searching and played, newest first.
     *
     * Filtered by the source in use, like [recent]: a Spotify track is not
     * something the YouTube Music backend can play, and offering it would be
     * offering a row that does nothing.
     */
    val searchHistory: StateFlow<List<CatalogTrack>> =
        combine(container.searchHistory.tracks, container.preferences.backend) { tracks, _ ->
            tracks.filter { container.activeBackend.owns(it.uri) }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /**
     * Everything a search led to, newest first — songs, artists, records, lists.
     *
     * The list the search page draws. [searchHistory] is the songs among these,
     * for the places that can only use a song: the radio's seeds, and anything
     * that plays rather than opens.
     */
    val searchTrail: StateFlow<List<dev.lelonio.square.data.SearchHistoryEntry>> =
        combine(container.searchHistory.entries, container.preferences.backend) { entries, _ ->
            entries.filter { container.activeBackend.owns(it.uri) }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _credits =
        MutableStateFlow<dev.lelonio.square.backend.spotify.SpotifyCredits.Credits?>(null)

    /**
     * Who made the track on screen, once somebody asks.
     *
     * Fetched when the panel is opened rather than with the track: it is a page
     * most listeners never look at, and a request per song for it would be a
     * request per song nobody wanted.
     */
    val credits: StateFlow<dev.lelonio.square.backend.spotify.SpotifyCredits.Credits?> =
        _credits.asStateFlow()

    private val _creditsLoading = MutableStateFlow(false)
    val creditsLoading: StateFlow<Boolean> = _creditsLoading.asStateFlow()

    private var creditsFor: String? = null
    private var creditsJob: Job? = null

    /** Asked for the open track; a repeat for the same one is free. */
    fun loadCredits(trackUri: String?) {
        val youtube = trackUri?.startsWith(dev.lelonio.square.backend.youtube.YouTubeBackend.TRACK_PREFIX) == true
        if (trackUri == null || (!trackUri.startsWith("spotify:track:") && !youtube)) {
            creditsJob?.cancel()
            creditsFor = null
            _credits.value = null
            _creditsLoading.value = false
            return
        }
        if (creditsFor == trackUri && (_credits.value != null || _creditsLoading.value)) return

        creditsJob?.cancel()
        creditsFor = trackUri
        _credits.value = null
        _creditsLoading.value = true
        creditsJob = viewModelScope.launch {
            val found = if (youtube) {
                dev.lelonio.square.backend.youtube.YouTubeCredits.of(trackUri)
            } else {
                dev.lelonio.square.backend.spotify.SpotifyCredits.of(trackUri)
            }
            if (creditsFor == trackUri) {
                _credits.value = found
                _creditsLoading.value = false
            }
        }
    }

    /** Called when a search result is played, rather than when a track starts. */
    fun recordSearchPlay(track: CatalogTrack) = viewModelScope.launch {
        container.searchHistory.record(track)
    }

    /** And when a search result that is a page rather than a song is opened. */
    fun recordSearchOpen(item: dev.lelonio.square.data.SearchItem) = viewModelScope.launch {
        container.searchHistory.record(
            dev.lelonio.square.data.SearchHistoryEntry(
                uri = item.uri,
                title = item.title,
                subtitle = item.subtitle,
                artworkUrl = item.artworkUrl,
            ),
        )
    }

    fun forgetSearchPlay(uri: String) = viewModelScope.launch {
        container.searchHistory.remove(uri)
    }

    fun clearSearchHistory() = viewModelScope.launch {
        container.searchHistory.clear()
    }

    init {
        // Everything on screen belongs to one source, so a change of source
        // starts the app's data over rather than patching it: the library, the
        // feed, the search results, the open detail page and the recent list all
        // describe a catalogue that is no longer the one being used.
        viewModelScope.launch {
            container.preferences.backend.drop(1).collect { reload() }
        }

        if (container.activeBackend.id != BackendId.SPOTIFY) {
            // No engine to authenticate, so nothing to send the service.
            //
            // Once this object is whole, not from inside its construction.
            // The view model's scope runs on the main thread straight away, so
            // a load that did not have to wait for anything (nobody signed in,
            // a library already at hand) went on into the saved albums and the
            // followed artists, whose fields are declared further down this
            // class and were still null: the app closed as it opened.
            viewModelScope.launch(Dispatchers.Main) { refresh() }
        } else if (container.spotifySignedIn) {
            PlaybackService.connect(app)
            refresh()
        }
    }

    private var loginJob: Job? = null

    fun logIn() {
        loginJob?.takeIf { it.isActive }?.let { return }
        loginJob = viewModelScope.launch {
            _state.value = UiState.Loading
            runCatching { SpotifyOAuth.authorize(getApplication()) }
                .onSuccess {
                    container.tokenStore.save(it)
                    // The service was created before this session existed, so it has
                    // to be told to authenticate the native engine now.
                    PlaybackService.connect(getApplication())
                    refresh()
                }
                .onFailure {
                    if (it is kotlinx.coroutines.CancellationException) return@launch
                    android.util.Log.e(TAG, "login failed: ${chain(it)}", it)
                    _state.value = UiState.Failed(describe(it))
                }
        }
    }

    /** Retries login if not signed in yet, or refreshes the library if signed in. */
    fun retryFailed() {
        if (!container.spotifySignedIn && container.activeBackend.id == BackendId.SPOTIFY) {
            logIn()
        } else {
            refresh()
        }
    }

    fun logOut() {
        loginJob?.cancel()
        SpotifyOAuth.cancelActiveAuthorization()
        container.tokenStore.clear()
        resetFollowedReleases()
        container.webApi.disconnect()
        container.spotifySdkAccount.disconnect()
        getApplication<android.app.Application>().getSharedPreferences("square_keys", android.content.Context.MODE_PRIVATE)
            .edit().remove("account_refused").apply()
        dev.lelonio.square.playback.websdk.WebSdkRecovery.refresh(getApplication())
        // The engine's own credential too, or the next launch would log itself
        // back in with it and signing out would mean nothing.
        dev.lelonio.square.auth.EngineCredentials.clear(getApplication())
        container.recentStore.clear()
        listeningSync?.cancel()
        lastListeningSync = 0L
        viewModelScope.launch { container.listeningStore.clear() }
        container.playlistOrder.clear()
        // Somebody else's library must not be sitting in the cache when the
        // next account signs in.
        contextCache.clear()
        viewModelScope.launch { container.contextCache.clear() }
        librarySnapshotFile().delete()
        _playlist.value = PlaylistState()
        _feed.value = FeedState()
        // Signed out of Spotify while playing from somewhere else leaves that
        // source exactly as usable as it was: its library is read again rather
        // than replaced with a screen asking to sign in to Spotify.
        if (container.activeBackend.id != BackendId.SPOTIFY) {
            refresh()
            return
        }
        _state.value = UiState.LoggedOut
    }

    /** Starts over on the newly chosen source; see the note in `init`. */
    private fun reload() {
        resetFollowedReleases()
        inFlight?.cancel()
        feedJob?.cancel()
        searchJob?.cancel()
        contextCache.clear()
        _playlist.value = PlaylistState()
        _feed.value = FeedState()
        _search.value = SearchState()
        _youtubeHome.value = YouTubeHomeState()
        sourceNewJob?.cancel()
        sourceRadioJob?.cancel()
        _sourceNew.value = SourceRowsState()
        _sourceRadio.value = SourceRowsState()
        _state.value = UiState.Loading
        if (container.activeBackend.id == BackendId.SPOTIFY && container.spotifySignedIn) {
            PlaybackService.connect(getApplication())
        }
        refresh()
        if (container.activeBackend.id == BackendId.SPOTIFY) {
            // The home page's own sections, which nothing else asks for again:
            // the screen is already composed, so its one-shot load will not run
            // a second time.
            loadFeed()
        } else {
            loadYouTubeHome(force = true)
        }
    }

    /**
     * @param restart throws away a load already running rather than joining it.
     *   A load waiting on a connection that has since come or gone is waiting
     *   on the wrong thing: joined, it kept the library on the downloads after
     *   the session was back, since every later call waited for the stuck one.
     */
    fun refresh(restart: Boolean = false): Job {
        if (restart) inFlight?.cancel()
        inFlight?.takeIf { it.isActive }?.let { return it }
        return launchRefresh().also { inFlight = it }
    }

    /**
     * The library as it was last read, kept on disk so the app opens on it.
     *
     * A start used to be a spinner until Spotify answered, and with signal but
     * no data it never did. Now the page is the listener's own library from
     * the first frame, and Spotify's answer, when it comes, replaces it.
     */
    @kotlinx.serialization.Serializable
    private data class LibrarySnapshot(val displayName: String, val playlists: List<CatalogPlaylist>, val avatarUrl: String? = null)

    private fun librarySnapshotFile() = java.io.File(getApplication<SquareApplication>().filesDir, "library-snapshot.json")

    private suspend fun readLibrarySnapshot(): UiState.Ready? = withContext(Dispatchers.IO) {
        runCatching {
            val kept = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
                .decodeFromString<LibrarySnapshot>(librarySnapshotFile().readText())
            UiState.Ready(kept.displayName, withLocalFiles(kept.playlists), kept.avatarUrl)
        }.getOrNull()
    }

    private suspend fun keepLibrarySnapshot(ready: UiState.Ready) = withContext(Dispatchers.IO) {
        runCatching {
            librarySnapshotFile().writeText(
                kotlinx.serialization.json.Json.encodeToString(
                    LibrarySnapshot.serializer(),
                    LibrarySnapshot(ready.displayName, ready.playlists, ready.avatarUrl),
                ),
            )
        }
    }

    private fun launchRefresh() = viewModelScope.launch {
        val backend = container.activeBackend
        if (backend.id != BackendId.SPOTIFY) {
            // Offline, the downloads are the library here as they are for
            // Spotify. Asked for its playlists, this backend can only fail, and
            // the page was left with the two shelves of the phone's own music
            // and none of the playlists downloaded for exactly this (issue #88).
            //
            // With nothing downloaded too: the page is then the phone's own
            // music, and nothing else. It went on to ask the service, which
            // with signal and no data never answers, so the button that says
            // "switch to offline mode" put the same spinner back.
            if (dev.lelonio.square.playback.OfflineMode.active.value) {
                val known = (backend.authState.value as? BackendAuthState.LoggedIn)?.displayName
                _state.value = offlineLibrary()
                    ?.let { it.copy(displayName = known.orEmpty().ifEmpty { it.displayName }) }
                    ?: UiState.Ready(displayName = known.orEmpty(), playlists = withLocalFiles(emptyList()))
                return@launch
            }
            // No access point to wait for and no Premium account to check: this
            // backend is usable at once, and signing in only adds the library.
            _state.value = UiState.Loading
            // Before the library is asked for: a session that has come loose
            // reads as an empty library otherwise, with nothing on screen to
            // say the account is the thing that needs attention.
            //
            // Both bounded, as Spotify's are: with signal and no data neither
            // answers, and the page waited on them for as long as it was open.
            runCatching { withTimeout(LIBRARY_TIMEOUT_MS) { backend.refreshAuth() } }
            val name = (backend.authState.value as? BackendAuthState.LoggedIn)?.displayName
            runCatching { withTimeout(LIBRARY_TIMEOUT_MS) { backend.playlists() } }
                .onSuccess { playlists ->
                    _state.value = UiState.Ready(
                        displayName = name.orEmpty(),
                        playlists = withLocalFiles(playlists),
                    )
                }
                .onFailure {
                    android.util.Log.w(TAG, "youtube library unavailable: ${describe(it)}")
                    // Not a failure worth a whole error screen: the library is
                    // the one part that needs an account, and everything else
                    // on this backend works without one. What was downloaded is
                    // still listed, since that much needs no connection.
                    _state.value = offlineLibrary()
                        ?.let { it.copy(displayName = name.orEmpty().ifEmpty { it.displayName }) }
                        ?: UiState.Ready(displayName = name.orEmpty(), playlists = withLocalFiles(emptyList()))
                }
            // The other two shelves of the same library. They read the active
            // backend and empty themselves for one that keeps neither, which is
            // also what clears Spotify's off the screen when the source changes.
            loadSavedAlbums()
            loadFollowedArtists()
            loadSavedShows()
            return@launch
        }

        if (!container.spotifySignedIn) {
            _state.value = UiState.LoggedOut
            return@launch
        }

        // Offline, there is nothing to wait for.
        //
        // The wait below is for a session to come up, and it ends either when
        // one does or after thirty seconds. Neither happens with the network
        // gone: the engine is up, it simply has no session, so the spinner sat
        // there for several seconds before the downloads appeared — the one
        // moment the app should be quickest, since everything it is about to
        // show is already on the phone.
        if (dev.lelonio.square.playback.OfflineMode.active.value) {
            offlineLibrary()?.let {
                _state.value = it
                return@launch
            }
        }

        // The library last read, at once, while the session comes up; see
        // LibrarySnapshot. Only online: offline the page is the downloads.
        val snapshot = readLibrarySnapshot()
        _state.value = snapshot ?: UiState.Connecting
        if (!awaitEngine()) {
            // No session, so Spotify's shelves are not coming from this load.
            homeShelvesSettled.value = true
            // A library with no session is not an empty library. Everything
            // that was downloaded is still here and still playable, and the
            // shelf for it is the one thing the listener came for.
            offlineLibrary()?.let {
                _state.value = it
                return@launch
            }
            _state.value = if (container.spotifySignedIn) {
                UiState.Failed(string(R.string.cannot_connect))
            } else {
                UiState.LoggedOut
            }
            return@launch
        }

        if (snapshot == null) _state.value = UiState.Loading
        // Bounded: with signal and no data these calls were left hanging, and
        // the page with them, for as long as the app was open.
        runCatching {
            withTimeout(LIBRARY_TIMEOUT_MS) { UiState.Ready(Catalog.username(), playlists()) }
        }
            .onSuccess {
                _state.value = it
                keepLibrarySnapshot(it)
                loadProfile()
                loadMissingCovers()
                // Spotify's own shelves, once there is a session to ask with.
                loadHomeShelves()
                loadFriends()
                loadFollowedArtists()
                loadSavedAlbums()
                loadSavedShows()
                // The pictures of whatever is downloaded, while there is a
                // connection to fetch them with.
                keepPageCovers()
                catchUpDownloads()
            }
            .onFailure {
                if (it is CancellationException && it !is kotlinx.coroutines.TimeoutCancellationException) throw it
                android.util.Log.e(TAG, "library load failed: ${chain(it)}", it)
                // The same fallback: the session came up but the catalogue
                // could not be read, and the downloads are unaffected by that.
                // The library last read stays if it is on screen, and the read
                // is tried again in a while rather than never.
                if (snapshot == null) _state.value = offlineLibrary() ?: UiState.Failed(describe(it))
                viewModelScope.launch {
                    kotlinx.coroutines.delay(LIBRARY_RETRY_MS)
                    if (_state.value !is UiState.LoggedOut) refresh()
                }
            }
    }

    /**
     * Fills in the profile name and picture.
     *
     * Separate from the library load and allowed to fail quietly: the page is
     * already on screen with the account name by the time this runs, and an
     * account with no Web API application connected simply keeps it.
     */
    /**
     * The library as the download index knows it, for when Spotify cannot be
     * asked.
     *
     * Built from the labels stored beside every download — name, cover, kind —
     * rather than from the context cache, which expires and holds only the last
     * few things opened. A download is meant to outlive both, and a phone in a
     * tunnel should find its playlists exactly where it left them.
     *
     * Null when there is nothing downloaded, which is the one case where an
     * error really is the honest answer.
     */
    /**
     * Fetches the covers of downloaded pages that have none yet.
     *
     * Not left to the download queue, which is where the songs' own covers are
     * filled in: that queue only runs while there is something to download, so
     * a library that is already complete never starts it and the pages kept
     * their blank tiles for ever. This is a handful of images against a
     * library's worth of audio, so it can simply be done.
     *
     * Online only, and quietly: a failure here means a tile stays drawn.
     */
    private fun keepPageCovers() = viewModelScope.launch {
        if (dev.lelonio.square.playback.OfflineMode.active.value) return@launch
        val owners = container.downloads.owners.value.keys
        if (owners.isEmpty()) return@launch
        withContext(Dispatchers.IO) {
            owners.forEach { uri ->
                val url = container.downloads.labelOf(uri)?.artworkUrl ?: return@forEach
                if (dev.lelonio.square.download.DownloadExtras.fileOf(url, "art") != null) {
                    return@forEach
                }
                runCatching { dev.lelonio.square.download.DownloadExtras.keep(url, "art") }
            }
        }
    }

    /**
     * Starts the queue when something downloaded is still short of its extras.
     *
     * A download is meant to carry its sleeve, its tall picture, its words and
     * its Canvas, and songs fetched by an earlier build carry none of those.
     * The queue catches them up on its own — but only while it is running, and
     * it only runs while there is audio owed, so a library that is complete
     * would never have started it. This is that missing nudge, once per launch
     * and only when there is really something to fetch.
     */
    private fun catchUpDownloads() = viewModelScope.launch {
        if (dev.lelonio.square.playback.OfflineMode.active.value) return@launch
        val wanting = withContext(Dispatchers.IO) {
            runCatching { container.downloadQueue.anythingMissing() }.getOrDefault(false)
        }
        if (wanting) DownloadService.start(getApplication())
    }

    private suspend fun offlineLibrary(): UiState.Ready? {
        container.downloads.load()
        val owners = container.downloads.owners.value
        val labelled = owners.keys.mapNotNull { uri ->
            container.downloads.labelOf(uri)?.let {
                CatalogPlaylist(uri = uri, name = it.name, artworkUrl = it.artworkUrl)
            }
        }
        // Everything on the phone, not only the songs downloaded on their own.
        //
        // It was the loose ones at first, which is what the store calls them —
        // and a shelf named "downloaded songs" holding one of the hundred and
        // ninety on the phone is a shelf that lies. The playlists are listed
        // beside it either way, so this is the one place that answers "what can
        // I play right now" without picking through them.
        val everything = labelled
        if (everything.isEmpty() && container.downloads.files.value.isEmpty()) return null

        android.util.Log.i(TAG, "offline library: ${everything.size} downloaded")
        // The name and the picture from the last time there was a connection.
        // They cost nothing to keep and their absence reads as being signed
        // out, which is not what has happened.
        val (name, avatar) = container.preferences.profile()
        // The downloaded music shelf belongs here as much as it does online.
        return UiState.Ready(name, withLocalFiles(everything), avatarUrl = avatar)
    }

    /**
     * The account's library, as the active backend assembles it.
     *
     * This used to build the Spotify list itself, which is why it went on
     * showing the old one: the backend is where the access point, the Web API
     * fallback and Liked Songs are put together, and a second copy here simply
     * missed everything added there.
     */
    private suspend fun playlists(): List<CatalogPlaylist> =
        withLocalFiles(container.activeBackend.playlists())

    /**
     * The phone's own music and downloaded music, at the head of whichever library is on screen.
     */
    private fun withLocalFiles(playlists: List<CatalogPlaylist>): List<CatalogPlaylist> =
        listOf(
            CatalogPlaylist(
                uri = LocalLibrary.CONTEXT_URI,
                name = string(R.string.local_files),
                artworkUrl = LocalLibrary.COVER,
            ),
            CatalogPlaylist(
                uri = DownloadStore.SINGLES,
                name = string(R.string.downloaded_tracks),
                artworkUrl = dev.lelonio.square.ui.components.DOWNLOADS_COVER,
            ),
        ) + dev.lelonio.square.data.PlaylistCovers.apply(
            playlists.filterNot { it.uri == DownloadStore.SINGLES || it.uri == LocalLibrary.CONTEXT_URI },
        )
            .distinctBy { it.uri }

    /** Covers already looked up, so a second visit to the home page is free. */
    private val coverCache = mutableMapOf<String, String>()

    /**
     * Fills in the covers the rootlist did not carry.
     *
     * Spotify's own playlists — the editorial ones, the daily mixes — keep their
     * art on the playlist rather than in the account's index of it, so those
     * tiles came out blank while the user's own were fine. One lookup each,
     * after the page is already on screen, and a failure just leaves the
     * generated tile in place.
     */
    private fun loadMissingCovers() = viewModelScope.launch {
        val ready = _state.value as? UiState.Ready ?: return@launch
        // A content:// address is a picker's grant from an earlier run, long
        // since unreadable; see fetchUploadedCover.
        val missing = ready.playlists.filter { it.artworkUrl == null || it.artworkUrl.startsWith("content://") }
        if (missing.isEmpty()) return@launch

        missing.forEach { playlist ->
            val cover = coverCache[playlist.uri] ?: Catalog.playlistCover(playlist.uri)
            if (cover.isNullOrEmpty()) return@forEach
            coverCache[playlist.uri] = cover

            // Re-read each time: the list can have been replaced by a refresh
            // while these were being fetched, one at a time.
            val current = _state.value as? UiState.Ready ?: return@launch
            _state.value = current.copy(
                playlists = current.playlists.map {
                    if (it.uri == playlist.uri) it.copy(artworkUrl = cover) else it
                },
            )
        }
    }

    /** The account's own Spotify id, once the profile has been read. */
    private var meId: String? = null
    /** The account's country, for endpoints that require market code. */
    private val userCountry: String get() = container.userCountry

    fun loadProfile() = viewModelScope.launch {
        if (!container.webApi.isReady) return@launch
        runCatching { container.api.me() }
            .onSuccess { profile ->
                // First, and whatever the screen is doing: it used to be set
                // only once the library was on screen, so a profile that
                // answered sooner left it unset for the whole run, every
                // playlist's "mine" unknown, and what hangs on it hidden.
                meId = profile.id
                container.listeningStore.useAccount(profile.id)
                val ready = _state.value as? UiState.Ready ?: return@onSuccess
                _state.value = ready.copy(
                    displayName = profile.displayName?.takeIf(String::isNotBlank)
                        ?: ready.displayName,
                    avatarUrl = profile.images.lastOrNull()?.url,
                )
                // Kept for the one question the playlist menu asks: is this
                // list mine. The id, not the display name — two accounts can
                // be called the same thing and only one of them owns it.
                meId = profile.id
                profile.country?.takeIf { it.isNotBlank() }?.let {
                    container.preferences.setUserCountry(it.uppercase())
                }
                // And kept on disk, for the next time there is no network to
                // ask with; see [offlineLibrary].
                container.preferences.setProfile(
                    _state.value.let { (it as? UiState.Ready)?.displayName.orEmpty() },
                    profile.images.lastOrNull()?.url,
                )
                // The picture itself, beside the downloads, so it is a file
                // rather than a URL that cannot be fetched.
                profile.images.lastOrNull()?.url?.let {
                    launch { dev.lelonio.square.download.DownloadExtras.keep(it, "art") }
                }
            }
            .onFailure { android.util.Log.w(TAG, "profile unavailable: ${describe(it)}") }
    }

    /** Playlists in the order this device last opened them; see [PlaylistOrderStore]. */
    val playlistOrder: StateFlow<List<String>> get() = container.playlistOrder.order


    /** Pinned playlists, in the order they were pinned. */
    val pinnedPlaylists: StateFlow<List<String>> get() = container.pinnedPlaylists.pinned

    fun togglePinned(uri: String) = container.pinnedPlaylists.toggle(uri)

    /**
     * A station built from one track, as the official client's radio button does.
     *
     * `spotify:station:track:…` is a context like any other to the access
     * point: Spotify assembles the list and this only has to ask for it. Empty
     * when it will not, and the caller then leaves the queue alone rather than
     * playing something the listener did not choose.
     */
    suspend fun radioFor(trackUri: String): List<CatalogTrack> {
        if (isYouTubeSong(trackUri)) {
            return runCatching { container.youtubeBackend.radio(trackUri) }
                .onFailure { android.util.Log.w(TAG, "no radio for $trackUri: ${describe(it)}") }
                .getOrDefault(emptyList())
        }
        val id = trackUri.substringAfterLast(':')
        val station = "spotify:station:track:$id"
        return runCatching { Catalog.tracks(Catalog.contextTrackUris(station)) }
            .onFailure { android.util.Log.w(TAG, "no station for $trackUri: ${describe(it)}") }
            .getOrDefault(emptyList())
    }

    /** The address of the station [radioFor] builds from [trackUri]: Spotify's, or YouTube's. */
    fun stationFor(trackUri: String): String =
        if (isYouTubeSong(trackUri)) {
            dev.lelonio.square.backend.youtube.YouTubeBackend.stationUri(trackUri)
        } else {
            "spotify:station:track:" + trackUri.substringAfterLast(':')
        }

    /** Whether a song has a radio at all: Spotify's tracks and YouTube's songs and videos. */
    fun hasRadio(trackUri: String): Boolean =
        trackUri.startsWith("spotify:track:") || isYouTubeSong(trackUri)

    /** A YouTube Music show, which opens as a list whose id starts "MPSP". */
    private fun isYouTubePodcast(uri: String) =
        uri.startsWith(dev.lelonio.square.backend.youtube.YouTubeBackend.PLAYLIST_PREFIX + "MPSP")

    private fun isYouTubeSong(uri: String) =
        uri.startsWith(dev.lelonio.square.backend.youtube.YouTubeBackend.TRACK_PREFIX) ||
            uri.startsWith(dev.lelonio.square.backend.youtube.YouTubeBackend.VIDEO_PREFIX)

    /** How the detail screen sorts its tracks; remembered between visits. */
    val trackOrders get() = container.preferences.trackOrders
    val defaultTrackOrder get() = container.preferences.defaultTrackOrder

    fun setTrackSort(uri: String?, value: String) {
        uri?.let { container.preferences.setTrackSort(it, value) }
    }

    fun setTrackSortDescending(uri: String?, value: Boolean) {
        uri?.let { container.preferences.setTrackSortDescending(it, value) }
    }

    val onboarded: StateFlow<Boolean> get() = container.preferences.onboarded

    fun setOnboarded(value: Boolean) = container.preferences.setOnboarded(value)

    /** Infinite autoplay: whether to fetch similar tracks when queue reaches the end. */
    val autoplayInfinite: StateFlow<Boolean> get() = container.preferences.autoplayInfinite

    fun setAutoplayInfinite(value: Boolean) = container.preferences.setAutoplayInfinite(value)

    /** Silence trimming: whether to trim trailing silence during crossfade. */
    val trimSilence: StateFlow<Boolean> get() = container.preferences.trimSilence

    fun setTrimSilence(value: Boolean) = container.preferences.setTrimSilence(value)

    /**
     * Loads a playlist's tracks.
     *
     * Reloading the playlist already shown is skipped: it is a few dozen
     * access-point round trips, and returning to a playlist from the player is
     * the common case.
     */
    /**
     * Opens a page the app was handed from outside, by URI alone.
     *
     * A link carries no name and no picture, and a page whose title is blank
     * until its tracks land looks broken rather than busy. The name is asked for
     * first when there is an application to ask with, and the page is opened
     * either way: a list of tracks under no title is still the playlist somebody
     * sent.
     */
    fun openLink(uri: String) = viewModelScope.launch {
        // A Spotify link is a Spotify page. Arriving on the other backend, it
        // would resolve against a catalogue that has never heard of it.
        if (container.activeBackend.id != BackendId.SPOTIFY) {
            container.preferences.setBackend(BackendId.SPOTIFY)
        }
        // No name and no picture: the page asks for both itself, and shows the
        // list without waiting for either.
        openContext(uri, "")
    }

    /**
     * Publishes a detail page without taking back what arrived while it was
     * being built.
     *
     * The page is assembled from a snapshot taken when it opened, and the title
     * and the picture of a page opened by URI alone are not in that snapshot:
     * they are asked for separately and land whenever the network answers. Every
     * later write is built from the same snapshot, so a name that arrived in
     * between was on screen until the next one, which is a title appearing for
     * half a second and vanishing. Neither field is ever cleared here: an empty
     * name and a missing picture mean "not known yet", never "gone".
     */
    private fun publishPlaylist(published: PlaylistState) {
        val state = published.copy(tracks = withDeviceFiles(published.tracks))
        val current = _playlist.value
        // The listener's own cover over whatever the service answers (#157).
        val chosen = state.uri?.let(dev.lelonio.square.data.PlaylistCovers::coverFor)
        _playlist.value = if (current.uri != state.uri) {
            if (chosen != null) state.copy(artworkUrl = chosen) else state
        } else {
            state.copy(
                name = state.name.ifEmpty { current.name },
                artworkUrl = chosen ?: state.artworkUrl ?: current.artworkUrl,
                description = state.description.ifEmpty { current.description },
                saved = state.saved ?: current.saved,
                mine = state.mine ?: current.mine,
                // Everything the other catalogue answered, kept across the
                // republishes the page makes while it loads. It arrives once, on
                // its own schedule, and the batch of tracks that lands after it
                // used to take the photograph and the bio back off the page.
                heroUrl = state.heroUrl ?: current.heroUrl,
                coverUrl = state.coverUrl ?: current.coverUrl,
                logoUrl = state.logoUrl ?: current.logoUrl,
                notes = state.notes ?: current.notes,
                byline = state.byline.ifEmpty { current.byline },
                origin = state.origin ?: current.origin,
                tintHex = state.tintHex ?: current.tintHex,
                inkHex = state.inkHex ?: current.inkHex,
                heroAspect = state.heroAspect ?: current.heroAspect,
                motionUrl = state.motionUrl ?: current.motionUrl,
                // The row under the songs, for the same reason: the list is
                // read from a copy of the page taken before the row arrived.
                relatedPlaylists = state.relatedPlaylists.ifEmpty { current.relatedPlaylists },
                // Owned by the lookup alone: every other publish carries the
                // flag's default and would clear the wait a batch of tracks
                // early, which is the swap this exists to prevent.
                heroPending = current.heroPending,
                // The mix, read once like the photograph: a batch of tracks
                // landing after it took the tempo and key back off the rows.
                // What is on screen wins, being the newest — switched on or
                // off since, or given its songs' lengths since.
                mix = current.mix ?: state.mix,
                mixOn = if (current.mix != null) current.mixOn else state.mixOn,
                audioAttributes = current.audioAttributes.ifEmpty { state.audioAttributes },
            )
        }
    }

    /**
     * The two things one lookup answers: what the list says, and whose it is.
     *
     * One request rather than two. They are asked at the same moment and the
     * playlist endpoint returns both, so splitting them would double the
     * traffic for a page that is already waiting on its tracks.
     */
    /** What one lookup says about a playlist: its words, whose it is, and their name. */
    private data class PlaylistDetails(
        val description: String?,
        val mine: Boolean?,
        val owner: String?,
    )

    private suspend fun detailsOf(uri: String): PlaylistDetails? {
        if (!container.webApi.isReady || !uri.startsWith("spotify:playlist:")) return null
        // The owner asked for by name: the default fields leave it out, and
        // without it no playlist was ever known to be the account's own.
        val dto = runCatching {
            container.api.playlist(
                uri.substringAfterLast(':'),
                fields = "id,uri,name,images,description,owner(id,display_name)",
            )
        }
            .onFailure { android.util.Log.w(TAG, "no details for $uri: ${describe(it)}") }
            .getOrNull()
            // Spotify's own lists answer 404 to an application in development
            // mode. Whose it is still matters — it is what hides "Edit" — and
            // the playlist service says.
            ?: return PlaylistDetails(description = null, mine = Catalog.playlistMine(uri), owner = null)
        val owner = dto.owner?.id
        // Asked for here if the profile has not been read yet, rather than
        // left unknown for the page.
        val me = meId ?: runCatching { container.api.me().id }.getOrNull()?.also { meId = it }
        // Null rather than false when either side is missing: "not yours" hides
        // the actions, and hiding them because a request came back thin is
        // worse than the button that was there before.
        val mine = if (owner == null || me == null) null else owner == me
        val text = dto.description
            ?.replace(Regex("<[^>]*>"), "")
            ?.replace("&amp;", "&")
            ?.replace("&quot;", "\"")
            ?.replace("&#x27;", "'")
            ?.replace("&#39;", "'")
            ?.trim()
            // The word a playlist made without a description was given.
            ?.takeIf { it.isNotEmpty() && it != "null" }
        return PlaylistDetails(
            description = text,
            mine = mine,
            owner = dto.owner?.displayName?.takeIf { it.isNotBlank() },
        )
    }


    /**
     * Whether a playlist is followed or an album saved.
     *
     * Two endpoints for one idea, because Spotify keeps the two words apart:
     * you follow somebody else's list and you save a record. Null when there is
     * no application to ask with, which leaves the button off the page rather
     * than showing a state nobody checked.
     */
    private suspend fun savedState(uri: String): Boolean? {
        // A YouTube Music podcast: kept when it is among the saved ones.
        if (isYouTubePodcast(uri)) {
            if (_savedShows.value.isEmpty()) _savedShows.value = runCatching { readSavedShows() }.getOrDefault(emptyList())
            return _savedShows.value.any { it.uri == uri }
        }
        if (!uri.startsWith("spotify:album:") && !uri.startsWith("spotify:playlist:")) return null
        // The gateway first, as the web player asks: it answers for anyone
        // signed in. The Web API's check for a followed playlist is one Spotify
        // has closed to newer applications, and a failure there took the plus
        // off every playlist for whoever had one of those.
        runCatching { container.gateway.inLibrary(listOf(uri))?.firstOrNull() }
            .getOrNull()
            ?.let { return it }
        val id = uri.substringAfterLast(':')
        if (container.webApi.isReady || container.tokenStore.isLoggedIn) {
            runCatching {
                when {
                    uri.startsWith("spotify:album:") ->
                        container.api.albumsAreSaved(id).firstOrNull()
                    else ->
                        container.api.playlistIsFollowed(id, container.api.me().id).firstOrNull()
                }
            }
                .onFailure { android.util.Log.w(TAG, "cannot tell if kept: ${describe(it)}") }
                .getOrNull()
                ?.let { return it }
        }
        // Last, what the library already shows: whether it is in there.
        val library = (_state.value as? UiState.Ready)?.playlists ?: return null
        return library.any { it.uri == uri }
    }

    /**
     * Keeps the open page, or lets it go.
     *
     * The button moves first and is put back if Spotify refuses, for the same
     * reason the follow button does: this is a round trip, and a control that
     * waits for one before acknowledging a tap feels broken even when it works.
     */
    fun toggleSaved() = viewModelScope.launch {
        val page = _playlist.value
        val uri = page.uri ?: return@launch
        val was = page.saved ?: return@launch
        val id = uri.substringAfterLast(':')

        _playlist.value = _playlist.value.copy(saved = !was)
        runCatching {
            when {
                // A podcast is kept through the gateway, as Spotify's own
                // player keeps one: the Web API asks for an application
                // registered with permission for it, which almost nobody has.
                dev.lelonio.square.data.SpotifyPodcasts.isShow(uri) ->
                    check(container.gateway.setInLibrary(listOf(uri), keep = !was)) { "the gateway refused" }

                isYouTubePodcast(uri) ->
                    com.metrolist.innertube.YouTube.savePodcast(
                        uri.removePrefix(dev.lelonio.square.backend.youtube.YouTubeBackend.PLAYLIST_PREFIX),
                        save = !was,
                    ).getOrThrow()

                // A playlist goes into the rootlist, as Spotify's own clients
                // put one there: the gateway refuses playlists, and the Web
                // API's follow answers only to an application of one's own.
                uri.startsWith("spotify:playlist:") &&
                    withContext(Dispatchers.IO) {
                        runCatching { NativeBridge.setInRootlist(uri, keep = !was) }
                            .onFailure { android.util.Log.w(TAG, "rootlist refused: ${describe(it)}") }
                            .isSuccess
                    } -> Unit

                // Through the gateway as the web player keeps them, which works
                // for anyone signed in; the Web API where it will not.
                !uri.startsWith("spotify:playlist:") &&
                    container.gateway.setInLibrary(listOf(uri), keep = !was) -> Unit

                uri.startsWith("spotify:album:") ->
                    if (was) container.api.removeAlbums(id) else container.api.saveAlbums(id)

                else ->
                    if (was) container.api.unfollowPlaylist(id) else container.api.followPlaylist(id)
            }
        }
            .onSuccess {
                // The library is what this button is about, so it is the library
                // that has to show the answer.
                if (kindOf(uri) == DetailKind.SHOW || isYouTubePodcast(uri)) loadSavedShows() else refresh()
            }
            .onFailure {
                android.util.Log.e(TAG, "keeping failed: ${chain(it)}", it)
                if (_playlist.value.uri == uri) {
                    _playlist.value = _playlist.value.copy(saved = was)
                }
            }
    }

    /**
     * Keeps the record on the artist page's top card, or lets it go.
     *
     * Its own function rather than [toggleSaved]: that one is about the page
     * being read, and this is about a different record shown on it. Sharing the
     * code would mean one of the two buttons writing the other's state.
     */
    fun toggleLatestSaved() = viewModelScope.launch {
        val page = _playlist.value
        val release = page.latest ?: return@launch
        val was = page.latestSaved ?: return@launch
        val id = release.uri.substringAfterLast(':')

        _playlist.value = _playlist.value.copy(latestSaved = !was)
        runCatching {
            if (was) container.api.removeAlbums(id) else container.api.saveAlbums(id)
        }
            .onSuccess { refresh() }
            .onFailure {
                android.util.Log.e(TAG, "keeping the release failed: ${chain(it)}", it)
                if (_playlist.value.uri == page.uri) {
                    _playlist.value = _playlist.value.copy(latestSaved = was)
                }
            }
    }

    /** A link's own title, from whichever side of Spotify will say. */
    private suspend fun nameOf(uri: String): String? {
        val kind = kindOf(uri)
        val id = uri.substringAfterLast(':')

        val apiName = runCatching {
            when (kind) {
                DetailKind.ARTIST -> if (container.webApi.isReady) container.api.artist(id).name else null
                DetailKind.ALBUM -> if (container.webApi.isReady) container.api.album(id).name else null
                DetailKind.PLAYLIST -> if (container.webApi.isReady) container.api.playlist(id).name else null
                DetailKind.SHOW -> container.gateway.show(uri)
                    ?.let(dev.lelonio.square.data.SpotifyPodcasts::parseShow)?.name
            }
        }
            .onFailure { android.util.Log.w(TAG, "no name for $uri: ${describe(it)}") }
            .getOrNull()

        if (!apiName.isNullOrEmpty()) return apiName

        if (kind == DetailKind.ARTIST) {
            runCatching {
                dev.lelonio.square.data.SpotifyWebArtist.fetch(id, container.sharedHttpClient, getApplication<SquareApplication>().resources)?.name
            }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { return it }
        }

        // The Web API answers 404 for everything Spotify generates itself — the
        // daily mixes, the editorial lists, the one somebody is most likely to
        // send — and those are exactly the playlists the access point can name.
        if (kind == DetailKind.PLAYLIST && awaitEngine()) {
            return Catalog.playlistName(uri)
        }
        return null
    }

    /**
     * One track, resolved from its URI, for a link that names a song rather
     * than a page.
     */
    suspend fun resolveTrack(uri: String): CatalogTrack? {
        if (!awaitEngine()) return null
        return runCatching { Catalog.tracks(listOf(uri)).firstOrNull() }
            .onFailure { android.util.Log.e(TAG, "link track failed: ${chain(it)}", it) }
            .getOrNull()
    }

    /**
     * Shows a station that has already been resolved.
     *
     * The radio button asks for the tracks before it does anything else — it
     * has to, since an empty station is a button that should do nothing — so
     * this publishes what is already in hand rather than sending the page off
     * to fetch the same list a second time. A station is not a context that can
     * be reopened later anyway: ask twice and Spotify builds two different ones.
     */
    /**
     * Tries to reach Spotify again, and says whether it worked.
     *
     * The switch first, because a listener who turned offline on and then asks
     * to go back online means the switch: leaving it set and rebuilding the
     * session would reconnect an app that immediately declares itself offline
     * again.
     *
     * Then the handshake. A failure is not an error worth showing — the banner
     * is already saying the thing it would say — so this reports it by leaving
     * the app exactly as it was.
     */
    /**
     * The listener's own offline, chosen from the wait for Spotify: the
     * switch in the settings turned on, and the library rebuilt from the
     * downloads at once rather than after the wait it was chosen to cut short.
     */
    fun goOffline() {
        container.downloadSettings.setOfflineMode(true)
        dev.lelonio.square.playback.OfflineMode.setManual(true)
        refresh(restart = true)
    }

    suspend fun retryOnline(): Boolean {
        container.downloadSettings.setOfflineMode(false)
        withContext(Dispatchers.IO) {
            runCatching { NativeBridge.setOfflineOnly(false) }
            runCatching { NativeBridge.reconnect() }
                .onFailure { android.util.Log.w(TAG, "retry failed: ${describe(it)}") }
        }
        val offline = runCatching { NativeBridge.isOffline }.getOrDefault(false)
        dev.lelonio.square.playback.OfflineMode.setNoSession(offline)
        dev.lelonio.square.playback.OfflineMode.setSlow(false)
        if (!offline) {
            // The library was built from the download index while there was no
            // session; now there is one, and it is a different library.
            refresh()
            loadHomeShelves()
        }
        return !offline
    }

    fun showStation(
        uri: String,
        name: String,
        artworkUrl: String?,
        tracks: List<CatalogTrack>,
    ) {
        playlistJob?.cancel()
        // Kept so the source line in the player can come back to it. Asking
        // Spotify for the same station again would build a different one, and
        // the page would then disagree with what is playing.
        lastStation = PlaylistState(
            uri = uri,
            name = name,
            artworkUrl = artworkUrl,
            kind = DetailKind.PLAYLIST,
            tracks = tracks,
        )
        lastStation?.let(::publishPlaylist)
    }

    /** The station last shown, so the player's source line can reopen it. */
    private var lastStation: PlaylistState? = null

    fun openContext(uri: String, name: String, artworkUrl: String? = null) =
        openPlaylist(CatalogPlaylist(uri = uri, name = name, artworkUrl = artworkUrl))

    /**
     * Track lists already resolved, keyed by context URI.
     *
     * Reopening a playlist used to re-resolve it from scratch, which on a
     * thousand-track playlist is a minute of watching rows appear. The list is
     * held for the session and shown immediately; a refresh runs behind it and
     * replaces it only when it has the whole thing, so reopening never takes a
     * finished list away and rebuilds it in front of the user.
     */
    private val _homeShelves = MutableStateFlow<List<HomeShelf>>(emptyList())

    /**
     * Spotify's own personalised home: the mixes, "made for you", the shelves
     * that change through the day.
     *
     * Empty is a perfectly good answer. It comes from a private gateway whose
     * queries are addressed by a hash of themselves, and those hashes are
     * retired whenever Spotify rebuilds its web client, so this page has to be
     * one the app can do without. Everything below it is read the old way and
     * does not depend on this at all.
     */
    private val _releasesPage = MutableStateFlow<List<HomeShelf>>(emptyList())
    private val _chartsPage = MutableStateFlow<List<HomeShelf>>(emptyList())
    private val _madeForYouPage = MutableStateFlow<List<HomeShelf>>(emptyList())

    /**
     * The three tabs, out of the four things Spotify answers.
     *
     * Worked out together because they share one rule, that no playlist is on
     * two of them; see TabContents. Each source updates it as it arrives.
     */
    private val tabs: StateFlow<dev.lelonio.square.data.TabContents.Tabs> = combine(
        _homeShelves,
        _releasesPage,
        _chartsPage,
        _madeForYouPage,
    ) { home, releases, charts, madeForYou ->
        dev.lelonio.square.data.TabContents.split(home, releases, charts, madeForYou)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, dev.lelonio.square.data.TabContents.Tabs())

    val homeShelves: StateFlow<List<HomeShelf>> = tabs.map { it.home }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** What is out and what is being played: new releases and the charts. */
    val newBrowse: StateFlow<List<HomeShelf>> = tabs.map { it.new }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Listening that does not stop: every station and every mix. */
    val radioBrowse: StateFlow<List<HomeShelf>> = tabs.map { it.radio }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var browseJob: Job? = null

    private val _browseLoading = MutableStateFlow(false)

    /**
     * Whether the browse rows are still on their way.
     *
     * The two tabs draw an outline of what is coming rather than growing a row
     * at a time under the reader's thumb: a page that assembles itself while
     * being read moves what is being looked at.
     */
    val browseLoading: StateFlow<Boolean> = _browseLoading.asStateFlow()

    /**
     * Reads Spotify's own browse pages for the two tabs that show them.
     *
     * Kept apart from the personalised home on purpose. Both come off the same
     * gateway, but home answers "what should this account see on opening the
     * app" — which is the home page's question, and putting its answer on two
     * more tabs is how those tabs ended up repeating it. These pages answer
     * what the catalogue is offering: the releases picked for this listener,
     * the editors' lists, the charts, the mixes.
     *
     * What goes on which tab is decided in one place for all three, by what
     * each playlist is rather than by the title of the row it came in; see
     * TabContents. Home reads these pages too: the blends and the day's own
     * list are on "made for you", and the charts are how it knows to leave
     * them to New.
     */
    fun loadBrowse() {
        if (browseJob?.isActive == true) return
        if (_releasesPage.value.isNotEmpty() && _madeForYouPage.value.isNotEmpty()) return

        _browseLoading.value = true
        browseJob = viewModelScope.launch {
            suspend fun page(uri: String) = withContext(Dispatchers.IO) {
                container.gateway.browsePage(uri)
                    ?.let { dev.lelonio.square.data.SpotifyBrowse.parse(it) }
                    .orEmpty()
            }

            page(dev.lelonio.square.data.SpotifyBrowse.Pages.NEW_RELEASES)
                .takeIf { it.isNotEmpty() }?.let { _releasesPage.value = it }
            page(dev.lelonio.square.data.SpotifyBrowse.Pages.MADE_FOR_YOU)
                .takeIf { it.isNotEmpty() }?.let { _madeForYouPage.value = it }
            page(dev.lelonio.square.data.SpotifyBrowse.Pages.CHARTS)
                .takeIf { it.isNotEmpty() }?.let { _chartsPage.value = it }

            android.util.Log.i(
                TAG,
                "browse: ${newBrowse.value.size} rows for new, ${radioBrowse.value.size} for radio",
            )
            _browseLoading.value = false
        }
    }

    /**
     * Asks for the personalised shelves if they are not already here.
     *
     * The home page loads them with the library; the two browse tabs show them
     * too and can be opened without ever visiting home — on a cold start
     * straight into Radio, for instance.
     */
    fun ensureHomeShelves() {
        if (_homeShelves.value.isEmpty()) loadHomeShelves()
    }

    /** Spotify's shelves as they were when the app went offline; see the offline handler. */
    private var shelvesBeforeOffline: List<HomeShelf> = emptyList()

    private var homeShelvesJob: Job? = null

    private fun loadHomeShelves() {
        if (homeShelvesJob?.isActive == true) return
        // On their way again, so their outline shows rather than the stand-in.
        if (_homeShelves.value.isEmpty()) homeShelvesSettled.value = false
        homeShelvesJob = viewModelScope.launch { loadHomeShelvesNow() }
    }

    /**
     * Asked again a couple of times before giving up, and on giving up the
     * shelves from before an offline spell are put back rather than leaving
     * the app's fallback page: one failed answer, often just the session still
     * coming up, used to be the end of Spotify's home for the session.
     */
    private suspend fun loadHomeShelvesNow() {
        try {
            loadHomeShelvesTries()
        } finally {
            homeShelvesSettled.value = true
        }
    }

    /**
     * Whether Spotify's own shelves have been asked for and answered, either
     * way. Until then the home page draws their outline rather than the app's
     * own stand-in page, which used to show first and be swapped for Spotify's
     * a few seconds later, all at once.
     */
    private val homeShelvesSettled = MutableStateFlow(false)

    /** Spotify's shelves are on their way: online, on Spotify, not yet answered. */
    val homeShelvesLoading: StateFlow<Boolean> = combine(
        homeShelvesSettled,
        dev.lelonio.square.playback.OfflineMode.active,
        container.preferences.backend,
    ) { settled, offline, backend ->
        !settled && !offline && backend == BackendId.SPOTIFY && container.spotifySignedIn
    }.stateIn(viewModelScope, SharingStarted.Eagerly, container.spotifySignedIn)

    private suspend fun loadHomeShelvesTries() {
        var shelves = emptyList<HomeShelf>()
        for (wait in HOME_RETRY_MS) {
            kotlinx.coroutines.delay(wait)
            shelves = fetchHomeShelves()
            if (shelves.isNotEmpty() || dev.lelonio.square.playback.OfflineMode.active.value) break
        }
        if (shelves.isEmpty() && _homeShelves.value.isEmpty() && shelvesBeforeOffline.isNotEmpty() &&
            !dev.lelonio.square.playback.OfflineMode.active.value
        ) {
            android.util.Log.i(TAG, "home: kept the shelves from before going offline")
            _homeShelves.value = shelvesBeforeOffline
            return
        }
        if (shelves.isNotEmpty()) {
            shelvesBeforeOffline = emptyList()
            android.util.Log.i(TAG, "home: ${shelves.size} shelves from the gateway")
            _homeShelves.value = shelves
            // The browse pages as well: part of Home is on them; see loadBrowse.
            loadBrowse()
        }
    }

    private suspend fun fetchHomeShelves(): List<HomeShelf> {
        val keys = container.pathfinderKeys
        keys.refresh()
        return withContext(Dispatchers.IO) {
            runCatching {
                SpotifyHome.parse(
                    NativeBridge.homeFeed(
                        java.util.TimeZone.getDefault().id,
                        java.util.Locale.getDefault().language,
                        keys.home,
                        keys.appVersion,
                    ),
                )
            }
                .onFailure { android.util.Log.i(TAG, "no personalised home: ${describe(it)}") }
                .getOrDefault(emptyList())
        }
    }

    private val _inPlaylists = MutableStateFlow<Set<String>>(emptySet())

    /**
     * Tracks known to be in one of the account's playlists.
     *
     * Known, not proven. Spotify has no endpoint for "which of my playlists
     * hold this track", and asking would mean reading every playlist on the
     * account to answer a question about one song. This is filled from the
     * playlists the app has already read, which is what it has been looking at,
     * plus whatever is added from inside the app. So a tick means yes; the
     * absence of one means "not that I have seen".
     */
    val inPlaylists: StateFlow<Set<String>> = _inPlaylists.asStateFlow()

    /**
     * Tracks taken out of a playlist in this session, as "playlist|track".
     *
     * The player ticks a song that is playing from one of the listener's own
     * playlists, and it goes on playing from it after being taken out: without
     * this the tick stayed on a song that was no longer in the list. Put back,
     * it leaves here again.
     */
    private val _takenOut = MutableStateFlow<Set<String>>(emptySet())
    val takenOut: StateFlow<Set<String>> = _takenOut.asStateFlow()

    /** Notes the tracks of a playlist that has just been read. */
    private fun rememberMembership(contextUri: String, tracks: List<CatalogTrack>) {
        if (tracks.isEmpty()) return
        // Liked Songs is not one of the playlists, and the player says so with
        // a heart rather than a tick.
        if (contextUri.endsWith(":collection")) {
            container.likedStore.seed(tracks.map { it.uri })
            // Just read, so nothing missing from it is saved. The seeding
            // below is left to run: it is the tick's half that this says
            // nothing about.
            likedListTrusted = true
            return
        }
        if (!contextUri.startsWith("spotify:playlist:")) return
        _inPlaylists.value = _inPlaylists.value + tracks.map { it.uri }
    }

    /**
     * Tracks known to be in Liked Songs.
     *
     * Delegated to the persistent [LikedStore] so state survives app restarts
     * and stays in lockstep with the notification and car controllers.
     */
    val likedTracks: StateFlow<Set<String>> = container.likedStore.likedTracks

    /**
     * Direct toggle for Liked Songs ("Tus me gusta").
     *
     * Flips local state immediately for zero-latency UI response, syncs with Spotify
     * in the background, and keeps offline downloads updated if enabled.
     */
    fun toggleLike(
        trackUri: String?,
        trackTitle: String? = null,
        artist: String? = null,
        artworkUrl: String? = null,
        playlistName: String? = null,
    ) {
        if (trackUri == null || !trackUri.startsWith("spotify:track:")) return
        val nowLiked = container.likedStore.toggle(trackUri)
        val id = trackUri.substringAfterLast(':')

        if (_addToPlaylist.value.trackUri == trackUri) {
            _addToPlaylist.value = _addToPlaylist.value.copy(liked = nowLiked)
        }

        // Build or find the CatalogTrack for immediate local collection update
        val resolvedTrack = _playlist.value.tracks.find { it.uri == trackUri }
            ?: contextCache.values.firstNotNullOfOrNull { entry -> entry.tracks.find { it.uri == trackUri } }
            ?: CatalogTrack(
                uri = trackUri,
                name = trackTitle.orEmpty().ifEmpty { "Track" },
                artist = artist.orEmpty(),
                artworkUrl = artworkUrl,
            )

        // Immediately update Liked Songs in memory and disk cache
        val colUri = runCatching { NativeBridge.collectionUri() }.getOrNull()?.takeIf { it.isNotEmpty() }
        val targetUris = (contextCache.keys.filter { it.endsWith(":collection") } + listOfNotNull(colUri)).toSet()
        for (cUri in targetUris) {
            val cachedEntry = contextCache[cUri]
            if (cachedEntry != null) {
                val updatedList = if (nowLiked) {
                    listOf(resolvedTrack) + cachedEntry.tracks.filterNot { it.uri == trackUri }
                } else {
                    cachedEntry.tracks.filterNot { it.uri == trackUri }
                }
                contextCache[cUri] = cachedEntry.copy(tracks = updatedList)
                viewModelScope.launch {
                    container.contextCache.write(cUri, updatedList, cachedEntry.snapshotId)
                }
            } else if (cUri.isNotEmpty()) {
                viewModelScope.launch {
                    val diskEntry = container.contextCache.read(cUri)
                    if (diskEntry != null) {
                        val updatedList = if (nowLiked) {
                            listOf(resolvedTrack) + diskEntry.tracks.filterNot { it.uri == trackUri }
                        } else {
                            diskEntry.tracks.filterNot { it.uri == trackUri }
                        }
                        contextCache[cUri] = diskEntry.copy(tracks = updatedList)
                        container.contextCache.write(cUri, updatedList, diskEntry.snapshotId)
                    }
                }
            }
        }

        // If currently viewing Liked Songs screen, update UI tracks immediately
        if (_playlist.value.uri?.endsWith(":collection") == true || (_playlist.value.uri != null && _playlist.value.uri == colUri)) {
            val currentTracks = _playlist.value.tracks
            val updated = if (nowLiked) {
                listOf(resolvedTrack) + currentTracks.filterNot { it.uri == trackUri }
            } else {
                currentTracks.filterNot { it.uri == trackUri }
            }
            _playlist.value = _playlist.value.copy(tracks = updated)
        }

        viewModelScope.launch {
            val syncResult = runCatching {
                if (nowLiked) {
                    container.api.saveToLibrary("spotify:track:$id", SpotifyApi.EMPTY_BODY)
                } else {
                    container.api.removeFromLibrary("spotify:track:$id")
                }
            }.onSuccess {
                android.util.Log.i(TAG, "toggleLike remote sync succeeded for $id (nowLiked=$nowLiked)")
                if (_addToPlaylist.value.trackUri == trackUri) {
                    _addToPlaylist.value = _addToPlaylist.value.copy(
                        busy = null,
                        done = if (nowLiked) playlistName ?: string(R.string.liked_songs) else null,
                        removed = if (!nowLiked) playlistName ?: string(R.string.liked_songs) else null,
                        liked = nowLiked,
                        error = null,
                    )
                }
            }.onFailure { ex ->
                android.util.Log.w(TAG, "toggleLike remote sync failed for $id: ${ex.message}", ex)
                // Revert local state because Spotify call failed
                container.likedStore.toggle(trackUri)
                val revertedLiked = !nowLiked

                val forbidden = describe(ex).contains("403") || (ex as? retrofit2.HttpException)?.code() == 403
                if (forbidden) _webApi.value = _webApi.value.copy(expired = true)

                val errorMsg = when {
                    forbidden -> string(R.string.permission_needed)
                    nowLiked -> string(R.string.like_failed)
                    else -> string(R.string.unlike_failed)
                }

                if (_addToPlaylist.value.trackUri == trackUri) {
                    _addToPlaylist.value = _addToPlaylist.value.copy(
                        busy = null,
                        done = null,
                        removed = null,
                        liked = revertedLiked,
                        error = errorMsg,
                    )
                } else {
                    viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                        android.widget.Toast.makeText(getApplication(), errorMsg, android.widget.Toast.LENGTH_SHORT).show()
                    }
                }

                // Revert Liked Songs in memory and disk cache
                val colUriRevert = runCatching { NativeBridge.collectionUri() }.getOrNull()?.takeIf { it.isNotEmpty() }
                val targetUrisRevert = (contextCache.keys.filter { it.endsWith(":collection") } + listOfNotNull(colUriRevert)).toSet()
                for (cUri in targetUrisRevert) {
                    val cachedEntry = contextCache[cUri]
                    if (cachedEntry != null) {
                        val updatedList = if (revertedLiked) {
                            listOf(resolvedTrack) + cachedEntry.tracks.filterNot { it.uri == trackUri }
                        } else {
                            cachedEntry.tracks.filterNot { it.uri == trackUri }
                        }
                        contextCache[cUri] = cachedEntry.copy(tracks = updatedList)
                        launch {
                            container.contextCache.write(cUri, updatedList, cachedEntry.snapshotId)
                        }
                    }
                }

                if (_playlist.value.uri?.endsWith(":collection") == true || (_playlist.value.uri != null && _playlist.value.uri == colUriRevert)) {
                    val currentTracks = _playlist.value.tracks
                    val updated = if (revertedLiked) {
                        listOf(resolvedTrack) + currentTracks.filterNot { it.uri == trackUri }
                    } else {
                        currentTracks.filterNot { it.uri == trackUri }
                    }
                    _playlist.value = _playlist.value.copy(tracks = updated)
                }
            }

            if (syncResult.isSuccess && container.downloadSettings.downloadLikedSongs.value) {
                if (nowLiked) {
                    // Nothing to fetch it with while the official SDK plays.
                    if (!dev.lelonio.square.playback.websdk.WebSdkRecovery.inUse.value) {
                        container.downloads.addLiked(resolvedTrack)
                        dev.lelonio.square.download.DownloadService.start(container)
                    }
                } else {
                    container.downloads.removeLiked(trackUri)
                    container.downloads.pruneOrphans().forEach {
                        runCatching { dev.lelonio.square.download.YouTubeDownloads.forget(getApplication(), it) }
                        dev.lelonio.square.download.DownloadExtras.forget(it)
                    }
                }
            }
        }
    }

    /** Tracks already asked about, saved or not, so each is asked once. */
    private val likedAsked = mutableSetOf<String>()

    /** Waiting to be asked about, so a run of skips is one question. */
    private val likedPending = linkedSetOf<String>()
    private var likedBatch: kotlinx.coroutines.Job? = null

    /** Whether what is on disk has been looked at yet, for both marks. */
    private var membershipSeeded = false

    /**
     * Whether that copy is recent enough to answer for itself.
     *
     * When it is, a track missing from the set is simply not saved and there
     * is nothing to ask. When it is not — an old copy, or none — a miss is a
     * question, because the listener may have saved it somewhere else since.
     */
    private var likedListTrusted = false

    fun checkLiked(uri: String?) {
        if (uri == null || !uri.startsWith("spotify:track:")) return
        viewModelScope.launch {
            seedMembership()
            if (container.likedStore.isLiked(uri) || likedListTrusted) return@launch
            if (!likedAsked.add(uri)) return@launch

            likedPending += uri
            // A skip is not an answer worth having: while the listener is
            // still moving, the questions pile up and go out together.
            likedBatch?.cancel()
            likedBatch = viewModelScope.launch {
                kotlinx.coroutines.delay(LIKED_BATCH_WAIT_MS)
                val batch = likedPending.toList()
                likedPending.clear()
                askLiked(batch)
            }
        }
    }

    /**
     * Fills both marks from what is already on disk, at no cost in requests.
     *
     * Both used to start every run empty. The heart then asked Spotify about
     * each track as it played, and the tick — which nobody can be asked about —
     * simply went missing: a song from one of the listener's own playlists
     * showed a plus until that playlist happened to be opened again, even
     * though the queue it was playing from had just been restored from this
     * same disk.
     */
    private suspend fun seedMembership() {
        if (membershipSeeded) return
        membershipSeeded = true

        val collection = runCatching { withContext(Dispatchers.IO) { NativeBridge.collectionUri() } }
            .getOrNull()
            .orEmpty()
        val liked = collection.takeIf { it.isNotEmpty() }
            ?.let { contextCache[it] ?: container.contextCache.read(it) }
        if (liked != null) {
            container.likedStore.seed(liked.tracks.map { it.uri })
            // Never downwards: this run may already have read the list itself,
            // which is fresher than anything on disk.
            likedListTrusted = likedListTrusted ||
                System.currentTimeMillis() - liked.savedAt < LIKED_TRUSTED_MS
        }

        val inPlaylists = runCatching { container.contextCache.tracksInPlaylists() }
            .onFailure { android.util.Log.i(TAG, "no playlists remembered: ${describe(it)}") }
            .getOrDefault(emptySet())
        if (inPlaylists.isNotEmpty()) _inPlaylists.value = _inPlaylists.value + inPlaylists
    }

    /**
     * Asks about a handful of tracks at once.
     *
     * The gateway first, as everywhere else: it answers for anyone logged in,
     * and it takes the whole batch in one request. The Web API answers the
     * same question against the listener's own application.
     */
    private suspend fun askLiked(uris: List<String>) {
        if (uris.isEmpty()) return
        val answers = container.gateway.inLibrary(uris) ?: webApiSaved(uris)
        if (answers == null) {
            // Asked again next time they play: this is a decoration.
            likedAsked -= uris.toSet()
            return
        }
        val saved = uris.filterIndexed { index, _ -> answers.getOrNull(index) == true }
        if (saved.isNotEmpty()) container.likedStore.seed(saved)
    }

    /** The same question through the listener's own application. */
    private suspend fun webApiSaved(uris: List<String>): List<Boolean>? {
        if (!container.webApi.isReady && !container.tokenStore.isLoggedIn) return null
        return runCatching {
            container.api.tracksAreSaved(uris.joinToString(",") { it.substringAfterLast(':') })
        }
            .onFailure { android.util.Log.i(TAG, "cannot tell what is saved: ${describe(it)}") }
            .getOrNull()
    }

    private val contextCache =
        object : LinkedHashMap<String, ContextCacheStore.Entry>(0, 0.75f, true) {
            override fun removeEldestEntry(eldest: Map.Entry<String, ContextCacheStore.Entry>) =
                size > CONTEXT_CACHE_SIZE
        }

    private val artistPageCache =
        object : LinkedHashMap<String, ArtistPage>(0, 0.75f, true) {
            override fun removeEldestEntry(eldest: Map.Entry<String, ArtistPage>) =
                size > 30
        }

    /** The row under each playlist opened this run, so reopening one asks nothing. */
    private val relatedCache =
        object : LinkedHashMap<String, List<SearchItem>>(0, 0.75f, true) {
            override fun removeEldestEntry(eldest: Map.Entry<String, List<SearchItem>>) =
                size > 30
        }

    // ------------------------------------------------------------ downloads

    /** What is on the phone, per track; see DownloadStore. */
    val downloadedFiles = container.downloads.files

    /** What is being fetched right now, 0f..1f per track. */
    val downloadProgress = container.downloads.progress

    /** Per playlist, album or artist: whether it is kept, and how far along. */
    val downloadOwners = container.downloads.ownerStates

    /**
     * Tracks downloaded on their own rather than as part of a page.
     *
     * The difference matters to the track menu: a song kept because a playlist
     * wants it cannot be removed by itself — the file is still owed to that
     * playlist — so offering to remove it there would be offering something
     * that does nothing.
     */
    val downloadSingles: StateFlow<Set<String>> =
        container.downloads.owners
            .map { it[DownloadStore.SINGLES].orEmpty().toSet() }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    /**
     * Starts the downloads the listener just asked for, and says so when they
     * are going to wait.
     *
     * On mobile data with "Download over Wi‑Fi only" on, which it is unless
     * changed, a download waits for Wi‑Fi, and the only place that said so was
     * the download notification. With notifications off, nothing happened and
     * nothing explained why, which reads as downloading being broken. Only for
     * what was asked for here: the queue following a kept playlist on its own
     * has nobody to tell.
     */
    private fun startRequestedDownloads() {
        val app = getApplication<android.app.Application>()
        if (container.downloadQueue.waitsForWifi()) {
            android.widget.Toast.makeText(
                app,
                app.getString(
                    dev.lelonio.square.R.string.download_waiting_wifi_hint,
                    app.getString(dev.lelonio.square.R.string.settings),
                    app.getString(dev.lelonio.square.R.string.page_downloads),
                    app.getString(dev.lelonio.square.R.string.download_wifi_only),
                ),
                android.widget.Toast.LENGTH_LONG,
            ).show()
        }
        DownloadService.start(app)
    }

    /**
     * Keeps a whole page on the phone, or stops keeping it.
     *
     * The page is the unit rather than the track because that is how a listener
     * thinks about it — a playlist goes on the plane, not forty songs — and
     * because it is what lets a shared track cost nothing: the store records
     * who wanted each file, so a song two playlists both keep is fetched once
     * and only leaves when the last of them lets go of it.
     */
    fun toggleDownload(page: PlaylistState) {
        val uri = page.uri ?: return
        if (page.tracks.isEmpty()) return
        viewModelScope.launch {
            if (container.downloads.owners.value.containsKey(uri)) {
                // Only what is actually being fetched. Cancelling every track
                // of the playlist would work — the engine clears the mark
                // before each download — but it would also be several hundred
                // JNI calls to stop the one or two that are running.
                val inFlight = container.downloads.progress.value.keys.toList()
                container.downloads.removeOwner(uri)
                inFlight.forEach { runCatching { dev.lelonio.square.download.YouTubeDownloads.stop(it) } }
                sweepOrphans()
            } else {
                // The page's own cover, kept like the songs are. It is one
                // picture against a playlist's worth of audio, and without it
                // the library offline is a wall of drawn tiles.
                page.artworkUrl?.let {
                    launch { dev.lelonio.square.download.DownloadExtras.keep(it, "art") }
                }
                container.downloads.setOwner(
                    ownerUri = uri,
                    tracks = page.tracks,
                    label = DownloadStore.OwnerLabel(
                        name = page.name,
                        artworkUrl = page.artworkUrl,
                        kind = when (page.kind) {
                            DetailKind.ALBUM -> DownloadStore.KIND_ALBUM
                            DetailKind.ARTIST -> DownloadStore.KIND_ARTIST
                            DetailKind.PLAYLIST, DetailKind.SHOW -> DownloadStore.KIND_PLAYLIST
                        },
                    ),
                )
                startRequestedDownloads()
            }
        }
    }

    /**
     * A kept page brought in step with the page as it now reads.
     *
     * Downloading a playlist used to record its songs as they were that day
     * and never look again: a song added afterwards, here or anywhere else,
     * was in the list and not on the phone, and one taken out stayed on the
     * phone. Every full read of a kept page now replaces what it wants, which
     * fetches what is new and lets go of what is gone; the order is kept too,
     * since it is the order the page shows offline.
     *
     * Only from a whole list read from the service: offline, or from a list
     * that came back empty, there is nothing to say the playlist changed.
     */
    private fun followKept(uri: String, tracks: List<CatalogTrack>) {
        val kept = container.downloads.owners.value[uri] ?: return
        if (tracks.isEmpty() || dev.lelonio.square.playback.OfflineMode.active.value) return
        val now = tracks.map { it.uri }
        if (now == kept) return
        viewModelScope.launch {
            container.downloads.setOwner(uri, tracks, label = null)
            val added = now.toSet() - kept.toSet()
            val gone = kept.toSet() - now.toSet()
            android.util.Log.i(TAG, "kept $uri followed: ${added.size} added, ${gone.size} gone")
            if (gone.isNotEmpty()) sweepOrphans()
            if (added.isNotEmpty()) DownloadService.start(getApplication())
        }
    }

    /**
     * Every kept list read again, once a run, so songs added to a downloaded
     * playlist anywhere (the service's own app, another phone) are downloaded
     * without the playlist having to be opened here first (discussion #87).
     *
     * YouTube Music's in full, which is one request. Spotify's only when their
     * version has moved since the copy kept here, which is one question each;
     * a playlist is read in full, at two hundred songs a request, only when
     * something in it changed. Liked Songs has no version to ask for, and is
     * read in full.
     */
    private fun followKeptYouTube() = viewModelScope.launch {
        delay(KEPT_SYNC_DELAY_MS)
        container.downloads.ensureLoaded()
        if (dev.lelonio.square.playback.OfflineMode.active.value) return@launch
        val youtube = container.youtubeBackend
        val kept = container.downloads.owners.value.keys
        kept.filter { it.startsWith(dev.lelonio.square.backend.youtube.YouTubeBackend.PLAYLIST_PREFIX) }
            .forEach { uri ->
                runCatching { youtube.tracksOf(uri) }
                    .onSuccess { followKept(uri, it) }
                    .onFailure { android.util.Log.w(TAG, "kept $uri not read: ${describe(it)}") }
            }
        val spotify = kept.filter { it.startsWith("spotify:playlist:") || it.endsWith(":collection") }
        if (spotify.isEmpty() || !container.spotifySignedIn || !awaitEngine()) return@launch
        spotify.forEach { uri ->
            if (dev.lelonio.square.playback.OfflineMode.active.value) return@launch
            val stamp = snapshotOf(uri)
            val known = (contextCache[uri] ?: container.contextCache.read(uri))?.snapshotId
            if (stamp != null && stamp == known) return@forEach
            followKeptSpotify(uri)
        }
    }

    /**
     * One track, kept on its own.
     *
     * Filed under a owner of its own so that the answer to "why is this here"
     * stays honest: a song downloaded by itself does not disappear because a
     * playlist it also belongs to was let go of.
     */
    fun toggleTrackDownload(track: CatalogTrack) {
        viewModelScope.launch {
            val singles = container.downloads.owners.value[DownloadStore.SINGLES].orEmpty()
            if (track.uri in singles) {
                container.downloads.removeSingle(track.uri)
                runCatching { dev.lelonio.square.download.YouTubeDownloads.stop(track.uri) }
                sweepOrphans()
            } else {
                container.downloads.addSingle(track)
                startRequestedDownloads()
            }
        }
    }

    /** Everything, gone. The files first, then what pointed at them. */
    /**
     * Deletes the files nothing wants any more.
     *
     * Letting go of a playlist only says the playlist no longer wants its
     * songs; it does not say the songs can go, because another playlist may
     * want the same ones. So the two halves are separate: the index works out
     * what is now unclaimed, and this is what takes those off the disk.
     *
     * Without it the index kept every file it had ever fetched — the rows went
     * on showing the download mark for a playlist that had just been let go of,
     * and the space was never given back.
     */
    private suspend fun sweepOrphans() {
        container.downloads.pruneOrphans().forEach {
            runCatching { dev.lelonio.square.download.YouTubeDownloads.forget(getApplication(), it) }
            dev.lelonio.square.download.DownloadExtras.forget(it)
        }
        // And whatever is left in the extras that no surviving track can
        // explain: covers, words and Canvases of songs that are gone.
        withContext(Dispatchers.IO) {
            val tracks = container.downloads.files.value.keys
            dev.lelonio.square.download.DownloadExtras.sweep(
                trackUris = tracks,
                coverUrls = tracks.mapNotNull { container.downloads.trackOf(it)?.artworkUrl },
            )
        }
    }

    fun clearDownloads() {
        viewModelScope.launch {
            container.downloads.progress.value.keys.forEach {
                runCatching { dev.lelonio.square.download.YouTubeDownloads.stop(it) }
            }
            container.downloads.clearAll()
        }
    }

    fun retryFailedDownloads() {
        viewModelScope.launch {
            container.downloads.retryFailed()
            startRequestedDownloads()
        }
    }

    /**
     * Detail pages opened over other detail pages, newest last.
     *
     * The navigation graph has one route for all of them, so an album opened
     * from an artist is not a second destination — it is the same screen showing
     * something else, and back had nowhere to go but out of the screen entirely.
     * This is that missing history: what the page was before it became this one.
     */
    private val pageStack = ArrayDeque<PlaylistState>()

    /**
     * Whether there is a page behind this one, as something the screen can watch.
     *
     * A plain getter is what this was, and it is worth saying why that was a
     * bug rather than a style: the back handler reads it while it composes, and
     * nothing about a plain field tells Compose to compose again. Opening an
     * album from an artist changed the answer and nothing noticed — so the
     * gesture kept leaving the screen entirely, or kept being swallowed after
     * the history had run out, which is the "back shows the wrong page" this is
     * behind.
     */
    private val _hasPreviousPage = MutableStateFlow(false)
    val hasPreviousPage: StateFlow<Boolean> = _hasPreviousPage.asStateFlow()

    /**
     * How deep into the detail pages the listener has walked.
     *
     * Only the screen's own transition uses it, and only to tell a push from a
     * pop: the two have to move in opposite directions, and one destination
     * shared by every page means the navigation library cannot say which way
     * this is going.
     */
    private val _pageDepth = MutableStateFlow(0)
    val pageDepth: StateFlow<Int> = _pageDepth.asStateFlow()

    /**
     * Whether the detail screen is the one on screen right now.
     *
     * What decides whether opening a page pushes the last one onto the history.
     * Without it the state left behind by a page that was closed minutes ago
     * still counted as "the page you were on": open a playlist, leave it, open
     * an artist, press back — and the playlist came back, because it was still
     * sitting in [_playlist] when the artist was opened.
     */
    private var pageOnScreen = false

    /** Told by the screen itself; see the detail route. */
    fun detailShown() {
        pageOnScreen = true
    }

    /** And when it goes, so does everything behind it. */
    fun detailClosed() {
        pageOnScreen = false
        playlistJob?.cancel()
        _playlist.value = PlaylistState()
        clearPageHistory()
    }

    /**
     * Goes back one detail page, and says whether there was one.
     *
     * False leaves the caller to pop the navigation stack as it always did:
     * the page underneath is then a tab, not another detail.
     */
    fun popPage(): Boolean {
        while (pageStack.isNotEmpty() && pageStack.last().uri == _playlist.value.uri) {
            pageStack.removeLast()
        }
        val previous = pageStack.removeLastOrNull()
        if (previous == null) {
            playlistJob?.cancel()
            return false
        }
        playlistJob?.cancel()
        _playlist.value = previous
        _hasPreviousPage.value = pageStack.isNotEmpty()
        _pageDepth.value = pageStack.size
        return true
    }

    /**
     * Nothing is behind a page reached from a tab.
     *
     * Called when a tab is tapped: the detail screen is one destination shared
     * by every tab, so a history left over from the last one would have back
     * walking into a page opened from somewhere the listener has since left.
     */
    fun clearPageHistory() {
        pageStack.clear()
        _hasPreviousPage.value = false
        _pageDepth.value = 0
    }

    /**
     * The phone's own music, read when a page opens, for the local files a
     * Spotify playlist names; see [withDeviceFiles].
     */
    @Volatile
    private var deviceFiles: List<CatalogTrack> = emptyList()

    /**
     * A playlist's local entries, each given the file on this phone it
     * describes. The entry keeps its `spotify:local:` URI, so it stays in the
     * playlist's queue and Spotify's engine plays it from the file, between the
     * streamed tracks; an entry with no file here is left without one, and the
     * page shows it greyed out, as Spotify's own apps do.
     */
    private fun withDeviceFiles(tracks: List<CatalogTrack>): List<CatalogTrack> {
        if (tracks.none { LocalLibrary.isSpotifyLocal(it.uri) }) return tracks
        val files = deviceFiles
        val matched = tracks.map { track ->
            if (!LocalLibrary.isSpotifyLocal(track.uri)) return@map track
            val file = LocalLibrary.match(track, files)
            track.copy(
                localFile = file?.localFile,
                artworkUrl = track.artworkUrl ?: file?.artworkUrl,
            )
        }
        // Told to the engine as they are found, and kept, on disk too: a queue
        // started on one page plays on while another is open, and after the
        // app is closed and opened again; see LocalFileBindings.
        dev.lelonio.square.data.LocalFileBindings.bind(
            matched.mapNotNull { track ->
                track.localFile?.takeIf { LocalLibrary.isSpotifyLocal(track.uri) }?.let { track.uri to it }
            }.toMap(),
        )
        return matched
    }


    private fun mixPrefs() =
        getApplication<SquareApplication>().getSharedPreferences(MIX_PREFS, android.content.Context.MODE_PRIVATE)

    /**
     * Whether a playlist plays as a mix here: as Spotify has it, unless the
     * listener said otherwise on this phone — off for one that is mixed, on
     * for one that is not.
     */
    private fun mixOn(uri: String, mixed: Boolean): Boolean {
        val prefs = mixPrefs()
        return if (mixed) {
            uri !in prefs.getStringSet(MIX_OFF, emptySet()).orEmpty()
        } else {
            uri in prefs.getStringSet(MIX_ON, emptySet()).orEmpty()
        }
    }

    /**
     * Turns the page's Spotify Mix on or off, here only.
     *
     * Kept per playlist on this phone, and nothing is written to Spotify: off,
     * the songs play one after another as anywhere else, and the playlist is
     * still mixed for every other device and for Spotify's own app.
     */
    fun toggleMix() {
        val page = _playlist.value
        val uri = page.uri ?: return
        val mix = page.mix ?: return
        val on = !page.mixOn
        val prefs = mixPrefs()
        // Kept as a difference from Spotify's own state, so a playlist mixed
        // or unmixed in Spotify's app later follows it unless told otherwise.
        val key = if (mix.mixed) MIX_OFF else MIX_ON
        val listed = prefs.getStringSet(key, emptySet()).orEmpty().toMutableSet()
        if (on == mix.mixed) listed.remove(uri) else listed.add(uri)
        prefs.edit().putStringSet(key, listed).apply()
        dev.lelonio.square.playback.Mixes.set(uri, mix.takeIf { on })
        _playlist.value = page.copy(mixOn = on)
        if (on) viewModelScope.launch { loadMixData(uri) }
    }

    /**
     * What a mixed page needs beyond its transitions: the tempo and key the
     * rows show, and the songs' lengths, which the automatic transitions fit
     * inside. What those are worked out from is asked for by the player, for
     * the pair about to play; see Mixes.
     *
     * Waits for the songs, which arrive on their own clock, and asks once for
     * all of them; see catalog.rs. Returns what it found, for a caller keeping
     * its own copy of the page, and null when the page was left meanwhile.
     */
    private suspend fun loadMixData(
        uri: String,
    ): Pair<Map<String, dev.lelonio.square.playback.Mixes.Attributes>, dev.lelonio.square.playback.Mixes.PlaylistMix>? {
        val tracks = withTimeoutOrNull(ARTIST_WAIT_MS) {
            while (_playlist.value.uri == uri && _playlist.value.tracks.isEmpty()) delay(POLL_INTERVAL_MS)
            _playlist.value.tracks
        }.orEmpty()
        val uris = tracks.map { it.uri }.filter { it.startsWith("spotify:track:") }.distinct()
        if (uris.isEmpty()) return null
        val json = org.json.JSONArray(uris).toString()
        val attributes = withContext(Dispatchers.IO) {
            dev.lelonio.square.playback.Mixes.parseAttributes(NativeBridge.tracksAudioAttributes(json))
        }
        android.util.Log.i(TAG, "mix of $uri: tempo and key for ${attributes.size} of ${uris.size} songs")
        val page = _playlist.value
        if (page.uri != uri) return null
        val mix = (page.mix ?: return null).copy(
            durations = page.tracks.filter { it.durationMs > 0 }.associate { it.uri to it.durationMs },
        )
        _playlist.value = page.copy(audioAttributes = attributes, mix = mix)
        if (page.mixOn) dev.lelonio.square.playback.Mixes.set(uri, mix)
        return attributes to mix
    }

    fun openPlaylist(playlist: CatalogPlaylist) {
        // Read again on every page: a file copied to the phone since the last
        // one should be found the next time its playlist is opened.
        viewModelScope.launch {
            deviceFiles = LocalLibrary.tracks(getApplication())
            val shown = _playlist.value
            if (shown.tracks.any { LocalLibrary.isSpotifyLocal(it.uri) }) publishPlaylist(shown)
        }
        // What is on screen now, if it is a different page and a real one. The
        // list is kept whole rather than re-resolved on the way back: an artist
        // page is four requests and a discography, and walking back into it
        // should be instant.
        _playlist.value
            .takeIf {
                pageOnScreen && it.uri != null && it.uri != playlist.uri
            }
            ?.let {
                if (pageStack.lastOrNull()?.uri != it.uri) {
                    pageStack.addLast(it)
                    // Deep enough to walk back through a listening session, short
                    // enough that a thousand-track playlist is not held forever.
                    while (pageStack.size > PAGE_HISTORY) pageStack.removeFirst()
                    _hasPreviousPage.value = true
                    _pageDepth.value = pageStack.size
                }
            }

        // A station reopens as the list it already is; see [showStation].
        lastStation?.takeIf { it.uri == playlist.uri }?.let {
            playlistJob?.cancel()
            publishPlaylist(it)
            return
        }

        // Reopening one counts as opening it, and that is exactly the playlist
        // the home page should keep at the front.
        container.playlistOrder.record(playlist.uri)
        container.widgetPlaylists.record(playlist.uri, playlist.name, playlist.artworkUrl, container.activeBackend.id)
        dev.lelonio.square.widget.SquareWidget.refresh(getApplication())

        if (playlist.uri == LocalLibrary.CONTEXT_URI) {
            openLocalFiles(playlist)
            return
        }

        // The shelf of downloaded songs contains all songs downloaded to the phone.
        if (playlist.uri == DownloadStore.SINGLES) {
            openDownloadedTracks(playlist)
            return
        }

        // Offline, a downloaded playlist is answered from the index too. Not a
        // fallback after a failed request but instead of one: with no session
        // the request cannot even be attempted, and the whole list is already
        // here — in the order the playlist had when it was downloaded, which is
        // the order it should still be in.
        if (dev.lelonio.square.playback.OfflineMode.active.value) {
            val wanted = container.downloads.owners.value[playlist.uri]
            if (wanted != null) {
                openDownloadedContext(playlist, wanted)
                return
            }
        }

        val kind = kindOf(playlist.uri)
        playlistJob?.cancel()
        // Reassigned when the picture arrives late; every state published below
        // is built from this, so filling it in one place is what stops a later
        // write from taking the picture back off the screen.
        var base = PlaylistState(
            uri = playlist.uri,
            name = playlist.name,
            artworkUrl = dev.lelonio.square.data.PlaylistCovers.coverFor(playlist.uri) ?: playlist.artworkUrl,
            kind = kind,
        )

        val rememberedArtist = if (kind == DetailKind.ARTIST) artistPageCache[playlist.uri] else null
        val remembered = contextCache[playlist.uri]
        if (rememberedArtist != null) {
            publishPlaylist(base.copy(
                name = base.name.ifEmpty { rememberedArtist.name.orEmpty() },
                artworkUrl = base.artworkUrl ?: rememberedArtist.artworkUrl,
                tracks = rememberedArtist.tracks.take(5),
                latest = rememberedArtist.latest,
                albums = rememberedArtist.albums,
                singles = rememberedArtist.singles,
                appearsOn = rememberedArtist.appearsOn,
                artistPlaylists = rememberedArtist.playlists,
                relatedArtists = rememberedArtist.relatedArtists,
                verified = true,
                monthlyListeners = rememberedArtist.monthlyListeners,
                followers = rememberedArtist.followers,
                genres = rememberedArtist.genres,
                notes = base.notes ?: rememberedArtist.biography,
                loading = false,
            ))
        } else {
            publishPlaylist(base.copy(
                tracks = remembered?.tracks.orEmpty(),
                loading = remembered == null,
            ))
        }

        playlistJob = viewModelScope.launch {
            // Opened by URI alone, from a tap on the player's text: there was no
            // row to take the picture from. Asked for alongside the track list
            // rather than before it, since the list is what the page is for.
            // Opened by URI alone from outside the app: a link carries no title
            // either. Written through `base` like the picture below, and for the
            // same reason: every state published here is built from it, so a
            // name patched onto the state instead would be taken back off the
            // screen by the next write, which is a title that appears for half a
            // second and vanishes.
            if (base.name.isEmpty()) launch {
                val name = nameOf(playlist.uri) ?: return@launch
                base = base.copy(name = name)
                if (isActive && _playlist.value.uri == playlist.uri) {
                    _playlist.value = _playlist.value.copy(name = name)
                }
            }

            // What the list says about itself, when its source says anything.
            // Asked for beside the picture and written the same way, through
            // `base`, so a later publish cannot take it back off the screen.
            // Asked whenever anything it answers is still missing. Keyed on the
            // description alone, it never ran for a list that had one — and the
            // name under the title, which comes from the same request, was then
            // absent on exactly the lists that describe themselves.
            if (kind == DetailKind.PLAYLIST &&
                (base.description.isEmpty() || base.byline.isEmpty())
            ) launch {
                val details = detailsOf(playlist.uri) ?: return@launch
                val text = details.description
                val mine = details.mine
                base = base.copy(
                    description = text.orEmpty(),
                    mine = mine,
                    byline = details.owner.orEmpty(),
                )
                if (isActive && _playlist.value.uri == playlist.uri) {
                    _playlist.value = _playlist.value.copy(
                        description = text.orEmpty().ifEmpty { _playlist.value.description },
                        mine = mine,
                        byline = details.owner.orEmpty(),
                    )
                }
            }

            // Its Spotify Mix: the transitions it was saved with in Spotify's
            // own app, if any, and whether it plays as a mix here. Any Spotify
            // playlist can: one that was never mixed plays with the automatic
            // transitions alone. On by default only where Spotify has it mixed.
            if (playlist.uri.startsWith("spotify:playlist:") &&
                container.activeBackend.id == BackendId.SPOTIFY &&
                !dev.lelonio.square.playback.OfflineMode.active.value
            ) launch {
                if (!awaitEngine()) return@launch
                val mix = withContext(Dispatchers.IO) {
                    dev.lelonio.square.playback.Mixes.parseMix(NativeBridge.playlistMix(playlist.uri))
                } ?: return@launch
                val on = mixOn(playlist.uri, mix.mixed)
                android.util.Log.i(TAG, "mix of ${playlist.uri}: mixed=${mix.mixed}, ${mix.transitions.size} saved, on=$on")
                base = base.copy(mix = mix, mixOn = on)
                if (!isActive || _playlist.value.uri != playlist.uri) return@launch
                _playlist.value = _playlist.value.copy(mix = mix, mixOn = on)
                if (on) {
                    dev.lelonio.square.playback.Mixes.set(playlist.uri, mix)
                    loadMixData(playlist.uri)?.let { (attributes, withLengths) ->
                        base = base.copy(audioAttributes = attributes, mix = withLengths)
                    }
                }
            }

            // Whether it is already kept, for the button that keeps it.
            if (kind != DetailKind.ARTIST) launch {
                val kept = savedState(playlist.uri) ?: return@launch
                if (isActive && _playlist.value.uri == playlist.uri) {
                    _playlist.value = _playlist.value.copy(saved = kept)
                }
                base = base.copy(saved = kept)
            }

            // Lists like this one, for the row under the songs. Written through
            // `base` like the rest, and quiet like the rest: the page is whole
            // without it, and a list Spotify has nothing to pair with simply
            // ends where its songs do.
            if (kind == DetailKind.PLAYLIST && playlist.uri.startsWith("spotify:playlist:") &&
                !dev.lelonio.square.playback.OfflineMode.active.value
            ) launch {
                val related = relatedCache[playlist.uri]
                    ?: container.gateway.relatedPlaylists(playlist.uri)
                        ?.filter { it.uri != playlist.uri }
                        ?.also { relatedCache[playlist.uri] = it }
                    ?: return@launch
                android.util.Log.i(TAG, "related playlists for ${playlist.uri}: ${related.size}")
                if (related.isEmpty()) return@launch
                base = base.copy(relatedPlaylists = related)
                if (isActive && _playlist.value.uri == playlist.uri) {
                    _playlist.value = _playlist.value.copy(relatedPlaylists = related)
                }
            }

            // Apple's own pictures for the page. Deliberately last and
            // deliberately quiet: it is a different catalogue reached over a
            // different network, everything on screen is already correct
            // without it, and an artist it has never heard of simply keeps the
            // header it has.
            if (kind == DetailKind.ARTIST || kind == DetailKind.ALBUM) {
                if (!dev.lelonio.square.playback.OfflineMode.active.value) {
                    base = base.copy(heroPending = true)
                    if (isActive && _playlist.value.uri == playlist.uri) {
                        _playlist.value = _playlist.value.copy(heroPending = true)
                    }
                }
                launch { dressPage(playlist.uri, playlist.name, kind) }
            }

            if (base.artworkUrl == null) launch {
                val art = artworkFor(playlist.uri, kind) ?: return@launch
                base = base.copy(artworkUrl = art)
                if (isActive && _playlist.value.uri == playlist.uri) {
                    _playlist.value = _playlist.value.copy(artworkUrl = art)
                }
            }

            // The disk copy, if this run has not opened the playlist yet. Read
            // before anything is asked of the network: the whole point is that a
            // list already known appears at once rather than filling in.
            val entry = remembered ?: container.contextCache.read(playlist.uri)?.also {
                contextCache[playlist.uri] = it
                rememberMembership(playlist.uri, it.tracks)
                publishPlaylist(base.copy(tracks = it.tracks, loading = false))
            }
            val cached = entry?.tracks.orEmpty()

            try {
                if (!playlist.uri.startsWith("spotify:")) {
                    // Whether the account follows this artist, for the button
                    // on their page. After the tracks, which read the same
                    // page and leave the answer behind for this to pick up.
                    if (kind == DetailKind.ARTIST) launch {
                        val following = container.activeBackend.isFollowing(playlist.uri)
                            ?: return@launch
                        base = base.copy(following = following)
                        if (isActive && _playlist.value.uri == playlist.uri) {
                            _playlist.value = _playlist.value.copy(following = following)
                        }
                    }
                    // Another backend's context. Resolved in one call rather
                    // than page by page: the Spotify paths below are built
                    // around the Web API's paging and the access point's
                    // per-track lookups, neither of which exists here.
                    val youtube = container.activeBackend as? dev.lelonio.square.backend.youtube.YouTubeBackend
                    val artistPage = if (kind == DetailKind.ARTIST && youtube != null) {
                        youtube.artistPage(playlist.uri)
                    } else {
                        null
                    }
                    if (artistPage != null) {
                        if (isActive && _playlist.value.uri == playlist.uri) {
                            publishPlaylist(
                                base.copy(
                                    name = base.name.ifEmpty { artistPage.name },
                                    artworkUrl = artistPage.artworkUrl ?: base.artworkUrl,
                                    tracks = artistPage.topSongs,
                                    notes = base.notes ?: artistPage.description,
                                    subscribers = artistPage.subscribers,
                                    monthlyListeners = artistPage.monthlyListeners,
                                    shelves = artistPage.shelves,
                                    topSongsMoreUri = artistPage.topSongsMoreUri,
                                    following = _playlist.value.following,
                                    loading = false,
                                ),
                            )
                        }
                        return@launch
                    }
                    // A YouTube Music list is kept like a Spotify one: read in
                    // full only when its first page says it has changed. Long
                    // lists are a page a hundred songs, asked one after another.
                    val youtubeLists = container.activeBackend as? dev.lelonio.square.backend.youtube.YouTubeBackend
                    val tracks = if (youtubeLists != null) {
                        val (stamp, fresh) = youtubeLists.tracksIfChanged(
                            playlist.uri,
                            entry?.snapshotId.takeIf { cached.isNotEmpty() },
                        )
                        val now = System.currentTimeMillis()
                        if (stamp != null) {
                            val kept = fresh ?: cached
                            contextCache[playlist.uri] = ContextCacheStore.Entry(tracks = kept, snapshotId = stamp, savedAt = now, uri = playlist.uri)
                            container.contextCache.write(playlist.uri, kept, stamp)
                        }
                        fresh ?: cached
                    } else {
                        container.activeBackend.tracksOf(playlist.uri)
                    }
                    followKept(playlist.uri, tracks)
                    if (isActive && _playlist.value.uri == playlist.uri) {
                        publishPlaylist(base.copy(tracks = tracks, loading = false))
                    }
                } else if (kind == DetailKind.ARTIST) {
                    val page = loadArtist(playlist.uri, base.name.ifEmpty { playlist.name })
                    if (!isActive || _playlist.value.uri != playlist.uri) return@launch
                    artistPageCache[playlist.uri] = page
                    publishPlaylist(
                        base.copy(
                            name = base.name.ifEmpty { page.name.orEmpty() },
                            artworkUrl = base.artworkUrl ?: page.artworkUrl,
                            tracks = page.tracks.take(5),
                            latest = page.latest,
                            albums = page.albums,
                            singles = page.singles,
                            appearsOn = page.appearsOn,
                            artistPlaylists = page.playlists,
                            relatedArtists = page.relatedArtists,
                            verified = true,
                            monthlyListeners = page.monthlyListeners,
                            followers = page.followers,
                            genres = page.genres,
                            notes = base.notes ?: page.biography,
                            following = _playlist.value.following,
                            loading = false,
                        ),
                    )

                    // Asked after the page is on screen, not before it: whether
                    // one album is in the library is not worth holding an
                    // artist's whole page for.
                    page.latest?.let { release ->
                        launch {
                            val kept = savedState(release.uri) ?: return@launch
                            if (isActive && _playlist.value.uri == playlist.uri) {
                                _playlist.value = _playlist.value.copy(latestSaved = kept)
                            }
                        }
                    }

                    // The playlists after the page too, and for the same
                    // reason: "This Is" and the rest are a row near the foot of
                    // it, and a second request is not worth holding the top for.
                    // The call that used to fill them went when this page's
                    // loading was rewritten, and the row went with it.
                    if (page.playlists.isEmpty()) {
                        launch {
                            val lists = artistPlaylistsFor(
                                playlist.uri,
                                page.name?.takeIf { it.isNotEmpty() } ?: base.name,
                            )
                            if (lists.isEmpty()) return@launch
                            artistPageCache[playlist.uri] = page.copy(playlists = lists)
                            if (isActive && _playlist.value.uri == playlist.uri) {
                                _playlist.value = _playlist.value.copy(artistPlaylists = lists)
                            }
                        }
                    }
                } else if (kind == DetailKind.SHOW) {
                    // A podcast: its page, then its episodes newest first. Read
                    // again on every visit rather than trusted from the copy,
                    // which is there to draw the page at once: a show gets new
                    // episodes, and how far into each one the listener got is
                    // part of what the list says.
                    awaitEngine()
                    val showAnswer = container.gateway.show(playlist.uri)
                    val show = showAnswer?.let(dev.lelonio.square.data.SpotifyPodcasts::parseShow)
                    if (show == null) {
                        android.util.Log.w(TAG, "show ${playlist.uri} unreadable: ${showAnswer?.take(400)}")
                    }
                    if (show != null) {
                        base = base.copy(
                            name = base.name.ifEmpty { show.name },
                            artworkUrl = show.artworkUrl ?: base.artworkUrl,
                            description = show.description,
                            byline = show.publisher,
                            saved = show.saved ?: base.saved,
                        )
                        if (isActive && _playlist.value.uri == playlist.uri) {
                            _playlist.value = _playlist.value.copy(
                                name = base.name,
                                artworkUrl = base.artworkUrl,
                                description = base.description,
                                byline = base.byline,
                                saved = base.saved,
                            )
                        }
                    }
                    val episodes = readShow(playlist.uri, base.name) { read, more ->
                        if (isActive && _playlist.value.uri == playlist.uri) {
                            publishPlaylist(base.copy(tracks = read, loading = false, loadingMore = more))
                        }
                    }
                    if (episodes != null) {
                        contextCache[playlist.uri] = ContextCacheStore.Entry(
                            tracks = episodes,
                            snapshotId = null,
                            savedAt = System.currentTimeMillis(),
                            uri = playlist.uri,
                        )
                        container.contextCache.write(playlist.uri, episodes, null)
                    } else if (cached.isEmpty()) {
                        error("the show's episodes did not come back")
                    }
                } else {
                    val freshness = if (cached.isEmpty()) {
                        Freshness.CHANGED
                    } else {
                        isUnchanged(playlist.uri, entry?.snapshotId)
                    }
                    val recent = (entry?.savedAt ?: 0) > System.currentTimeMillis() - STALE_AFTER_MS
                    if (freshness == Freshness.SAME || (freshness == Freshness.UNKNOWN && recent)) {
                        // Nothing to read again: either one small request said
                        // the copy on screen is the current one, or nobody
                        // could say and the copy is new enough to believe.
                        if (isActive && _playlist.value.uri == playlist.uri) {
                            publishPlaylist(base.copy(tracks = cached, loadingMore = false))
                        }
                        // The copy is the playlist as it is now, so a download
                        // of it that is behind can catch up from it.
                        followKept(playlist.uri, cached)
                        // A copy saved without a stamp is asked for one now, so
                        // the next open has a question to ask instead of a
                        // whole playlist to read.
                        if (entry != null && entry.snapshotId == null) launch {
                            val stamp = snapshotOf(playlist.uri) ?: return@launch
                            contextCache[playlist.uri] = entry.copy(snapshotId = stamp)
                            container.contextCache.write(playlist.uri, entry.tracks, stamp)
                        } else if (entry != null && freshness == Freshness.SAME) launch {
                            // Confirmed current, so it counts as just read.
                            //
                            // Only a full read used to date a copy. A playlist
                            // that never changes was never read in full again,
                            // so its copy kept the age of its first read: past
                            // six hours one failed check had it read from the
                            // top, past a week it expired, and as the oldest
                            // file in the cache it was the first one dropped
                            // to make room — the most used list, read again
                            // most often.
                            contextCache[playlist.uri] = entry.copy(savedAt = System.currentTimeMillis())
                            container.contextCache.write(playlist.uri, entry.tracks, entry.snapshotId)
                        }
                    } else {
                        loadContextInto(base, playlist.uri, showProgress = cached.isEmpty())
                    }
                }
            } catch (e: CancellationException) {
                // Cooperative cancellation: do NOT treat job cancellation as a failure or set error on the screen!
                throw e
            } catch (t: Throwable) {
                android.util.Log.e(TAG, "detail load failed: ${chain(t)}", t)
                if (isActive && _playlist.value.uri == playlist.uri) {
                    // Downloaded, it is on the phone whatever the network says:
                    // a connection that is up and carrying nothing fails here
                    // without the app being offline, and the songs it could
                    // play were hidden behind an error.
                    val downloaded = container.downloads.owners.value[playlist.uri]
                    if (cached.isEmpty() && rememberedArtist == null && downloaded != null) {
                        openDownloadedContext(playlist, downloaded)
                        return@launch
                    }
                    val hasCachedContent = cached.isNotEmpty() || rememberedArtist != null
                    val fallbackTracks = cached.ifEmpty { rememberedArtist?.tracks.orEmpty() }
                    publishPlaylist(
                        if (!hasCachedContent) base.copy(error = describe(t), loading = false) else base.copy(tracks = fallbackTracks, loading = false),
                    )
                }
            }
        }
    }

    /**
     * The music on this phone, read straight from the media index.
     *
     * Empty is two different answers, and the screen has to tell them apart:
     * a phone with no music on it, and a phone this app has not been allowed
     * to look at. The second is what [PlaylistState.needsPermission] says, and
     * it is the only case in the app where an empty list is something to act
     * on rather than to report.
     */
    /**
     * All songs downloaded to this phone, sorted newest first, updated live as downloads complete.
     */
    private fun openDownloadedTracks(playlist: CatalogPlaylist) {
        playlistJob?.cancel()
        val name = playlist.name.ifEmpty { string(R.string.downloaded_tracks) }
        val base = PlaylistState(
            uri = DownloadStore.SINGLES,
            name = name,
            artworkUrl = dev.lelonio.square.ui.components.DOWNLOADS_COVER,
            kind = DetailKind.PLAYLIST,
            mine = false,
        )

        val resolvedInMemory = mutableMapOf<String, CatalogTrack>()

        fun resolveList(uris: List<String>): List<CatalogTrack> {
            val known = uris.mapNotNull { container.downloads.trackOf(it) ?: resolvedInMemory[it] }
                .associateBy { it.uri }
            return uris.map { uri ->
                known[uri] ?: CatalogTrack(
                    uri = uri,
                    name = uri.substringAfterLast(':'),
                    artist = "",
                )
            }
        }

        // Snapshot of downloads right now so the user sees songs with 0 delay
        val filesSnapshot = container.downloads.files.value
        val uris = filesSnapshot.entries
            .sortedByDescending { it.value.downloadedAt }
            .map { it.key }

        val missingInitial = uris.filter { container.downloads.trackOf(it) == null }

        publishPlaylist(
            base.copy(
                tracks = resolveList(uris),
                loading = missingInitial.isNotEmpty(),
            ),
        )

        playlistJob = viewModelScope.launch {
            if (missingInitial.isNotEmpty() && !dev.lelonio.square.playback.OfflineMode.active.value) {
                runCatching {
                    val fetched = withContext(Dispatchers.IO) {
                        Catalog.tracks(missingInitial)
                    }
                    if (fetched.isNotEmpty()) {
                        fetched.forEach { resolvedInMemory[it.uri] = it }
                        publishPlaylist(base.copy(tracks = resolveList(uris), loading = false))
                    }
                }
            }

            // Observe downloads flow in real time while this screen is open
            container.downloads.files.collect { currentFiles ->
                val currentUris = currentFiles.entries
                    .sortedByDescending { it.value.downloadedAt }
                    .map { it.key }

                val missing = currentUris.filter { container.downloads.trackOf(it) == null && !resolvedInMemory.containsKey(it) }
                if (missing.isNotEmpty() && !dev.lelonio.square.playback.OfflineMode.active.value) {
                    runCatching {
                        val fetched = withContext(Dispatchers.IO) {
                            Catalog.tracks(missing)
                        }
                        if (fetched.isNotEmpty()) {
                            fetched.forEach { resolvedInMemory[it.uri] = it }
                        }
                    }
                }

                publishPlaylist(
                    base.copy(
                        tracks = resolveList(currentUris),
                        loading = false,
                    ),
                )
            }
        }
    }

    /** A downloaded list, read out of the index rather than off the network. */
    private fun openDownloadedContext(playlist: CatalogPlaylist, wanted: List<String>) {
        playlistJob?.cancel()
        val label = container.downloads.labelOf(playlist.uri)
        val resolvedTracks = wanted.map { uri ->
            container.downloads.trackOf(uri) ?: CatalogTrack(
                uri = uri,
                name = uri.substringAfterLast(':'),
                artist = "",
            )
        }
        publishPlaylist(
            PlaylistState(
                uri = playlist.uri,
                name = playlist.name.ifEmpty { label?.name.orEmpty() },
                artworkUrl = playlist.artworkUrl ?: label?.artworkUrl,
                kind = when (label?.kind) {
                    DownloadStore.KIND_ALBUM -> DetailKind.ALBUM
                    DownloadStore.KIND_ARTIST -> DetailKind.ARTIST
                    else -> DetailKind.PLAYLIST
                },
                tracks = resolvedTracks,
            ),
        )
    }

    private fun openLocalFiles(playlist: CatalogPlaylist) {
        playlistJob?.cancel()
        val base = PlaylistState(
            uri = playlist.uri,
            name = playlist.name,
            artworkUrl = playlist.artworkUrl ?: LocalLibrary.COVER,
            kind = DetailKind.PLAYLIST,
            mine = false,
        )
        publishPlaylist(base.copy(loading = true))

        playlistJob = viewModelScope.launch {
            val granted = LocalLibrary.granted(getApplication())
            val tracks = if (granted) LocalLibrary.tracks(getApplication()) else emptyList()
            publishPlaylist(
                base.copy(
                    tracks = tracks,
                    loading = false,
                    needsPermission = !granted,
                ),
            )
        }
    }

    /** Called once the listener has answered the system's permission dialog. */
    fun onLocalPermissionAnswered() {
        val open = _playlist.value
        if (open.uri != LocalLibrary.CONTEXT_URI) {
            viewModelScope.launch {
                deviceFiles = LocalLibrary.tracks(getApplication())
                val current = _playlist.value
                publishPlaylist(current)
            }
            return
        }
        openLocalFiles(
            CatalogPlaylist(
                uri = open.uri.orEmpty(),
                name = open.name,
                artworkUrl = LocalLibrary.COVER,
            ),
        )
    }

    /**
     * The picture at the top of a page opened by URI alone.
     *
     * The account's own playlists are already in hand, so those cost nothing.
     * Anything else is one request, and a page without a picture is a perfectly
     * good page, so every failure here is silent.
     */
    private suspend fun artworkFor(uri: String, kind: DetailKind): String? {
        (_state.value as? UiState.Ready)?.playlists
            ?.firstOrNull { it.uri == uri }
            ?.artworkUrl
            ?.let { return it }

        val id = uri.substringAfterLast(':')

        val fetched = runCatching {
            when (kind) {
                DetailKind.ARTIST -> if (container.webApi.isReady) container.api.artist(id).images.firstOrNull()?.url else null
                DetailKind.ALBUM -> if (container.webApi.isReady) container.api.album(id).images.firstOrNull()?.url else null
                DetailKind.PLAYLIST -> if (container.webApi.isReady) container.api.playlist(id).images.firstOrNull()?.url else null
                DetailKind.SHOW -> container.gateway.show(uri)
                    ?.let(dev.lelonio.square.data.SpotifyPodcasts::parseShow)?.artworkUrl
            }
        }
            .onFailure { android.util.Log.w(TAG, "no cover for $uri: ${describe(it)}") }
            .getOrNull()
        if (fetched != null) return fetched

        if (kind == DetailKind.ARTIST) {
            runCatching {
                dev.lelonio.square.data.SpotifyWebArtist.fetch(id, container.sharedHttpClient, getApplication<SquareApplication>().resources)?.artworkUrl
            }.getOrNull()?.takeIf { !it.isNullOrEmpty() }?.let { return it }
        }

        // The access point carries the art for the lists Spotify generates,
        // which is where the Web API answers 404.
        if (kind == DetailKind.PLAYLIST) return Catalog.playlistCover(uri)

        // An album's cover is on every one of its tracks, which is the way in
        // when the user has not registered an application of their own.
        if (kind != DetailKind.ALBUM) return null
        return contextCache[uri]?.tracks?.firstNotNullOfOrNull { it.artworkUrl }
    }

    /**
     * Whether the stored copy of a playlist is still the current one.
     *
     * Spotify changes a playlist's `snapshot_id` whenever its contents do, so
     * this is one request against a dozen. False for anything without a stored
     * stamp — an album, a list read through the access point — which simply
     * means it is refreshed as before, silently, behind what is already shown.
     */
    private suspend fun isUnchanged(uri: String, snapshotId: String?): Freshness {
        if (snapshotId == null) return Freshness.UNKNOWN
        if (!container.webApi.isReady || !uri.startsWith("spotify:playlist:")) return Freshness.UNKNOWN
        val id = uri.substringAfterLast(':')
        repeat(SNAPSHOT_TRIES) { attempt ->
            val answer = runCatching { container.api.playlistSnapshot(id).snapshotId }
                .onFailure { android.util.Log.w(TAG, "snapshot check failed: ${describe(it)}") }
            answer.getOrNull()?.let {
                return if (it == snapshotId) Freshness.SAME else Freshness.CHANGED
            }
            // Spotify metering answers a burst with 429, and the next second
            // it answers properly. Worth one more try before a thousand-track
            // playlist is read again from the top.
            val retryable = answer.exceptionOrNull()?.let { describe(it).contains("429") } == true
            if (!retryable || attempt == SNAPSHOT_TRIES - 1) return Freshness.UNKNOWN
            delay(SNAPSHOT_RETRY_MS)
        }
        return Freshness.UNKNOWN
    }

    /**
     * What a version check could say about a stored copy.
     *
     * [UNKNOWN] is the answer that used to be read as [CHANGED]: no token yet
     * in the first seconds after a start, a refused request, a playlist saved
     * before its stamp could be had. Every one of those read a thousand-track
     * playlist again from the top for nothing, which is minutes of paging on a
     * list that had not moved. It is now trusted for [STALE_AFTER_MS], after
     * which a copy nobody can vouch for is read again.
     */
    private enum class Freshness { SAME, CHANGED, UNKNOWN }

    /**
     * Removes a track from the playlist currently open.
     *
     * Optimistic, unlike adding: the row disappearing *is* the confirmation, and
     * putting it back is a possible outcome the user can see, whereas a row that
     * sits there for a round trip before vanishing reads as a tap that missed.
     * Every occurrence goes, which matters only on a playlist holding the same
     * track twice; see SpotifyApi.removeFromPlaylist.
     */
    fun removeFromPlaylist(track: CatalogTrack) {
        val uri = _playlist.value.uri ?: return
        // The other source removes through its own account; the same
        // optimistic row going and coming back if it refuses.
        if (!uri.startsWith("spotify:") && container.activeBackend.owns(uri)) {
            val before = _playlist.value.tracks
            _playlist.value = _playlist.value.copy(tracks = before.filterNot { it.uri == track.uri })
            invalidateContext(uri)
            viewModelScope.launch {
                runCatching { container.activeBackend.removeFromPlaylist(uri, track.uri) }
                    .onFailure {
                        android.util.Log.e(TAG, "remove from playlist failed: ${chain(it)}", it)
                        if (_playlist.value.uri == uri) {
                            _playlist.value = _playlist.value.copy(tracks = before)
                        }
                    }
            }
            return
        }
        if (!uri.startsWith("spotify:playlist:")) return
        _takenOut.value = _takenOut.value + "$uri|${track.uri}"

        val before = _playlist.value.tracks
        _playlist.value = _playlist.value.copy(tracks = before.filterNot { it.uri == track.uri })
        invalidateContext(uri)

        viewModelScope.launch {
            runCatching {
                if (LocalLibrary.isSpotifyLocal(track.uri)) {
                    // The Web API cannot take out what it could not put in.
                    withContext(Dispatchers.IO) {
                        dev.lelonio.square.nativecore.NativeBridge.removeFromPlaylist(uri, track.uri)
                    }
                } else {
                    container.api.removeFromPlaylist(
                        uri.substringAfterLast(':'),
                        RemoveTracksRequestDto(listOf(TrackUriDto(track.uri))),
                    )
                }
            }.onFailure {
                android.util.Log.e(TAG, "remove from playlist failed: ${chain(it)}", it)
                _takenOut.value = _takenOut.value - "$uri|${track.uri}"
                // Only if the screen is still showing the same playlist.
                if (_playlist.value.uri == uri) {
                    _playlist.value = _playlist.value.copy(tracks = before)
                }
            }
        }
    }

    /** Whether the active source lets the account make and change playlists. */
    val canEditPlaylists: Boolean get() = container.activeBackend.canEditPlaylists

    /** Whether a track can be taken out of this particular list. */
    fun canRemoveFrom(playlistUri: String?): Boolean {
        val uri = playlistUri ?: return false
        return if (uri.startsWith("spotify:")) {
            container.activeBackend.id == BackendId.SPOTIFY
        } else {
            container.activeBackend.owns(uri) && container.activeBackend.canWriteTo(uri)
        }
    }

    /** Whether the active source's pages and songs can be kept on the phone. */
    fun canKeep(uri: String?): Boolean {
        val it = uri ?: return false
        val backend = container.activeBackend
        return backend.owns(it) && when (backend.id) {
            // The official SDK streams and keeps nothing; see WebSdkRecovery.inUse.
            BackendId.SPOTIFY -> it.startsWith("spotify:") && !LocalLibrary.isSpotifyLocal(it) &&
                !dev.lelonio.square.playback.websdk.WebSdkRecovery.inUse.value
            BackendId.YOUTUBE_MUSIC -> true
        }
    }

    /**
     * Makes a playlist and puts it at the top of the library.
     *
     * Inserted locally rather than by refetching: the service takes a moment to
     * list a playlist it has just created, and a new playlist that does not
     * appear reads as the button having failed.
     */
    /** The new-playlist sheet: whether it is waiting, and what went wrong. */
    data class CreatePlaylistState(val busy: Boolean = false, val error: String? = null)

    private val _creatingPlaylist = MutableStateFlow(CreatePlaylistState())
    val creatingPlaylist: StateFlow<CreatePlaylistState> = _creatingPlaylist.asStateFlow()

    fun resetCreatePlaylist() {
        _creatingPlaylist.value = CreatePlaylistState()
    }

    /** Whether the active source takes a description, a visibility and a cover. */
    val describesPlaylists: Boolean get() = container.activeBackend.describesPlaylists

    /**
     * Makes a playlist, puts it at the top of the library and hands it to
     * [onCreated], which opens it.
     *
     * The sheet stays up until the service answers: a playlist that might or
     * might not exist is worse than a moment's wait, and a refusal is said on
     * the sheet rather than in the log. The cover goes up after, and a cover
     * that fails does not take the playlist with it: it is said in a toast,
     * with what to do when the reason is a missing permission.
     */
    fun createPlaylist(
        name: String,
        description: String,
        public: Boolean,
        cover: android.net.Uri?,
        onCreated: (CatalogPlaylist) -> Unit,
    ) {
        if (_creatingPlaylist.value.busy) return
        _creatingPlaylist.value = CreatePlaylistState(busy = true)
        viewModelScope.launch {
            val backend = container.activeBackend
            runCatching { backend.createPlaylist(name.trim(), description, public) }
                .onSuccess { created ->
                    (_state.value as? UiState.Ready)?.let { ready ->
                        _state.value = ready.copy(playlists = listOf(created) + ready.playlists)
                    }
                    if (cover != null && backend.describesPlaylists) {
                        runCatching {
                            val jpeg = withContext(Dispatchers.Default) { coverJpeg(cover) }
                            backend.setPlaylistCover(created.uri, jpeg)
                        }.onSuccess {
                            fetchUploadedCover(created.uri)
                        }.onFailure {
                            android.util.Log.e(TAG, "playlist cover failed: ${chain(it)}", it)
                            val permission = describe(it).let { why -> "401" in why || "403" in why }
                            android.widget.Toast.makeText(
                                getApplication(),
                                string(if (permission) R.string.cover_needs_permission else R.string.cover_failed),
                                android.widget.Toast.LENGTH_LONG,
                            ).show()
                        }
                    }
                    _creatingPlaylist.value = CreatePlaylistState()
                    onCreated(created)
                }
                .onFailure {
                    android.util.Log.e(TAG, "create playlist failed: ${chain(it)}", it)
                    _creatingPlaylist.value = CreatePlaylistState(error = string(R.string.create_playlist_failed))
                }
        }
    }

    /** Songs offered under one of the account's own playlists. */
    data class SuggestionsState(
        val playlistUri: String? = null,
        val tracks: List<CatalogTrack> = emptyList(),
        val loading: Boolean = false,
    )

    private val _suggestions = MutableStateFlow(SuggestionsState())
    val suggestions: StateFlow<SuggestionsState> = _suggestions.asStateFlow()
    private var suggestionsJob: Job? = null

    /**
     * Songs to add to a playlist of the account's own, as Spotify offers
     * under one.
     *
     * Drawn from the stations of a couple of its songs, picked at random so
     * that asking again brings different ones, or of liked songs while the
     * playlist is still empty. Nothing already in it is offered.
     */
    fun loadSuggestions(playlistUri: String, refresh: Boolean = false) {
        if (!playlistUri.startsWith("spotify:playlist:")) return
        val current = _suggestions.value
        if (!refresh && current.playlistUri == playlistUri && (current.loading || current.tracks.isNotEmpty())) return
        suggestionsJob?.cancel()
        _suggestions.value = SuggestionsState(playlistUri, loading = true)
        suggestionsJob = viewModelScope.launch {
            val present = _playlist.value.takeIf { it.uri == playlistUri }?.tracks.orEmpty()
            val presentUris = present.mapTo(mutableSetOf()) { it.uri }
            val seeds = present.map { it.uri }.filter { it.startsWith("spotify:track:") }
                .ifEmpty { container.likedStore.likedTracks.value.toList() }
                .shuffled()
                .take(SUGGESTION_SEEDS)
            val uris = seeds.flatMap { seed ->
                runCatching { Catalog.contextTrackUris("spotify:station:track:${seed.substringAfterLast(':')}") }
                    .getOrDefault(emptyList())
            }
                .filter { it.startsWith("spotify:track:") && it !in presentUris && it !in seeds }
                .distinct()
                .shuffled()
                .take(SUGGESTION_COUNT)
            val tracks = runCatching { Catalog.tracks(uris) }
                .onFailure { android.util.Log.w(TAG, "suggestions unavailable: ${describe(it)}") }
                .getOrDefault(emptyList())
            if (_suggestions.value.playlistUri == playlistUri) {
                _suggestions.value = SuggestionsState(playlistUri, tracks)
            }
        }
    }

    /**
     * One of [suggestions], into the playlist on screen. At once on screen,
     * and back among the suggestions if Spotify refuses it.
     */
    fun addSuggestion(track: CatalogTrack) {
        val uri = _playlist.value.uri?.takeIf { it.startsWith("spotify:playlist:") } ?: return
        _suggestions.value = _suggestions.value.copy(tracks = _suggestions.value.tracks.filterNot { it.uri == track.uri })
        _playlist.value = _playlist.value.copy(tracks = _playlist.value.tracks + track)
        invalidateContext(uri)
        viewModelScope.launch {
            runCatching { container.api.addToPlaylist(uri.substringAfterLast(':'), AddTracksRequestDto(listOf(track.uri))) }
                .onFailure {
                    android.util.Log.e(TAG, "add suggestion failed: ${chain(it)}", it)
                    if (_playlist.value.uri == uri) {
                        _playlist.value = _playlist.value.copy(tracks = _playlist.value.tracks.filterNot { it.uri == track.uri })
                    }
                    if (_suggestions.value.playlistUri == uri) {
                        _suggestions.value = _suggestions.value.copy(tracks = listOf(track) + _suggestions.value.tracks)
                    }
                }
        }
    }

    private val SUGGESTION_SEEDS = 2
    private val SUGGESTION_COUNT = 10

    /** The edit sheet of an existing playlist: what it shows and how it is going. */
    data class EditPlaylistState(
        val playlist: CatalogPlaylist,
        val details: dev.lelonio.square.backend.PlaylistDetails? = null,
        val loading: Boolean = false,
        val busy: Boolean = false,
        val error: String? = null,
    )

    private val _editingPlaylist = MutableStateFlow<EditPlaylistState?>(null)
    val editingPlaylist: StateFlow<EditPlaylistState?> = _editingPlaylist.asStateFlow()

    /** Opens the edit sheet, reading what the playlist has now where the source keeps it. */
    fun openEditPlaylist(playlist: CatalogPlaylist) {
        val backend = container.activeBackend
        val plain = dev.lelonio.square.backend.PlaylistDetails(playlist.name, "", false, playlist.artworkUrl)
        if (!backend.describesPlaylists) {
            _editingPlaylist.value = EditPlaylistState(playlist, details = plain)
            return
        }
        _editingPlaylist.value = EditPlaylistState(playlist, loading = true)
        viewModelScope.launch {
            val details = runCatching { backend.playlistDetails(playlist.uri) }
                .onFailure { android.util.Log.w(TAG, "playlist details unavailable: ${describe(it)}") }
                .getOrNull() ?: plain
            _editingPlaylist.value = _editingPlaylist.value
                ?.takeIf { it.playlist.uri == playlist.uri }
                ?.copy(details = details, loading = false)
        }
    }

    fun closeEditPlaylist() {
        _editingPlaylist.value = null
    }

    /**
     * Saves the edit sheet. The sheet waits for the service, as the new one
     * does, and the cover follows as it does there: a cover that fails leaves
     * the rest saved.
     */
    fun savePlaylist(name: String, description: String, public: Boolean, cover: android.net.Uri?) {
        val editing = _editingPlaylist.value ?: return
        if (editing.busy) return
        val uri = editing.playlist.uri
        val trimmed = name.trim()
        _editingPlaylist.value = editing.copy(busy = true, error = null)
        viewModelScope.launch {
            val backend = container.activeBackend
            runCatching { backend.updatePlaylist(uri, trimmed, description, public) }
                .onSuccess {
                    (_state.value as? UiState.Ready)?.let { ready ->
                        _state.value = ready.copy(
                            playlists = ready.playlists.map { if (it.uri == uri) it.copy(name = trimmed) else it },
                        )
                    }
                    if (_playlist.value.uri == uri) {
                        _playlist.value = _playlist.value.copy(name = trimmed, description = description.trim())
                    }
                    invalidateContext(uri)
                    // A service that takes no picture: kept on this phone (#157).
                    if (cover != null && !backend.describesPlaylists) {
                        runCatching {
                            withContext(Dispatchers.IO) {
                                dev.lelonio.square.data.PlaylistCovers.save(uri, coverJpeg(cover))
                            }
                        }.onFailure {
                            android.util.Log.e(TAG, "local playlist cover failed: ${chain(it)}", it)
                        }.getOrNull()?.let { file ->
                            (_state.value as? UiState.Ready)?.let { ready ->
                                _state.value = ready.copy(
                                    playlists = ready.playlists.map { if (it.uri == uri) it.copy(artworkUrl = file) else it },
                                )
                            }
                            if (_playlist.value.uri == uri) _playlist.value = _playlist.value.copy(artworkUrl = file)
                        }
                    }
                    if (cover != null && backend.describesPlaylists) {
                        runCatching {
                            val jpeg = withContext(Dispatchers.Default) { coverJpeg(cover) }
                            backend.setPlaylistCover(uri, jpeg)
                        }.onSuccess {
                            coverCache.remove(uri)
                            fetchUploadedCover(uri)
                        }.onFailure {
                            android.util.Log.e(TAG, "playlist cover failed: ${chain(it)}", it)
                            val permission = describe(it).let { why -> "401" in why || "403" in why }
                            android.widget.Toast.makeText(
                                getApplication(),
                                string(if (permission) R.string.cover_needs_permission else R.string.cover_failed),
                                android.widget.Toast.LENGTH_LONG,
                            ).show()
                        }
                    }
                    _editingPlaylist.value = null
                }
                .onFailure {
                    android.util.Log.e(TAG, "edit playlist failed: ${chain(it)}", it)
                    _editingPlaylist.value = _editingPlaylist.value?.copy(
                        busy = false,
                        error = string(R.string.save_playlist_failed),
                    )
                }
        }
    }

    /**
     * The cover Spotify made of an upload, put on the library's tile.
     *
     * The picker's own address for the picture is no use for this: it is
     * readable only while the grant lasts, and a tile holding it stayed blank
     * once it lapsed — and was never looked up again, since it was not empty.
     * Spotify takes an upload and makes its sizes afterwards, so the cover is
     * asked for a few times before giving up.
     */
    private fun fetchUploadedCover(uri: String) = viewModelScope.launch {
        // A playlist that had a cover goes on answering with it until the new
        // one is ready.
        val previous = (_state.value as? UiState.Ready)?.playlists?.firstOrNull { it.uri == uri }?.artworkUrl
        repeat(COVER_POLLS) {
            delay(COVER_POLL_MS)
            val url = Catalog.playlistCover(uri)?.takeIf { it.isNotEmpty() && it != previous } ?: return@repeat
            coverCache[uri] = url
            (_state.value as? UiState.Ready)?.let { ready ->
                _state.value = ready.copy(
                    playlists = ready.playlists.map { if (it.uri == uri) it.copy(artworkUrl = url) else it },
                )
            }
            if (_playlist.value.uri == uri) _playlist.value = _playlist.value.copy(artworkUrl = url)
            return@launch
        }
    }

    private val COVER_POLLS = 6
    private val COVER_POLL_MS = 1_500L

    /**
     * The picture as Spotify takes a cover: square, cut from the middle, at
     * most 640 pixels a side, and a JPEG whose base64 fits in 256 KB.
     */
    private fun coverJpeg(uri: android.net.Uri): ByteArray {
        val resolver = getApplication<android.app.Application>().contentResolver
        val source = resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
            ?: error("cannot read $uri")
        val side = minOf(source.width, source.height)
        val square = android.graphics.Bitmap.createBitmap(
            source, (source.width - side) / 2, (source.height - side) / 2, side, side,
        )
        val scaled = if (side > COVER_SIDE) {
            android.graphics.Bitmap.createScaledBitmap(square, COVER_SIDE, COVER_SIDE, true)
        } else {
            square
        }
        var quality = 90
        while (true) {
            val bytes = java.io.ByteArrayOutputStream().use { out ->
                scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, out)
                out.toByteArray()
            }
            // Base64 is four characters for every three bytes.
            if (bytes.size * 4 / 3 <= COVER_MAX_BASE64 || quality <= 30) return bytes
            quality -= 10
        }
    }

    private val COVER_SIDE = 640
    private val COVER_MAX_BASE64 = 256 * 1024

    fun renamePlaylist(uri: String, name: String) = viewModelScope.launch {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return@launch
        // Renamed on screen first: this is one field on a row, the failure is
        // rare, and putting the old name back is all an undo needs to be.
        val ready = _state.value as? UiState.Ready
        val before = ready?.playlists
        if (ready != null) {
            _state.value = ready.copy(
                playlists = ready.playlists.map {
                    if (it.uri == uri) it.copy(name = trimmed) else it
                },
            )
        }
        if (_playlist.value.uri == uri) {
            _playlist.value = _playlist.value.copy(name = trimmed)
        }

        runCatching { container.activeBackend.renamePlaylist(uri, trimmed) }
            .onFailure {
                android.util.Log.e(TAG, "rename playlist failed: ${chain(it)}", it)
                val current = _state.value as? UiState.Ready
                if (before != null && current != null) {
                    _state.value = current.copy(playlists = before)
                }
            }
        invalidateContext(uri)
    }

    fun deletePlaylist(uri: String) = viewModelScope.launch {
        val ready = _state.value as? UiState.Ready
        val before = ready?.playlists
        if (ready != null) {
            _state.value = ready.copy(playlists = ready.playlists.filterNot { it.uri == uri })
        }

        runCatching { container.activeBackend.deletePlaylist(uri) }
            .onSuccess { dev.lelonio.square.data.PlaylistCovers.forget(uri) }
            .onFailure {
                android.util.Log.e(TAG, "delete playlist failed: ${chain(it)}", it)
                val current = _state.value as? UiState.Ready
                if (before != null && current != null) {
                    _state.value = current.copy(playlists = before)
                }
            }
        invalidateContext(uri)
    }

    /** Drops a context from both caches so the next open re-reads it. */
    private fun invalidateContext(uri: String) {
        contextCache.remove(uri)
        viewModelScope.launch { container.contextCache.remove(uri) }
        // A song just added to, or taken out of, a list that is kept: read
        // again now rather than on the next open, so the download follows the
        // change while the listener is still looking at it. Spotify's too:
        // left to the next open, a song added from here to a downloaded
        // playlist was not downloaded until the playlist was opened again,
        // which read as the download not following at all (discussion #87).
        if (container.downloads.owners.value.containsKey(uri)) {
            viewModelScope.launch {
                if (uri.startsWith("spotify:")) {
                    followKeptSpotify(uri)
                } else {
                    runCatching { container.activeBackend.tracksOf(uri) }
                        .onSuccess { followKept(uri, it) }
                }
            }
        }
    }

    /**
     * A kept Spotify list read again in full and followed; see [followKept].
     *
     * Read quietly (nothing on screen changes) and stored as the cached copy
     * too, stamped with its version, so the next open is free.
     */
    private suspend fun followKeptSpotify(uri: String) {
        val tracks = runCatching {
            pagedTracks(PlaylistState(uri = uri), uri, showProgress = false)
        }.onFailure { android.util.Log.w(TAG, "kept $uri not read: ${describe(it)}") }
            .getOrNull()
            ?.takeIf { it.isNotEmpty() }
            ?: return
        followKept(uri, tracks)
        // Unstamped while a song in it is still only a name, so the next open
        // reads it again rather than trusting this copy until the version moves.
        val snapshotId = if (tracks.any(::isSparse)) null else snapshotOf(uri)
        contextCache[uri] = ContextCacheStore.Entry(tracks, snapshotId)
        container.contextCache.write(uri, tracks, snapshotId)
    }

    /**
     * Resolves a whole playlist or album.
     *
     * Two sources, and which one is used matters more than anything else on this
     * screen. The Web API returns a hundred *complete* tracks per request, so a
     * twelve-hundred-track playlist is a dozen requests. The access point
     * answers with URIs and then charges one round trip per track to turn each
     * into a name — the same playlist is twelve hundred lookups, minutes of
     * waiting, and enough of them get dropped that the total came out different
     * on every open. So the Web API is the path whenever the user has connected
     * their application, and the access point is the fallback for when they have
     * not.
     *
     * @param showProgress publish each page as it arrives. Off when there is a
     *   cached list on screen: a finished list must not be replaced by a
     *   growing one.
     */
    private suspend fun loadContextInto(base: PlaylistState, uri: String, showProgress: Boolean) {
        val paged = runCatching { pagedTracks(base, uri, showProgress) }
            .onFailure { android.util.Log.w(TAG, "paged read failed: ${describe(it)}") }
            .getOrNull()

        var tracks = paged ?: accessPointTracks(base, uri, showProgress)
        if (uri.endsWith(":collection")) {
            val priorCached = contextCache[uri]?.tracks?.takeIf { it.isNotEmpty() }
                ?: container.contextCache.read(uri)?.tracks?.takeIf { it.isNotEmpty() }
            if (tracks.isEmpty() && priorCached != null) {
                tracks = priorCached
            }
            val localLikedUris = container.likedStore.likedTracks.value
            val existingUris = tracks.map { it.uri }.toSet()
            val priorPool = (priorCached.orEmpty() + contextCache.values.flatMap { it.tracks })
            val localExtras = priorPool
                .filter { it.uri in localLikedUris && it.uri !in existingUris }
                .distinctBy { it.uri }
            if (localExtras.isNotEmpty()) {
                tracks = localExtras + tracks
            }
            if (tracks.isEmpty() && localLikedUris.isNotEmpty()) {
                val loaded = runCatching { Catalog.tracks(localLikedUris.toList()) }.getOrDefault(emptyList())
                if (loaded.isNotEmpty()) {
                    tracks = loaded
                }
            }
            container.likedStore.seed(tracks.map { it.uri })
        }

        publishPlaylist(base.copy(tracks = tracks, loadingMore = false))

        // Stamped with the version it was read from, so the next open can ask
        // one question instead of reading it all again. Without a stamp the
        // entry still saves — it just gets refreshed silently every time.
        followKept(uri, tracks)
        // Unstamped while a song in it is still only a name, so the next open
        // reads it again rather than trusting this copy until the version moves.
        val snapshotId = if (tracks.any(::isSparse)) null else snapshotOf(uri)
        contextCache[uri] = ContextCacheStore.Entry(tracks, snapshotId)
        rememberMembership(uri, tracks)
        container.contextCache.write(uri, tracks, snapshotId)
    }

    /**
     * How long a stored copy nobody could vouch for is used anyway, and how a
     * refused version check is retried; see [Freshness].
     */
    private val STALE_AFTER_MS = 6L * 60 * 60 * 1000
    private val SNAPSHOT_TRIES = 2
    private val SNAPSHOT_RETRY_MS = 700L

    /** The playlist's current version stamp, or null if it has none to give. */
    private suspend fun snapshotOf(uri: String): String? {
        if (!container.webApi.isReady || !uri.startsWith("spotify:playlist:")) return null
        return runCatching {
            container.api.playlistSnapshot(uri.substringAfterLast(':')).snapshotId
        }.getOrNull()
    }

    /**
     * A playlist or the saved tracks, paged.
     *
     * Spotify's gateway first and the Web API behind it, for both. The gateway
     * is the endpoint the web player itself reads and it answers for anyone
     * logged in, two hundred whole tracks a request; the Web API is metered
     * against an application the listener has to register for themselves, and
     * gives a hundred. So the Web API is what is left when a query hash has
     * been retired, rather than the way in.
     *
     * Null when this is neither of those — an album, a list from the access
     * point — which is the caller's cue to resolve it the other way.
     */
    private suspend fun pagedTracks(
        base: PlaylistState,
        uri: String,
        showProgress: Boolean,
    ): List<CatalogTrack>? {
        if (uri.endsWith(":collection")) {
            gatewayTracks(base, showProgress) { offset ->
                container.gateway.savedTracks(offset)
            }?.let { return completeSparse(it) }
            // Nothing else knows this list: the access point refuses the
            // collection as a context, so without the gateway and without a
            // registered application there is no answer to give.
            check(container.webApi.isReady || container.tokenStore.isLoggedIn) { string(R.string.liked_songs_failed) }
            return webApiSavedTracks(base, showProgress)
        }

        if (!uri.startsWith("spotify:playlist:")) return null
        gatewayTracks(base, showProgress) { offset ->
            container.gateway.playlistTracks(uri, offset)
        }?.let { return completeSparse(it) }
        if (!container.webApi.isReady) return null
        return webApiPlaylistTracks(base, uri, showProgress)
    }

    /**
     * A song the gateway named and nothing more: no artist, no length.
     *
     * What it answers for a song added to a playlist moments before, until
     * its own copy of the list catches up, and it caught up in its own time:
     * the rows stayed a letter and a dash for a while after every addition
     * (issue #93).
     */
    private fun isSparse(track: CatalogTrack): Boolean =
        track.uri.startsWith("spotify:track:") && track.artist.isBlank() && track.durationMs <= 0L

    /**
     * [tracks] with the [isSparse] ones looked up again, through the access
     * point rather than the gateway that answered short. Whatever it cannot
     * answer either stays as it was.
     */
    private suspend fun completeSparse(tracks: List<CatalogTrack>): List<CatalogTrack> {
        val sparse = tracks.filter(::isSparse).map { it.uri }.distinct()
        if (sparse.isEmpty()) return tracks
        val found = runCatching { Catalog.tracks(sparse) }
            .onFailure { android.util.Log.w(TAG, "sparse tracks not completed: ${describe(it)}") }
            .getOrDefault(emptyList())
            .filterNot(::isSparse)
            .associateBy { it.uri }
        android.util.Log.i(TAG, "completed ${found.size} of ${sparse.size} sparse tracks")
        return tracks.map { track ->
            found[track.uri]?.takeIf { isSparse(track) }?.copy(addedAt = track.addedAt) ?: track
        }
    }

    /** The shared gateway reader, with each page published as it lands. */
    private suspend fun gatewayTracks(
        base: PlaylistState,
        showProgress: Boolean,
        page: suspend (offset: Int) -> GatewayPage?,
    ): List<CatalogTrack>? = container.gateway.readAll(
        onPage = if (showProgress) {
            { tracks, more -> publishPlaylist(base.copy(tracks = tracks, loadingMore = more)) }
        } else {
            null
        },
        page = page,
    )

    /** A playlist through the listener's own application; see [pagedTracks]. */
    private suspend fun webApiPlaylistTracks(
        base: PlaylistState,
        uri: String,
        showProgress: Boolean,
    ): List<CatalogTrack> {
        val id = uri.substringAfterLast(':')
        val loaded = mutableListOf<CatalogTrack>()
        var offset = 0
        while (true) {
            val page = container.api.playlistTracks(id, limit = WEB_API_PAGE, offset = offset, market = userCountry)
            // Episodes and delisted tracks come back as a null track, and
            // `is_playable` is false for anything the relinking could not find a
            // licensed copy of here. Keeping those would put items in the queue
            // that the engine can only skip.
            loaded += page.items.mapNotNull { item ->
                item.track
                    ?.takeIf {
                        (it.isPlayable != false && it.uri.startsWith("spotify:track:")) ||
                            LocalLibrary.isSpotifyLocal(it.uri)
                    }
                    ?.toCatalogTrack(item.addedAt)
            }
            offset += page.items.size
            if (showProgress) {
                publishPlaylist(base.copy(
                    tracks = loaded.toList(),
                    loadingMore = offset < page.total,
                ))
            }
            if (page.items.isEmpty() || offset >= page.total) return loaded
        }
    }

    /** Liked Songs through the listener's own application; see [pagedTracks]. */
    private suspend fun webApiSavedTracks(
        base: PlaylistState,
        showProgress: Boolean,
    ): List<CatalogTrack> {
        val loaded = mutableListOf<CatalogTrack>()
        var offset = 0
        while (true) {
            val page = container.api.savedTracks(limit = WEB_API_LIBRARY_PAGE, offset = offset)
            // The same rule as a playlist's pages: anything the engine could
            // only skip has no business being in the queue.
            loaded += page.items.mapNotNull { saved ->
                saved.track
                    .takeIf { it.isPlayable != false && it.uri.startsWith("spotify:track:") }
                    ?.toCatalogTrack(saved.addedAt)
            }
            offset += page.items.size
            if (showProgress) {
                publishPlaylist(base.copy(
                    tracks = loaded.toList(),
                    loadingMore = offset < page.total,
                ))
            }
            if (page.items.isEmpty() || offset >= page.total) return loaded
        }
    }

    private suspend fun accessPointTracks(
        base: PlaylistState,
        uri: String,
        showProgress: Boolean,
    ): List<CatalogTrack> {
        val uris = Catalog.contextTrackUris(uri)
        if (uris.isEmpty()) return emptyList()

        val batches = uris.chunked(METADATA_BATCH)
        val loaded = mutableListOf<CatalogTrack>()
        batches.forEachIndexed { index, batch ->
            loaded += Catalog.tracks(batch)
            if (showProgress) {
                publishPlaylist(base.copy(
                    tracks = loaded.toList(),
                    // Counted in batches, not in tracks: a delisted track
                    // resolves to nothing, so the list is legitimately shorter
                    // than the URIs asked for and comparing the two totals left
                    // "more coming" on forever.
                    loadingMore = index < batches.lastIndex,
                ))
            }
        }
        return loaded
    }

    /**
     * The artwork the record a track comes from carries, for the player.
     *
     * A song in Apple's catalogue has one square picture and nothing else; the
     * tall one and the moving one belong to its album, which is where their own
     * player takes them from too. Empty until a track is playing, and empty
     * again for anything the catalogue does not have — the player then shows the
     * square cover it already had.
     */
    private val _nowPlayingArt = MutableStateFlow<dev.lelonio.square.data.AppleCatalog.Album?>(null)
    val nowPlayingArt: StateFlow<dev.lelonio.square.data.AppleCatalog.Album?> =
        _nowPlayingArt.asStateFlow()

    /**
     * Whether the other catalogue is still being asked about this track.
     *
     * The player holds its picture back while this is true. Spotify's cover is
     * already in hand and could be drawn at once, but on a track that is about
     * to have a better copy of the same artwork that only means showing the
     * soft one and swapping it in front of the listener. Capped, so a slow
     * network costs a moment of plain colour rather than a player with no
     * picture at all.
     */
    private val _nowPlayingArtPending = MutableStateFlow(false)
    val nowPlayingArtPending: StateFlow<Boolean> = _nowPlayingArtPending.asStateFlow()

    private var nowPlayingArtJob: Job? = null
    private var prefetchArtJob: Job? = null

    /**
     * Looks up, and downloads, the artwork of the song that comes next.
     *
     * The wait a listener notices is not the picture arriving — thirty
     * kilobytes on a wifi is nothing — it is everything before it: a search of
     * the other catalogue, then a fetch, then a decode of a picture sixteen
     * hundred across, all of it started at the moment the song changed. Done
     * for the *next* song while the current one plays, all three are over
     * before the change, and the answer is waiting in the caches the real
     * lookup reads.
     *
     * Fails quietly and cancels freely: nothing on screen depends on it.
     */
    /**
     * [prefetchArt] for a song queued on another device, whose record's name
     * did not come with it.
     */
    fun prefetchRemoteArt(uri: String, title: String, artist: String) {
        if (artist.isBlank() || dev.lelonio.square.playback.OfflineMode.active.value) return
        viewModelScope.launch {
            val record = withContext(Dispatchers.IO) {
                runCatching { container.activeBackend.tracksOf(uri).firstOrNull()?.album }.getOrNull()
            }.orEmpty()
            prefetchArt(title, record, artist)
        }
    }

    fun prefetchArt(title: String, album: String, artist: String) {
        if (artist.isBlank() || dev.lelonio.square.playback.OfflineMode.active.value) return
        prefetchArtJob?.cancel()
        prefetchArtJob = viewModelScope.launch {
            val found = dev.lelonio.square.data.AppleCatalog.album(album, artist)
                .takeIf { album.isNotBlank() }
            val cover = found?.coverUrl
                ?: dev.lelonio.square.data.AppleCatalog.song(title, artist, album)
            // The bytes and the decode as well as the answer: Coil keeps what it
            // has already read, and this is the half that takes the longest.
            val context = getApplication<SquareApplication>()
            // At the size the player will ask for, not at the picture's own.
            // Coil files what it has decoded under the size it decoded it at, so
            // a copy read at sixteen hundred across is not the copy the screen
            // wants and the decode happens again in front of the listener. The
            // header fills the width at three by four.
            val width = context.resources.displayMetrics.widthPixels
            val height = width * DETAIL_TALL / DETAIL_WIDE
            listOfNotNull(found?.heroUrl, cover).forEach { url ->
                runCatching {
                    context.imageLoader.enqueue(
                        coil.request.ImageRequest.Builder(context)
                            .data(url)
                            .size(width, height)
                            .scale(coil.size.Scale.FILL)
                            .build(),
                    )
                }
            }
            // And the colour the page takes from it, which is a second read of
            // the same file: without this the cover arrived out of memory in one
            // frame and the page followed it a moment later. See
            // warmArtworkColor.
            (found?.heroUrl ?: cover)?.let { url ->
                runCatching {
                    dev.lelonio.square.ui.theme.warmArtworkColor(context, url)
                }
            }
        }
    }

    /**
     * The record a track is on, asked for when nothing already knew it.
     *
     * The address travels with the queue where the source gave one, but a
     * playlist resolved before this app kept it — the copies on disk outlive a
     * version — has only the album's name. Rather than leave the title inert on
     * those, it is looked up once, on the tap.
     */
    suspend fun albumOf(trackUri: String): CatalogPlaylist? {
        if (!trackUri.startsWith("spotify:track:") || !container.webApi.isReady) return null
        val id = trackUri.substringAfterLast(':')
        val dto = runCatching { container.api.track(id) }
            .onFailure { android.util.Log.w(TAG, "no album for $trackUri: ${describe(it)}") }
            .getOrNull() ?: return null
        val album = dto.album ?: return null
        val uri = album.uri ?: return null
        return CatalogPlaylist(
            uri = uri,
            name = album.name,
            artworkUrl = album.images.firstOrNull()?.url,
        )
    }

    /**
     * Resolves the artist for a track.
     *
     * Prefers the track's own artistUri or first credited artist; if missing on
     * a Spotify track, looks it up via Web API.
     */
    suspend fun artistOf(track: CatalogTrack): SearchItem? {
        val directUri = track.artistUri ?: track.artists.firstOrNull()?.uri
        val name = track.artists.firstOrNull()?.name ?: track.artist
        if (directUri != null) {
            return SearchItem(
                uri = directUri,
                title = name,
                subtitle = "",
                artworkUrl = null,
            )
        }
        if (track.uri.startsWith("spotify:track:") && container.webApi.isReady) {
            val id = track.uri.substringAfterLast(':')
            val dto = runCatching { container.api.track(id) }
                .onFailure { android.util.Log.w(TAG, "no artist for ${track.uri}: ${describe(it)}") }
                .getOrNull()
            val firstArtist = dto?.artists?.firstOrNull()
            if (firstArtist?.uri != null) {
                return SearchItem(
                    uri = firstArtist.uri,
                    title = firstArtist.name.ifBlank { name },
                    subtitle = "",
                    artworkUrl = null,
                )
            }
        }
        if (name.isNotBlank()) {
            val hit = runCatching {
                container.api.search(query = name, type = "artist", limit = 1).artists?.items?.firstOrNull()
            }.getOrNull()
            if (hit?.uri != null) {
                return SearchItem(
                    uri = hit.uri,
                    title = hit.name,
                    subtitle = "",
                    artworkUrl = hit.images.firstOrNull()?.url,
                )
            }
        }
        return null
    }

    /** Called when the track changes; cached and cheap on a repeat. */
    fun loadNowPlayingArt(uri: String?, title: String, album: String, artist: String) {
        nowPlayingArtJob?.cancel()
        _nowPlayingArt.value = null
        if (artist.isBlank()) {
            _nowPlayingArtPending.value = false
            return
        }
        _nowPlayingArtPending.value = true
        val artStarted = android.os.SystemClock.elapsedRealtime()
        nowPlayingArtJob = viewModelScope.launch {
            launch {
                delay(ART_WAIT_MS)
                _nowPlayingArtPending.value = false
            }

            // What came down with the download, first and without asking
            // anybody. A downloaded song keeps the tall picture beside its
            // audio, which is the whole point of keeping it: offline there is
            // nobody to ask, and online this is the same answer without the
            // round trip.
            //
            // "Asked and there is nothing" counts as an answer here, and ends
            // the wait just as an answer does. Otherwise every downloaded song
            // the other catalogue does not have would hold its own cover back
            // for the length of a lookup that was made days ago.
            keptArt(uri)?.let {
                _nowPlayingArt.value = it.album
                _nowPlayingArtPending.value = false
                return@launch
            }

            // The record's name is worth waiting a moment for.
            //
            // Metadata arrives in pieces: the id first, the title and artist
            // next, the record's name sometimes after that. Asking with it
            // missing does not fail — it falls through to searching for the
            // song, which answers with whichever release the search puts first,
            // and that is as often a compilation or a single as the record. Two
            // different answers for one song, each filed under its own key, is
            // why the cover could change between one opening of the app and the
            // next.
            //
            // Nothing is polled: the caller re-runs this the moment the name
            // lands, which cancels this job where it stands. The wait is only
            // for the songs that never get one — a local file, a stream — and
            // those go on to the search below as they did before.
            // Asked for, where the catalogue can say. A queue put back after a
            // restart can carry a song with no record's name, and waiting for
            // one to arrive meant the moving cover came several seconds late, or
            // not at all to whoever looked before it did.
            //
            // Asked more than once: right after a restart the session is still
            // coming up, the first answer is a failure, and the record's name
            // never arrived by any other way for the song that was put back.
            var record = album
            if (record.isBlank() && uri != null) {
                for (wait in ALBUM_ASK_MS) {
                    delay(wait)
                    record = withContext(Dispatchers.IO) {
                        runCatching { container.activeBackend.tracksOf(uri).firstOrNull()?.album }.getOrNull()
                    }.orEmpty()
                    if (record.isNotBlank()) break
                }
                android.util.Log.i(TAG, "art: record for $uri ${if (record.isBlank()) "not found" else "is '$record'"}")
            }
            if (record.isBlank()) delay(ALBUM_WAIT_MS)

            val askedAt = android.os.SystemClock.elapsedRealtime()
            val found = dev.lelonio.square.data.AppleCatalog.album(record, artist)
                .takeIf { record.isNotBlank() }
            _nowPlayingArt.value = found
            android.util.Log.i(
                TAG,
                "art timing: '$record' asked after ${askedAt - artStarted} ms, answered in " +
                    "${android.os.SystemClock.elapsedRealtime() - askedAt} ms, hero=${found?.heroUrl != null}",
            )

            // No record found, or one with no sleeve of its own: ask for the
            // song instead. Spotify's largest cover is 640 across and the player
            // draws it the width of the screen, so falling back to it is
            // falling back to a soft picture — where Apple keeps a song's
            // artwork at several thousand.
            if (found?.coverUrl == null && title.isNotBlank()) {
                val fromSong = dev.lelonio.square.data.AppleCatalog.song(title, artist, record)
                if (fromSong != null) {
                    _nowPlayingArt.value = (found ?: dev.lelonio.square.data.AppleCatalog.Album(
                        heroUrl = null,
                        coverUrl = null,
                    )).copy(coverUrl = fromSong)
                }
            }
            _nowPlayingArtPending.value = false
        }
    }

    /**
     * What was filed for a downloaded song when it was asked about.
     *
     * Null and [album] null are different answers, and the difference is the
     * whole reason this is wrapped: null means nobody has asked yet, so the
     * catalogue still might have something; an [album] of null means it was
     * asked and had nothing, and there is nothing to wait for.
     */
    private class KeptArt(val album: dev.lelonio.square.data.AppleCatalog.Album?)

    /**
     * The pictures kept beside a downloaded song, as the player wants them.
     *
     * Only urls with a file behind them: a url whose picture never came down is
     * a header that draws nothing at all offline. See DownloadExtras.
     */
    private suspend fun keptArt(uri: String?): KeptArt? {
        val track = uri ?: return null
        return withContext(Dispatchers.IO) {
            val extras = dev.lelonio.square.download.DownloadExtras
            val (hero, cover) = extras.art(track) ?: return@withContext null
            val onDisk = { url: String? -> url?.takeIf { extras.fileOf(it, "art") != null } }
            val kept = dev.lelonio.square.data.AppleCatalog.Album(
                heroUrl = onDisk(hero),
                coverUrl = onDisk(cover),
            )
            KeptArt(kept.takeIf { it.heroUrl != null || it.coverUrl != null })
        }
    }

    /**
     * Asks Apple's catalogue for the page's photograph, and its name drawn.
     *
     * An album is matched on its own name and its artist's, and the artist is
     * only known once the tracks are in — so this waits for them rather than
     * guessing. Everything about it is optional: no network, no match, no
     * pictures, and the page keeps the header it already has.
     */
    private suspend fun dressPage(uri: String, opened: String, kind: DetailKind) {
        // Offline this still runs. AppleCatalog answers from what it wrote down
        // and reaches for nothing, so a record whose songs are on the phone
        // opens on its own photograph in a tunnel; one that was never looked up
        // simply keeps Spotify's header, as it did before.

        // Whatever happens below, the header stops waiting: an answer, no
        // answer, or a network that is simply slow. A page that holds its
        // picture back for a lookup that is never coming is worse than one that
        // shows Spotify's.
        viewModelScope.launch {
            delay(HERO_WAIT_MS)
            if (_playlist.value.uri == uri) {
                _playlist.value = _playlist.value.copy(heroPending = false)
            }
        }
        val done = { if (_playlist.value.uri == uri) {
            _playlist.value = _playlist.value.copy(heroPending = false)
        } }

        // The name the page was opened with is empty when it was opened from a
        // link — the title arrives with the rest of it a moment later — and a
        // lookup for "" is a lookup for nothing.
        val name = opened.ifBlank {
            withTimeoutOrNull(ARTIST_WAIT_MS) {
                while (_playlist.value.uri == uri && _playlist.value.name.isBlank()) {
                    delay(POLL_INTERVAL_MS)
                }
                _playlist.value.name
            }.orEmpty()
        }
        if (name.isBlank()) {
            done()
            return
        }

        if (kind == DetailKind.ARTIST) {
            val found = dev.lelonio.square.data.AppleCatalog.artist(name)
            if (found == null) {
                done()
                return
            }
            if (_playlist.value.uri != uri) return
            _playlist.value = _playlist.value.copy(
                heroUrl = found.heroUrl,
                logoUrl = found.logoUrl,
                tintHex = found.bgColor,
                inkHex = found.textHex,
                heroAspect = found.heroAspect,
                notes = found.bio,
                origin = found.origin,
                heroPending = false,
            )
            return
        }

        // The record's artist, once there is a track to read it off.
        val artist = withTimeoutOrNull(ARTIST_WAIT_MS) {
            while (_playlist.value.uri == uri && _playlist.value.tracks.isEmpty()) {
                delay(POLL_INTERVAL_MS)
            }
            _playlist.value.tracks.firstOrNull()?.artist
        }
        if (artist == null) {
            done()
            return
        }

        // The catalogue's answer, or the one that came down with the songs.
        // The rows it writes expire after a month; the pictures beside a
        // download do not, so a record kept on the phone opens on its own
        // photograph however long it has been there.
        val found = dev.lelonio.square.data.AppleCatalog.album(name, artist)
            ?: keptArt(_playlist.value.tracks.firstOrNull()?.uri)?.album
        if (found == null) {
            done()
            return
        }
        if (_playlist.value.uri != uri) return
        _playlist.value = _playlist.value.copy(
            heroUrl = found.heroUrl,
            coverUrl = found.coverUrl,
            notes = found.notes,
            tintHex = found.bgColor,
            inkHex = found.textHex,
            motionUrl = found.motionUrl,
            heroPending = false,
        )
    }

    /**
     * Top tracks and albums for an artist.
     *
     * Web API rather than the access point: an artist is not a playable context,
     * so there is no track list to resolve there. That also means this is the one
     * screen which cannot work until the user has registered their own
     * application, hence the explicit message rather than a raw 401.
     */
    /** Everything an artist page shows, gathered in one go. */
    /** Everything an artist page shows, gathered in one go. */
    data class ArtistPage(
        val tracks: List<CatalogTrack>,
        val latest: ArtistRelease?,
        val albums: List<SearchItem>,
        val singles: List<SearchItem>,
        val appearsOn: List<SearchItem>,
        val playlists: List<SearchItem>,
        val relatedArtists: List<SearchItem>,
        val followers: Int,
        val genres: List<String>,
        val monthlyListeners: String?,
        val name: String? = null,
        val artworkUrl: String? = null,
        val biography: String? = null,
    )

    private data class BasicArtistMeta(val name: String, val artworkUrl: String?, val followers: Int)

    private suspend fun fetchArtistMetadata(id: String): BasicArtistMeta? = withContext(Dispatchers.IO) {
        val token = dev.lelonio.square.nativecore.NativeBridge.accessToken() ?: return@withContext null
        runCatching {
            val request = okhttp3.Request.Builder()
                .url("https://api.spotify.com/v1/artists/$id")
                .header("Authorization", "Bearer $token")
                .build()
            container.sharedHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val json = org.json.JSONObject(response.body.string())
                val name = json.optString("name").takeIf { it.isNotEmpty() } ?: return@withContext null
                val img = json.optJSONArray("images")?.optJSONObject(0)?.optString("url")
                val followers = json.optJSONObject("followers")?.optInt("total") ?: 0
                BasicArtistMeta(name, img, followers)
            }
        }.getOrNull()
    }

    private suspend fun loadArtist(uri: String, knownName: String = ""): ArtistPage = coroutineScope {
        val id = uri.substringAfterLast(':')
        val market = userCountry

        // Primary: Web API if custom developer app is configured
        if (container.webApi.isReady) {
            val tracksDeferred = async {
                runCatching {
                    withTimeoutOrNull(3000L) {
                        container.api.artistTopTracks(id, market = market).tracks.map { it.toCatalogTrack() }
                    }
                }.getOrNull()?.takeIf { it.isNotEmpty() }
                    ?: runCatching {
                        withTimeoutOrNull(3000L) {
                            container.api.artistTopTracks(id, market = "from_token").tracks.map { it.toCatalogTrack() }
                        }
                    }.getOrNull()?.takeIf { it.isNotEmpty() }
                    ?: runCatching {
                        withTimeoutOrNull(3000L) {
                            container.api.artistTopTracks(id, market = "US").tracks.map { it.toCatalogTrack() }
                        }
                    }.getOrNull().orEmpty().take(5)
            }
            val releasesDeferred = async {
                runCatching {
                    withTimeoutOrNull(3000L) {
                        container.api.artistAlbums(artistId = id, groups = "album,single", limit = 50, market = market).items
                    }
                }.getOrNull()?.takeIf { it.isNotEmpty() }
                    ?: runCatching {
                        withTimeoutOrNull(3000L) {
                            container.api.artistAlbums(artistId = id, groups = "album,single", limit = 50, market = null).items
                        }
                    }.getOrNull().orEmpty()
            }
            val artistDeferred = async {
                runCatching { withTimeoutOrNull(2000L) { container.api.artist(id) } }.getOrNull()
            }
            val followingDeferred = async {
                runCatching { withTimeoutOrNull(2000L) { container.api.isFollowing(ids = id).firstOrNull() } }.getOrNull()
            }

            var tracks = tracksDeferred.await()
            val releases = releasesDeferred.await()
            val artist = artistDeferred.await()
            val following = followingDeferred.await()
            val resolvedName = artist?.name ?: knownName

            // If Web API returned the artist info but 0 top tracks, don't leave tracks empty!
            // Query Gateway search or native context tracks as fallback
            if (tracks.isEmpty() && resolvedName.isNotEmpty()) {
                val searchRes = runCatching {
                    withTimeoutOrNull(3000L) {
                        container.gateway.search(resolvedName)?.let {
                            dev.lelonio.square.data.GatewaySearch.parse(
                                it,
                                dev.lelonio.square.backend.SearchLabels(
                                    artist = string(R.string.artist),
                                    album = string(R.string.album),
                                    playlist = string(R.string.playlist),
                                    podcast = string(R.string.podcast),
                                ),
                            )
                        }
                    }
                }.getOrNull()

                if (searchRes != null && searchRes.tracks.isNotEmpty()) {
                    tracks = searchRes.tracks
                        .filter { it.artists.any { a -> a.name.contains(resolvedName, ignoreCase = true) } }
                        .ifEmpty { searchRes.tracks }
                        .take(5)
                }
            }

            if (tracks.isEmpty()) {
                val nativeTracks = runCatching {
                    withTimeoutOrNull(3000L) {
                        Catalog.tracks(Catalog.contextTrackUris(uri).take(10))
                    }
                }.getOrNull()
                if (!nativeTracks.isNullOrEmpty()) {
                    tracks = nativeTracks.take(5)
                }
            }

            if (tracks.isNotEmpty() || releases.isNotEmpty() || artist != null) {
                if (following != null) {
                    _playlist.value = _playlist.value.let {
                        if (it.uri == uri) it.copy(following = following) else it
                    }
                }

                data class AlbumItemEntry(val item: SearchItem, val date: String)

                fun shelf(vararg groups: String): List<SearchItem> = releases
                    .filter { it.albumGroup in groups }
                    .mapNotNull { album ->
                        val date = album.releaseDate.orEmpty()
                        val year = date.take(4)
                        val type = when (album.albumGroup) {
                            "single" -> if (album.totalTracks > 1) "EP" else string(R.string.single)
                            "album" -> string(R.string.album)
                            "compilation" -> string(R.string.compilation)
                            else -> ""
                        }
                        val subtitle = if (type.isNotEmpty() && year.isNotEmpty()) "$type • $year" else year.ifEmpty { type }
                        AlbumItemEntry(
                            item = SearchItem(
                                uri = album.uri ?: return@mapNotNull null,
                                title = album.name,
                                subtitle = subtitle,
                                artworkUrl = album.images.firstOrNull()?.url,
                            ),
                            date = date,
                        )
                    }
                    .distinctBy { it.item.title.lowercase() }
                    .sortedByDescending { it.date }
                    .map { it.item }

                val followersCount = artist?.followers?.total ?: 0
                val monthlyListenersFormatted = formatMonthlyListeners(followersCount.toLong())

                var albumsList = shelf("album", "compilation")
                var singlesList = shelf("single")

                // If releases were empty, enrich from Gateway search if available
                if (albumsList.isEmpty() && singlesList.isEmpty() && resolvedName.isNotEmpty()) {
                    val searchRes = runCatching {
                        withTimeoutOrNull(3000L) {
                            container.gateway.search(resolvedName)?.let {
                                dev.lelonio.square.data.GatewaySearch.parse(
                                    it,
                                    dev.lelonio.square.backend.SearchLabels(
                                        artist = string(R.string.artist),
                                        album = string(R.string.album),
                                        playlist = string(R.string.playlist),
                                        podcast = string(R.string.podcast),
                                    ),
                                )
                            }
                        }
                    }.getOrNull()
                    if (searchRes != null && searchRes.albums.isNotEmpty()) {
                        albumsList = searchRes.albums
                    }
                }

                return@coroutineScope ArtistPage(
                    playlists = emptyList(),
                    tracks = tracks,
                    latest = null,
                    albums = albumsList,
                    singles = singlesList,
                    appearsOn = emptyList(),
                    relatedArtists = emptyList(),
                    followers = followersCount,
                    genres = artist?.genres.orEmpty(),
                    monthlyListeners = monthlyListenersFormatted,
                    name = resolvedName.takeIf { it.isNotEmpty() },
                    artworkUrl = artist?.images?.firstOrNull()?.url,
                )
            }
        }

        // Secondary fallback: Web player entity (when Web API is not configured or rate-limited)
        val webArtist = runCatching {
            withTimeoutOrNull(4000L) {
                dev.lelonio.square.data.SpotifyWebArtist.fetch(
                    id,
                    container.sharedHttpClient,
                    getApplication<SquareApplication>().resources,
                )
            }
        }.onFailure {
            android.util.Log.w(TAG, "web artist lookup failed for $id: ${describe(it)}")
        }.getOrNull()

        if (webArtist != null && (webArtist.tracks.isNotEmpty() || webArtist.albums.isNotEmpty() || webArtist.singles.isNotEmpty())) {
            val enrichedTracks = runCatching {
                withTimeoutOrNull(3000L) {
                    Catalog.tracks(webArtist.tracks.map { it.uri })
                }
            }.getOrNull()?.takeIf { it.size == webArtist.tracks.size } ?: webArtist.tracks

            val isFollowed = _followedArtists.value.any { it.uri == uri }
            _playlist.value = _playlist.value.let {
                if (it.uri == uri) it.copy(following = isFollowed) else it
            }

            return@coroutineScope webArtist.copy(tracks = enrichedTracks.take(5))
        }

        // Resolve artist name & metadata if knownName is empty
        val meta = if (knownName.isEmpty()) withTimeoutOrNull(3000L) { fetchArtistMetadata(id) } else null
        val searchName = knownName.ifEmpty { meta?.name.orEmpty() }.ifEmpty { webArtist?.name.orEmpty() }

        // Tertiary fallback: Gateway search if web scraper fails
        if (searchName.isNotEmpty()) {
            val searchRes = runCatching {
                withTimeoutOrNull(3000L) {
                    container.gateway.search(searchName)?.let {
                        dev.lelonio.square.data.GatewaySearch.parse(
                            it,
                            dev.lelonio.square.backend.SearchLabels(
                                artist = string(R.string.artist),
                                album = string(R.string.album),
                                playlist = string(R.string.playlist),
                                podcast = string(R.string.podcast),
                            ),
                        )
                    }
                }
            }.getOrNull()

            if (searchRes != null && (searchRes.tracks.isNotEmpty() || searchRes.albums.isNotEmpty())) {
                val matchedTracks = searchRes.tracks
                    .filter { it.artists.any { a -> a.name.contains(searchName, ignoreCase = true) } }
                    .ifEmpty { searchRes.tracks }
                    .take(5)

                val matchedAlbums = searchRes.albums
                val isFollowed = _followedArtists.value.any { it.uri == uri }
                _playlist.value = _playlist.value.let {
                    if (it.uri == uri) it.copy(following = isFollowed) else it
                }

                val followers = meta?.followers ?: webArtist?.followers ?: 0
                val artwork = meta?.artworkUrl ?: webArtist?.artworkUrl

                return@coroutineScope ArtistPage(
                    playlists = searchRes.playlists,
                    tracks = matchedTracks,
                    latest = null,
                    albums = matchedAlbums,
                    singles = emptyList(),
                    appearsOn = emptyList(),
                    relatedArtists = emptyList(),
                    followers = followers,
                    genres = emptyList(),
                    monthlyListeners = formatMonthlyListeners(followers.toLong()) ?: webArtist?.monthlyListeners,
                    name = searchName,
                    artworkUrl = artwork,
                    biography = webArtist?.biography,
                )
            }
        }

        // Last resort: native contextTracks
        val nativeTracks = runCatching {
            Catalog.tracks(Catalog.contextTrackUris(uri).take(10))
        }.getOrDefault(emptyList()).take(5)

        val isFollowed = _followedArtists.value.any { it.uri == uri }
        _playlist.value = _playlist.value.let {
            if (it.uri == uri) it.copy(following = isFollowed) else it
        }

        ArtistPage(
            playlists = emptyList(),
            tracks = nativeTracks,
            latest = null,
            albums = emptyList(),
            singles = emptyList(),
            appearsOn = emptyList(),
            relatedArtists = emptyList(),
            followers = meta?.followers ?: 0,
            genres = emptyList(),
            monthlyListeners = meta?.followers?.let { formatMonthlyListeners(it.toLong()) },
            name = searchName.takeIf { it.isNotEmpty() },
            artworkUrl = meta?.artworkUrl,
        )
    }

    private fun formatMonthlyListeners(count: Long): String? {
        if (count <= 0) return null
        val res = getApplication<SquareApplication>().resources
        val locale = java.util.Locale.getDefault()
        val formattedCount = when {
            count >= 1_000_000 -> String.format(locale, "%.1f M", count / 1_000_000.0)
            count >= 1_000 -> String.format(locale, "%.1f K", count / 1_000.0)
            else -> String.format(locale, "%,d", count)
        }
        val quantity = count.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        return res.getQuantityString(R.plurals.monthly_listeners, quantity, formattedCount)
    }

    /**
     * The playlists an artist is in, "This Is" first.
     *
     * Read from the gateway, which answers with the row the desktop client
     * heads "Featuring"; see [dev.lelonio.square.data.ArtistPlaylists]. The
     * search below is what is left when the gateway will not answer.
     */
    private suspend fun artistPlaylistsFor(uri: String, name: String): List<SearchItem> =
        container.gateway.artistPlaylists(uri)?.takeIf { it.isNotEmpty() }
            ?: if (container.webApi.isReady) artistPlaylists(name) else emptyList()

    /**
     * The playlists Spotify built around one artist, by searching for them.
     *
     * The fallback for [artistPlaylistsFor]: "This Is" and the rest are
     * ordinary public playlists, and what makes them Spotify's own rather than
     * a stranger's copy is the owner.
     *
     * Named after the artist too, because searching a name returns everything
     * anybody ever titled after them.
     */
    private suspend fun artistPlaylists(name: String): List<SearchItem> {
        if (name.isEmpty()) return emptyList()
        val needle = name.lowercase()
        return runCatching {
            container.api.search(
                query = "\"This Is $name\"",
                type = "playlist",
                limit = 20,
            ).playlists?.items.orEmpty()
                .filterNotNull()
                .filter { it.owner?.id == "spotify" && it.name.lowercase().contains(needle) }
                .map { playlist ->
                    SearchItem(
                        uri = playlist.uri,
                        title = playlist.name,
                        subtitle = playlist.description.orEmpty(),
                        artworkUrl = playlist.images.firstOrNull()?.url,
                    )
                }
                // "This Is" first when it is there: it is the one everybody
                // means by "the artist's playlist".
                .sortedBy { if (it.title.lowercase().startsWith("this is")) 0 else 1 }
                .take(10)
        }
            .onFailure { android.util.Log.w(TAG, "no playlists for $name: ${describe(it)}") }
            .getOrDefault(emptyList())
    }

    /**
     * Follows or unfollows the artist whose page is open.
     *
     * The button moves first and is put back if Spotify refuses: this is one
     * request over a network, and a control that waits for a round trip before
     * acknowledging a tap feels broken even when it works.
     */
    fun toggleFollowArtist() = viewModelScope.launch {
        val page = _playlist.value
        val uri = page.uri ?: return@launch
        if (page.kind != DetailKind.ARTIST) return@launch
        val was = page.following ?: false
        val id = uri.substringAfterLast(':')

        _playlist.value = _playlist.value.copy(following = !was)

        // The other source follows through its own account.
        if (!uri.startsWith("spotify:")) {
            runCatching { container.activeBackend.setFollowing(uri, !was) }
                .onSuccess {
                    resetFollowedReleases()
                    loadFollowedArtists()
                }
                .onFailure {
                    android.util.Log.e(TAG, "follow failed: ${chain(it)}", it)
                    if (_playlist.value.uri == uri) {
                        _playlist.value = _playlist.value.copy(following = was)
                    }
                }
            return@launch
        }

        if (!container.webApi.isReady) {
            val currentList = _followedArtists.value.toMutableList()
            if (was) {
                currentList.removeAll { it.uri == uri }
            } else {
                currentList.add(SearchItem(uri = uri, title = page.name, subtitle = "", artworkUrl = page.artworkUrl))
            }
            _followedArtists.value = currentList
            return@launch
        }

        runCatching {
            if (was) container.api.unfollowArtists(ids = id) else container.api.followArtists(ids = id)
        }
            .onSuccess {
                resetFollowedReleases()
                loadFollowedArtists()
            }
            .onFailure {
                android.util.Log.e(TAG, "follow failed: ${chain(it)}", it)
                if (_playlist.value.uri == uri) {
                    _playlist.value = _playlist.value.copy(following = was)
                }
                // Almost always the same cause: an application connected before
                // this feature existed, whose token carries no permission to
                // follow anybody. Saying so is more use than the error itself.
                _webApi.value = _webApi.value.copy(expired = true)
            }
    }

    private val _savedAlbums = MutableStateFlow<List<CatalogPlaylist>>(emptyList())

    init {
        // The widget's playlists, from the library's own recency and the
        // library's names and covers; see WidgetPlaylists.fill.
        viewModelScope.launch {
            kotlinx.coroutines.flow.combine(_state, container.playlistOrder.order, _savedAlbums) { state, order, albums ->
                Triple(state, order, albums)
            }.collect { (state, order, albums) ->
                val ready = state as? UiState.Ready ?: return@collect
                val changed = kotlinx.coroutines.withContext(Dispatchers.IO) {
                    container.widgetPlaylists.fill(order, ready.playlists + albums, container.activeBackend.id)
                }
                if (changed) dev.lelonio.square.widget.SquareWidget.refresh(getApplication())
            }
        }
    }

    /**
     * The albums the account has saved, for the library's own shelf of them.
     *
     * Kept apart from [UiState.Ready.playlists] rather than mixed into it: the
     * rootlist is playlists and nothing else, and a screen that filters by kind
     * needs to be able to say which is which without reading URIs.
     */
    val savedAlbums: StateFlow<List<CatalogPlaylist>> = _savedAlbums.asStateFlow()

    fun loadSavedAlbums() = viewModelScope.launch {
        // Whichever service is on. What follows is Spotify's own paging; every
        // other backend answers for itself, and one that keeps no albums
        // answers with none.
        if (container.activeBackend.id != BackendId.SPOTIFY) {
            _savedAlbums.value = runCatching { container.activeBackend.savedAlbums() }
                .getOrDefault(emptyList())
            return@launch
        }
        if (!container.webApi.isReady) {
            _savedAlbums.value = emptyList()
            return@launch
        }
        runCatching {
            val gathered = mutableListOf<CatalogPlaylist>()
            var offset = 0
            // Offset-paged, unlike the artists: walked to the end for the same
            // reason, which is that a first page is not a library.
            while (true) {
                val page = container.api.savedAlbums(limit = ALBUM_PAGE, offset = offset)
                gathered += page.items.mapNotNull { saved ->
                    CatalogPlaylist(
                        uri = saved.album.uri ?: return@mapNotNull null,
                        name = saved.album.name,
                        artworkUrl = saved.album.images.firstOrNull()?.url,
                    )
                }
                if (page.items.size < ALBUM_PAGE) break
                offset += ALBUM_PAGE
            }
            gathered.distinctBy { it.uri }
        }
            .onSuccess { _savedAlbums.value = it }
            .onFailure { android.util.Log.w(TAG, "saved albums unavailable: ${describe(it)}") }
    }

    private val _podcastShelves = MutableStateFlow<List<HomeShelf>>(emptyList())

    /** Spotify's own podcast home, for Home's chip of it; see [loadPodcastShelves]. */
    val podcastShelves: StateFlow<List<HomeShelf>> = _podcastShelves.asStateFlow()
    private val _podcastsLoading = MutableStateFlow(false)
    val podcastsLoading: StateFlow<Boolean> = _podcastsLoading.asStateFlow()
    private var podcastShelvesJob: Job? = null

    /** Once a session, when the chip is first chosen. */
    fun loadPodcastShelves() {
        if (podcastShelvesJob?.isActive == true || _podcastShelves.value.isNotEmpty()) return
        _podcastsLoading.value = true
        podcastShelvesJob = viewModelScope.launch {
            try {
                if (!awaitEngine()) return@launch
                val json = container.gateway.homeFacet(PODCASTS_FACET) ?: return@launch
                _podcastShelves.value = withContext(Dispatchers.Default) {
                    dev.lelonio.square.data.SpotifyHome.parse(json, podcasts = true)
                }
            } finally {
                _podcastsLoading.value = false
            }
        }
    }

    private val _savedShows = MutableStateFlow<List<CatalogPlaylist>>(emptyList())

    /** The podcasts the account follows, for the library's chip of them. */
    val savedShows: StateFlow<List<CatalogPlaylist>> = _savedShows.asStateFlow()

    fun loadSavedShows() = viewModelScope.launch {
        _savedShows.value = runCatching { readSavedShows() }
            .onFailure { android.util.Log.w(TAG, "followed shows unavailable: ${describe(it)}") }
            .getOrDefault(emptyList())
    }

    /** From Spotify's library page for them, or whatever the source keeps. */
    private suspend fun readSavedShows(): List<CatalogPlaylist> {
        if (container.activeBackend.id != BackendId.SPOTIFY) return container.activeBackend.savedShows()
        if (!awaitEngine()) return emptyList()
        val gathered = mutableListOf<CatalogPlaylist>()
        while (gathered.size < MAX_SHOWS) {
            val page = container.gateway.followedShows(offset = gathered.size)
                ?.let(dev.lelonio.square.data.SpotifyPodcasts::parseFollowed)
                ?: break
            gathered += page
            if (page.isEmpty()) break
        }
        return gathered.distinctBy { it.uri }
    }

    private val _newEpisodes = MutableStateFlow<List<CatalogTrack>>(emptyList())

    /** What the followed podcasts put out lately, newest first; see [loadNewEpisodes]. */
    val newEpisodes: StateFlow<List<CatalogTrack>> = _newEpisodes.asStateFlow()
    private var newEpisodesJob: Job? = null
    private var newEpisodesAt = 0L

    /**
     * The New tab's row of episodes, read again at most every few minutes.
     *
     * On Spotify there is no one list of them: each followed show is asked for
     * its newest few, a handful at a time, and what came out in the last weeks
     * is kept. YouTube Music keeps such a list itself.
     */
    fun loadNewEpisodes() {
        if (newEpisodesJob?.isActive == true) return
        if (System.currentTimeMillis() - newEpisodesAt < NEW_EPISODES_FRESH_MS) return
        newEpisodesJob = viewModelScope.launch {
            val episodes = runCatching {
                if (container.activeBackend.id != BackendId.SPOTIFY) {
                    container.activeBackend.newEpisodes()
                } else {
                    val shows = _savedShows.value.ifEmpty { readSavedShows().also { _savedShows.value = it } }
                    val since = java.time.Instant.now().minus(java.time.Duration.ofDays(NEW_EPISODES_DAYS)).toString()
                    withContext(Dispatchers.IO) {
                        shows.take(MAX_SHOWS_ASKED).chunked(SHOWS_AT_ONCE).flatMap { batch ->
                            coroutineScope {
                                batch.map { show ->
                                    async {
                                        container.gateway.showEpisodes(show.uri, 0, EPISODES_A_SHOW)
                                            ?.let { dev.lelonio.square.data.SpotifyPodcasts.parseEpisodes(it, show.name) }
                                            ?.tracks.orEmpty()
                                    }
                                }.awaitAll().flatten()
                            }
                        }
                    }
                        .filter { (it.releasedAt ?: "") >= since }
                        .sortedByDescending { it.releasedAt }
                        .take(NEW_EPISODES)
                }.map(container.episodeProgress::apply)
            }
                .onFailure { android.util.Log.w(TAG, "new episodes unavailable: ${describe(it)}") }
                .getOrNull() ?: return@launch
            _newEpisodes.value = episodes
            newEpisodesAt = System.currentTimeMillis()
        }
    }

    private val _followedArtists = MutableStateFlow<List<SearchItem>>(emptyList())

    /** The artists this account follows, for the library. */
    val followedArtists: StateFlow<List<SearchItem>> = _followedArtists.asStateFlow()

    fun loadFollowedArtists() = viewModelScope.launch {
        if (container.activeBackend.id != BackendId.SPOTIFY) {
            _followedArtists.value = runCatching { container.activeBackend.followedArtists().distinctBy { it.uri } }
                .getOrDefault(emptyList())
            return@launch
        }
        // The gateway first: it answers for anyone signed in, and without an
        // application of one's own it is the only thing that does.
        val fromLibrary = container.gateway.followedArtists()
        if (fromLibrary == null && !container.webApi.isReady) {
            _followedArtists.value = emptyList()
            return@launch
        }
        runCatching {
            (fromLibrary ?: followedReleaseRepository.webArtists()).mapNotNull { artist ->
                SearchItem(
                    uri = artist.uri ?: return@mapNotNull null,
                    title = artist.name, subtitle = "",
                    artworkUrl = artist.images.firstOrNull()?.url,
                )
            }.sortedBy { it.title.lowercase() }
        }
            .onSuccess { _followedArtists.value = it }
            .onFailure {
                android.util.Log.w(TAG, "followed artists unavailable: ${describe(it)}")
                // 403 here has one cause: an application connected before the
                // follow permissions were asked for. The token is valid and
                // will never be allowed to read this, so the way out is the
                // same one an expired session takes — sign in again, once.
                if (describe(it).contains("403")) {
                    _webApi.value = _webApi.value.copy(expired = true)
                }
            }
    }

    /**
     * A show's episodes, newest first, up to [SHOW_EPISODES_LIMIT].
     *
     * Not to the end, as a playlist is read: a daily show has thousands, and a
     * page of the last few hundred is what anybody scrolls. Null when the first
     * page would not come back.
     */
    private suspend fun readShow(
        uri: String,
        showName: String,
        onPage: (List<CatalogTrack>, Boolean) -> Unit,
    ): List<CatalogTrack>? {
        val loaded = mutableListOf<CatalogTrack>()
        var offset = 0
        while (loaded.size < SHOW_EPISODES_LIMIT) {
            val page = container.gateway.showEpisodes(uri, offset)
                ?.let { dev.lelonio.square.data.SpotifyPodcasts.parseEpisodes(it, showName) }
                ?: return loaded.takeIf { it.isNotEmpty() }
            loaded += page.tracks.map(container.episodeProgress::apply)
            val next = page.nextOffset
            val more = next != null && next > offset && loaded.size < SHOW_EPISODES_LIMIT
            onPage(loaded.toList(), more)
            if (!more) break
            offset = next!!
        }
        return loaded
    }

    private fun kindOf(uri: String): DetailKind = when {
        uri.startsWith("spotify:artist:") -> DetailKind.ARTIST
        // An artist on the other source is an artist too: the page they open on
        // is the one with the follow button, whichever catalogue they are from.
        uri.startsWith(dev.lelonio.square.backend.youtube.YouTubeBackend.ARTIST_PREFIX) ->
            DetailKind.ARTIST
        uri.startsWith("spotify:album:") -> DetailKind.ALBUM
        dev.lelonio.square.data.SpotifyPodcasts.isShow(uri) -> DetailKind.SHOW
        else -> DetailKind.PLAYLIST
    }

    /**
     * Waits for the native session to finish authenticating.
     *
     * Every catalogue call fails outright without it, so polling here is what
     * stops a cold start from showing a spurious error. Polling rather than a
     * callback because readiness lives behind a JNI boolean.
     */
    private suspend fun awaitEngine(): Boolean = withTimeoutOrNull(ENGINE_TIMEOUT_MS) {
        while (!NativeBridge.isConnected) {
            // The service clears the session when Spotify rejects it. Without
            // this check the UI would sit on "connecting" for the full timeout
            // and then report a connection problem, when the real answer is
            // that the user has to log in again.
            if (!container.spotifySignedIn) return@withTimeoutOrNull false
            // An engine that came up offline is never going to report itself
            // connected, and waiting for it to is thirty seconds of spinner on
            // a phone that has the music already. There is a player behind this
            // — see build_offline_bundle — so the answer is "ready", and what
            // it is ready for is what the library below works out.
            if (runCatching { NativeBridge.isOffline }.getOrDefault(false)) {
                return@withTimeoutOrNull false
            }
            delay(POLL_INTERVAL_MS)
        }
        true
    } ?: false

    /** Full `Class: message` chain, for the log. */
    private fun chain(error: Throwable): String =
        generateSequence(error, Throwable::cause)
            .joinToString(" <- ") { "${it::class.java.name}: ${it.message}" }

    /**
     * A message worth putting on screen. `Throwable.message` alone is often null
     * or an empty wrapper, which is how "unknown error" screens happen.
     */
    private fun describe(error: Throwable): String {
        if (error is java.util.concurrent.CancellationException || error is CancellationException) {
            return ""
        }
        if (error is java.net.BindException || error.message?.contains("EADDRINUSE") == true) {
            return string(R.string.cannot_connect)
        }
        val parts = generateSequence(error, Throwable::cause)
            .mapNotNull { it.message?.takeIf(String::isNotBlank) }
            .toList()
        return parts.firstOrNull() ?: error::class.java.simpleName
    }

    private companion object {
        /** How long the app has to stay offline before what needs a connection goes. */
        const val OFFLINE_SETTLE_MS = 4_000L

        /** The waits before each time a song's record is asked for; see loadNowPlayingArt. */
        val ALBUM_ASK_MS = listOf(0L, 1_500L, 3_000L, 5_000L)

        /** The waits before each try at Spotify's home shelves. */
        val HOME_RETRY_MS = listOf(0L, 2_000L, 6_000L)

        const val TAG = "SquareUi"

        /** After the start's own requests, which the listener is waiting on. */
        const val KEPT_SYNC_DELAY_MS = 15_000L

        /** Artists asked for new records on the home page; one request each. */
        const val FRESH_ARTISTS = 14

        /** How far the daily turn moves; a prime, so it works through the list. */
        const val DAILY_TURN = 7

        /** A page of saved albums; the API's own maximum. */
        const val ALBUM_PAGE = 50

        /** How many detail pages back the in-screen history holds. */
        const val PAGE_HISTORY = 12

        /** Spotify's name for its home's podcast chip. */
        const val PODCASTS_FACET = "podcasts-chip"

        /** Followed podcasts read, and how many of them asked for new episodes, how many at once. */
        const val MAX_SHOWS = 500
        const val MAX_SHOWS_ASKED = 60
        const val SHOWS_AT_ONCE = 6
        const val EPISODES_A_SHOW = 5

        /** What counts as new, how much of it the tab shows, and how long it is believed. */
        const val NEW_EPISODES_DAYS = 21L
        const val NEW_EPISODES = 30
        const val NEW_EPISODES_FRESH_MS = 10 * 60 * 1000L

        /** How many of a show's episodes a page reads; see [readShow]. */
        const val SHOW_EPISODES_LIMIT = 300

        /** How long a home row gets before it stops being worth scrolling. */
        const val FEED_ROW = 12

        /** Records asked of Spotify's own new-releases list for the New tab. */
        const val NEW_RELEASES = 50

        /** How many of those pages to read; see loadNewPage. */
        const val NEW_PAGES = 3

        /** How many of them the page leads with, drawn large. */
        const val HERO_RELEASES = 6

        /** And how many are opened for a song to put in the list under them. */
        const val NEW_SONGS = 18

        /**
         * How long a header holds its picture back for the other catalogue.
         *
         * Long enough for a cached answer and a quick search, short enough that
         * a bad network costs a moment of plain colour rather than a page with
         * no picture at all.
         */
        const val HERO_WAIT_MS = 1_200L

        /**
         * How long the player holds its picture back for the other catalogue.
         *
         * Long enough for a cached answer and a search on a working connection,
         * short enough that a bad one costs a moment of colour rather than a
         * screen with no artwork.
         */
        const val ART_WAIT_MS = 1_500L

        /** How long a song's record has to arrive before it is given up on. */
        const val ALBUM_WAIT_MS = 900L

        /** The shape the header draws a cover in; see PlayerScreen. */
        const val DETAIL_WIDE = 3
        const val DETAIL_TALL = 4

        /** How long the album lookup waits for a track to name the artist. */
        const val ARTIST_WAIT_MS = 8_000L

        /** Where the playlists' mix choices are kept; see mixOn and toggleMix. */
        const val MIX_PREFS = "square_mix"
        /** Mixed in Spotify's app, and turned off here. */
        const val MIX_OFF = "off"
        /** Not mixed in Spotify's app, and turned on here. */
        const val MIX_ON = "on"

        const val ENGINE_TIMEOUT_MS = 30_000L

        /** How long the library is waited for once there is a session. */
        const val LIBRARY_TIMEOUT_MS = 20_000L

        /** And how long before it is asked again when it did not come. */
        const val LIBRARY_RETRY_MS = 30_000L
        const val POLL_INTERVAL_MS = 250L

        /** Each track is its own access-point round trip. */
        /** Tracks resolved per access-point round trip; see loadContextInto. */
        const val METADATA_BATCH = 100

        /** The Web API's own maximum page size for playlist tracks. */
        const val WEB_API_PAGE = 100

        /**
         * And what the account's own lists take, which is half that: `me/tracks`
         * answers 400 to anything larger rather than an empty page.
         */
        const val WEB_API_LIBRARY_PAGE = 50

        /**
         * How long the copy of Liked Songs on disk answers for the whole list.
         *
         * Long enough that a listening session costs nothing, short enough
         * that a track saved on another device is not denied all day.
         */
        const val LIKED_TRUSTED_MS = 6L * 60 * 60 * 1000

        /** How long a question about a track waits for the next one. */
        const val LIKED_BATCH_WAIT_MS = 400L

        /** How many track lists to keep resolved; see contextCache. */
        const val CONTEXT_CACHE_SIZE = 8

        const val SEARCH_DEBOUNCE_MS = 350L

        /** How many of each kind a page of results holds; see Gateway. */
        const val SEARCH_PAGE = 20

        /** Spotify acknowledges a transfer before it has taken effect. */
        const val TRANSFER_SETTLE_MS = 700L
    }
}
