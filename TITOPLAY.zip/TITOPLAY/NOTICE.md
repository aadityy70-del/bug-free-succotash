# TITOPLAY

TITOPLAY is a modified version of an open-source music player by **Lelonio**,
released under the **GNU General Public License v3.0** (see `LICENSE`).

Changes by **Aditya Yadav (Titonox)**: renamed to TITOPLAY, new logo and
branding, glass and fade effects, pinned headings, a two-way karaoke control,
endless Home feed, and other fixes. These changes were made in 2026.

Because this is GPL-3.0 software, anyone who receives the app is entitled to the
source code of this version, and any further changes must stay under the same
licence. Keep the `LICENSE` file and this notice when sharing the code.
