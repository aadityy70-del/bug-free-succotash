# TITOPLAY

Music player by **Aditya Yadav** (Titonox).

- Instagram: https://www.instagram.com/titonoxofficial
- YouTube: https://www.youtube.com/@titonoxofficial

Open source under GPL-3.0, based on work by Lelonio. See `NOTICE.md` and `LICENSE`.
